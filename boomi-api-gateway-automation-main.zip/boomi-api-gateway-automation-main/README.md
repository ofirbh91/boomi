# Boomi API Gateway - CI/CD Automation

Automating the lifecycle of **Boomi API Gateway** artifacts (API proxies, policies,
API Service Components, and their deployments) through the **Boomi AtomSphere Platform API**
and the **APIM GraphQL API**.

> **Goal:** treat API proxies, policies, and gateway configuration as version-controlled
> artifacts that flow through a repeatable build → package → deploy → verify pipeline
> across Dev / Test / Prod environments - instead of hand-clicking them in the GUI.

---

## 1. Where the API Gateway sits in the Boomi API Platform

This repository targets the **native Boomi API Gateway** (the "Original" offering), which
layers gateway policies on top of APIs built and deployed from Integration.

### The API delivery chain

An API request travels from the consumer, through the gateway policy layer, into the
deployed **API Service Component**, which routes to a Boomi **Integration process** that
does the real work against backend systems.

```mermaid
flowchart TD
    consumer["API Consumer<br/>(app / partner)"]
    portal["Developer Portal<br/>(keys, docs, plans)"]

    subgraph GW["Boomi API Gateway (Runtime)"]
        proxy["API Proxy"]
        pol["Policy Chain<br/>(rate-limit, auth, CORS…)"]
    end

    subgraph RT["Integration Runtime (Advanced Atom/Molecule)"]
        asc["API Service Component<br/>type=webservice"]
        wss["WSS Listen process<br/>(Web Services Server Start)"]
        proc["Integration Process<br/>(maps, connectors, logic)"]
    end

    backend["Backend Systems<br/>(SaaS, DB, files, queues)"]

    consumer -->|request + API key| proxy
    portal -.subscribes / issues keys.-> proxy
    proxy --> pol --> asc
    asc --> wss --> proc --> backend
    backend --> proc --> wss --> asc --> pol --> proxy --> consumer
```

---

## 2. Boomi API Gateway components

The artifacts we want under CI/CD control, grouped by layer.

| # | Component | What it is | Where it lives |
|---|---|---|---|
| 1 | **API Gateway Runtime** | A runtime (Atom/Molecule/Cloud) with the API Gateway role that hosts proxies and enforces policies | `Manage → Atom Management` |
| 2 | **API Proxy** | A **deployable component** that fronts any endpoint (Boomi or external) through the Gateway with shared auth/validation; supports REST/SOAP/OData/GraphQL routing, base path, target server URL, and auth (None/Basic/Pass-Through/OAuth 2.0) | Build → package → deploy |
| 3 | **Policies** | Rules attached to a proxy: rate limiting, quota/subscription plans, authentication, IP filtering, CORS, caching, payload limits | Configured on the proxy |
| 4 | **API Service Component** (`type=webservice`) | The deployable that stands up REST listeners on an **Advanced** runtime; generates an OpenAPI spec at deploy time | Build (Integration) |
| 5 | **WSS Listen process** | Integration process whose Start step is a Web Services Server *Listen* action; the API Service Component routes to it | Build (Integration) |
| 6 | **Developer Portal** | Branded catalog where consumers discover APIs, read docs, and request subscription keys | `API Management → Developer Portal` |
| 7 | **Environment & Extensions** | Per-environment configuration (URLs, credentials, plan limits) injected without editing components | `Manage → Environments` |
| 8 | **Packaged Component** | An immutable, versioned snapshot of a component - the unit that gets deployed | Platform API / Deploy |

### Policy types (the "policy chain")

| Policy | Purpose | Typical CI/CD parameter |
|---|---|---|
| Rate Limiting | Cap requests per interval | requests / window |
| Quota & Subscription Plans | Tiered consumer allowances (Bronze/Silver/Gold) | plan → limits mapping |
| Authentication | API key / OAuth / Basic / mTLS enforcement | scheme, key location |
| IP Allow/Deny | Network-level access control | CIDR lists |
| CORS | Cross-origin rules for browser clients | origins, methods, headers |
| Caching | Response caching to cut backend load | TTL, cache key |
| Payload / Header limits | Guard against oversized or malformed requests | max size, header rules |

---

## 3. Two automation planes

Boomi API Gateway automation splits across **two distinct APIs**. Getting this split right is
the core of the CI/CD design.

```mermaid
flowchart LR
    subgraph BUILD["Plane A - Build & Deploy (AtomSphere REST API)"]
        c1["API Proxy component<br/>(deployable)"]
        c2["API Service Component<br/>(webservice)"]
        c3["Packaged Component<br/>(version)"]
        c4["Deploy → Environment<br/>(w/ assigned Gateway)"]
        c1 --> c3
        c2 --> c3
        c3 --> c4
    end

    subgraph GOV["Plane B - Gateway Governance (APIM GraphQL API)"]
        g1["Deployed API"]
        g2["Policy Rules<br/>(rate-limit, CORS, auth…)"]
        g3["Plans & Applications<br/>(subscriptions, keys)"]
        g4["Authentication Sources"]
        g1 --> g2
        g1 --> g3
    end

    c4 --> g1
```

- **Plane A - AtomSphere REST API** (`https://api.boomi.com/api/rest/v1`): everything that is
  a *Component* is authored, versioned, packaged, and deployed here - including the **API
  Proxy component**, which is fully deployable (build → Create Packaged Component → deploy to
  an environment that has an assigned API Gateway). This is what the Plane A scripts
  (`ci-cd/10-build.sh`, `ci-cd/20-deploy.sh`) drive via the bundled `boomi-*.sh` helpers.
- **Plane B - APIM GraphQL API** (`https://api.boomi.com/graphql`): once an API/proxy is
  *deployed*, its runtime governance is managed here via query + mutation. A `DeployedApi`
  exposes these governance fields directly:
  `plans` / `planMappings` / `subscriptions` (subscription tiers & keys), `customPolicies`
  (custom gateway policies), `cors` (CORS policy), `executionSettings` (throttling/rate
  limits), `authSource`, `requiredRoles`, `certificateAuthentication`. Metrics & Runtime are
  query-only.
  **Auth:** HTTP Basic with username `BOOMI_TOKEN.<user>`, password = API token, **plus** an
  `X-Account: <accountId>` header (both required). Handled by `ci-cd/lib/common.sh`.

### Automation matrix

Every element below is driven by a ready-to-run `ci-cd/` accelerator script (Tooling column).
Plane A scripts wrap the bundled `boomi-*.sh` CLI helpers; Plane B `gateway-*.sh` scripts wrap
the APIM GraphQL API directly.

| Element | Plane | Mechanism | Tooling (`ci-cd/` script) | CI/CD status |
|---|---|---|---|---|
| Connectivity preflight | A+B | Auth check on both API planes | `ci-cd/00-check.sh` | ✅ Full |
| API Proxy component | A | Component CRUD → package → deploy | `ci-cd/10-build.sh`, `ci-cd/20-deploy.sh` | ✅ Full |
| API Service Component (`webservice`) | A | Component CRUD → package → deploy | `ci-cd/10-build.sh`, `ci-cd/20-deploy.sh` | ✅ Full |
| WSS Listen process + profiles | A | Component CRUD → deploy | `ci-cd/10-build.sh`, `ci-cd/20-deploy.sh` | ✅ Full |
| Packaged Component (version) | A | `PackagedComponent` API | `ci-cd/20-deploy.sh` | ✅ Full |
| Deploy to environment | A | `DeployedPackage` / Deploy API | `ci-cd/20-deploy.sh` | ✅ Full |
| Environment Extensions (per-env config) | A | `EnvironmentExtensions` API | `ci-cd/30-extensions.sh` | ✅ Full |
| Gateway ↔ environment assignment | B | `gateways` / `environments` queries | `ci-cd/gateway-api.sh gateways` / `environments` | ✅ Query/verify |
| Deployed API | B | `deployedApi(s)` query | `ci-cd/gateway-api.sh list` / `get` | ✅ Full |
| Policy rules (rate-limit, CORS, auth…) | B | `deployedApiPolicyRule*` query/mutation | `ci-cd/gateway-policy.sh` | ✅ Full |
| Subscription Plans | B | `deployedApiPlan*` query/mutation | `ci-cd/gateway-plan.sh` | ✅ Full |
| Applications / API keys | B | `deployedApiApplication*` query/mutation | `ci-cd/gateway-application.sh` | ✅ Full |
| Subscriptions (app ↔ API ↔ plan, keys) | B | `deployedApiSubscription*` query/mutation | `ci-cd/gateway-subscription.sh` | ✅ Full |
| Authentication Sources | B | `authSource*` query/mutation | `ci-cd/gateway-authsource.sh` | ✅ Full |
| Gateway policies (declarative, bulk) | B | Apply all `gateway/*.graphql` manifests | `ci-cd/40-govern.sh` | ✅ Full |
| Developer Portal catalog | B/GUI | Publish tied to Deployed API; branding in GUI | GraphQL + GUI | 🟡 Partial |

Legend: ✅ scriptable end-to-end · 🟡 scriptable with GUI fallback · 🔴 GUI-only

> **Two ways to drive Plane B.** The `gateway-*.sh` scripts are **imperative accelerators**
> (`list` / `get` / `create` / `update` / `delete`) - ideal for discovery and one-off changes.
> `40-govern.sh` is the **declarative** path - it applies version-controlled
> `gateway/*.graphql` manifests in bulk during the pipeline. Use the accelerators to explore
> and to author, then capture the final shape as a manifest for repeatable promotion.

---

## 4. Target CI/CD pipeline

Artifacts are authored and version-controlled locally, promoted through environments, and
verified at each stage. Packaging produces an immutable version; the same package is deployed
to each environment with environment-specific extensions.

```mermaid
flowchart TD
    dev["Author / edit<br/>components locally"] --> vcs["Commit to Git<br/>(XML + policy manifests)"]
    vcs --> ci{"CI trigger"}
    ci --> build["Push components<br/>(design-time)"]
    build --> pkg["Create Packaged<br/>Component (version)"]

    pkg --> denv["Deploy → DEV env"]
    denv --> dtest["Smoke test<br/>(WSS/curl)"]
    dtest -->|pass| tenv["Deploy → TEST env<br/>+ extensions"]
    tenv --> ttest["Integration tests"]
    ttest -->|pass| penv["Deploy → PROD env<br/>+ extensions"]
    penv --> verify["Verify proxy + policies live"]

    dtest -->|fail| dev
    ttest -->|fail| dev
```

### Promotion model

| Stage | Runtime | Extensions applied | Gate |
|---|---|---|---|
| **Dev** | Dev Advanced atom | Dev URLs/keys | Smoke test route returns 200 |
| **Test** | Test atom/molecule | Test URLs/keys, relaxed limits | Automated integration tests |
| **Prod** | Prod molecule/cloud | Prod URLs/keys, plan limits | Verify proxy reachable + policies enforced |

---

## 5. Proposed repository layout

```
boomi-api-gateway-automation/
├── README.md                     # this document
├── .env.example                  # credential template (copy to .env)
├── .gitignore
├── active-development/           # Plane A helper-script working files (gitignored)
│
├── components/                   # Plane A - AtomSphere components (versioned XML)
│   ├── api-proxy/                # API Proxy component XML
│   ├── api-service/              # API Service Component XML (type=webservice)
│   └── processes/                # WSS Listen processes + profiles
│
├── gateway/                      # Plane B - APIM GraphQL governance (declarative)
│   ├── policies/                 # policy-rule definitions (rate-limit, CORS, auth…)
│   ├── plans/                    # subscription plan definitions
│   ├── applications/             # app / API-key definitions
│   └── portal/                   # developer-portal catalog config notes
│
├── environments/                 # per-env config
│   ├── dev.extensions.json       # environment extension values (Plane A)
│   ├── test.extensions.json
│   └── prod.extensions.json
│
├── vendor/                       # bundled third-party dependencies (no external install)
│   └── boomi-integration/        # Boomi AtomSphere helper scripts (Plane A), BSD-2-Clause
│       ├── scripts/              # boomi-*.sh CLI helpers + boomi-common.sh
│       ├── VERSION
│       └── LICENSE
│
└── ci-cd/                           # portable bash pipeline (CI-system agnostic)
    ├── lib/common.sh             # shared: env load, skill runner, GraphQL client
    ├── lib/gateway.sh            # Plane B accelerator primitives (used by gateway-*.sh)
    ├── config.sh                 # project config: deployables, stage→env, verify
    ├── 00-check.sh               # preflight: auth + connectivity, both planes
    ├── 10-build.sh               # push components (design-time)
    ├── 20-deploy.sh <stage>      # package + deploy to the stage's environment
    ├── 30-extensions.sh <stage>  # apply per-stage environment extension values
    ├── 40-govern.sh [--check]    # apply gateway/*.graphql manifests (declarative)
    ├── 50-verify.sh              # smoke-test the live proxy route
    ├── pipeline.sh <stage>       # orchestrates 00→50 for a stage
    │                             #  ── Plane B accelerators (APIM GraphQL) ──
    ├── gateway-api.sh                 # deployed APIs: list | get | gateways | environments
    ├── gateway-policy.sh              # policy rules: list | get | create | update | delete
    ├── gateway-plan.sh                # subscription plans: list | get | create | update | delete
    ├── gateway-application.sh         # applications/keys: list | get | create | update | delete
    ├── gateway-authsource.sh          # auth sources (JWT): list | get | create | update | delete
    ├── gateway-subscription.sh        # subscriptions/API keys: list | get | create | regenerate | delete
    └── examples/                 # sample create/update inputs for the gateway-*.sh scripts
        ├── plan/gold.json
        ├── policy/ip-allowlist.json
        ├── application/partner-app.json
        ├── authsource/azure-entraid.json
        └── subscription/subscribe.json
```

> **Note:** `boomi-deploy.sh` already performs the two-step `PackagedComponent` →
> `DeployedPackage` flow, so packaging and deploy are one stage (`20-deploy.sh`) rather than
> two.

---

## 6. Getting started

**Prerequisites**
- `curl` and `jq` on the `PATH`.
- The Plane A `boomi-*.sh` helper scripts (bundled in-project under `vendor/boomi-integration`,
  so no external install is required).
- A Boomi account with **API Management enabled** and at least one **environment that has an
  assigned API Gateway**.
- API credentials: a `BOOMI_USERNAME`, `BOOMI_API_TOKEN`, and `BOOMI_ACCOUNT_ID`.

**Steps**
1. Copy `.env.example` to `.env` and fill in your credentials (and environment IDs).
2. Confirm connectivity to both API planes: `bash ci-cd/00-check.sh`.
3. Build or import an **API Proxy component** (Plane A) under `components/` and version-control it.
4. Add it to `DEPLOYABLES` in [ci-cd/config.sh](ci-cd/config.sh), then run `bash ci-cd/pipeline.sh dev`.
5. Author the gateway policy/plan mutations under `gateway/` (templates provided as `.example`
   files) using the field names from your account's GraphQL reference UI, or use the
   `ci-cd/gateway-*.sh` accelerators to apply them directly.

> **Note on API Management prerequisites:** deployment targets must be **environments with an
> assigned Boomi API Gateway**, and API Management must be enabled on the account. The APIM
> GraphQL API (Plane B) is a separate endpoint from the AtomSphere REST API (Plane A) - both
> use the same account credentials but different base URLs. Run `bash ci-cd/00-check.sh` to
> confirm both endpoints resolve for your account.

## 7. References

- [API Gateway](https://help.boomi.com/docs/Atomsphere/API%20Management/Topics/api-API_Gateway_ddddb1bf-f768-4698-b175-2a2ae701d6ae)
- [API Proxy components](https://help.boomi.com/docs/Atomsphere/API%20Management/Topics/int-API_Proxy_components_24a9612a-2e4a-4ae9-ba66-88ba1b3f9c97)
- [Creating and configuring an API Proxy component](https://help.boomi.com/docs/Atomsphere/API%20Management/Topics/int-Creating_and_configuring_an_API_Proxy_component_85ede556-d8c1-40c8-9785-e1b2d76b8787)
- [Using Policies with Gateway APIs](https://help.boomi.com/docs/Atomsphere/API%20Management/Topics/using_policies_with_gateway_apis)
- [APIM GraphQL APIs overview](https://developer.boomi.com/docs/APIs/GraphQL/APIM_GraphQL_apis_overview)
- [Deployed APIs](https://help.boomi.com/docs/Atomsphere/API%20Management/Topics/c-api-APIs_f52533b3-afeb-4d64-9b30-57a6c5dd2999)
- [Boomi Enterprise Platform APIs](https://help.boomi.com/docs/Atomsphere/Integration/int-Boomi_Platform_APIs)
