#!/usr/bin/env bash
# Copyright (c) Anthony Rabiaza 2026-09-08
# Updated 2026-09-08
# ci-cd/50-verify.sh - smoke-test the live gateway proxy route.
# Probes VERIFY_BASE_URL + VERIFY_PATH and asserts the expected HTTP status.
# Set VERIFY_PATH / VERIFY_EXPECT_CODE in ci-cd/config.sh or the environment.

set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib/common.sh
. "${HERE}/lib/common.sh"
# shellcheck source=config.sh
. "${HERE}/config.sh"
load_env

[ -n "$VERIFY_BASE_URL" ] || die "VERIFY_BASE_URL not set (SERVER_BASE_URL in .env, or export VERIFY_BASE_URL)"
url="${VERIFY_BASE_URL%/}${VERIFY_PATH}"

verify=(); [ "${SERVER_VERIFY_SSL:-true}" = "false" ] && verify=(-k)
auth=()
case "${SERVER_AUTH_TYPE:-}" in
  basic)  auth=(-u "${SERVER_USERNAME:-}:${SERVER_TOKEN:-}") ;;
  bearer) auth=(-H "Authorization: Bearer ${SERVER_BEARER_TOKEN:-}") ;;
esac

log_info "Verify: GET ${url} (expect ${VERIFY_EXPECT_CODE})"
# ${arr[@]+"${arr[@]}"} - safe empty-array expansion under `set -u` (bash 3.2)
code="$(curl -sS ${verify[@]+"${verify[@]}"} ${auth[@]+"${auth[@]}"} -o /dev/null -w '%{http_code}' --max-time 20 "$url" || echo "000")"

if [ "$code" = "$VERIFY_EXPECT_CODE" ]; then
  log_info "Verify PASSED (HTTP ${code})"
else
  die "Verify FAILED: got HTTP ${code}, expected ${VERIFY_EXPECT_CODE}"
fi
