#!/usr/bin/env bash
# Copyright (c) Anthony Rabiaza 2026-09-08
# Updated 2026-10-01
# ci-cd/config.sh - project-specific pipeline configuration.
# Sourced after ci-cd/lib/common.sh. Edit these values for your project.

# --- Deployable components (Plane A) ---------------------------------------
# Component XML files that should be PACKAGED + DEPLOYED (in order).
# Profiles and other design-only components do NOT belong here - they are
# pushed at build time but deployed transitively with their parent.
# Add paths as you build real components under components/.
DEPLOYABLES=(
  # "components/processes/MyListen_Process.xml"
  # "components/api-service/MyApi_ServiceComponent.xml"
  # "components/api-proxy/MyProxy.xml"
)

# --- Design-time-only components pushed at build (Plane A) ------------------
# Everything under these globs is pushed (create/update) but not independently
# deployed. Leave as-is to auto-discover all component XML.
BUILD_GLOBS=(
  "components/processes"
  "components/api-service"
  "components/api-proxy"
)

# --- API Proxy defaults (Plane A - api-proxy.sh) ---------------------------
# Default folderFullPath for `api-proxy.sh create` when --folder is omitted.
# Leave empty to require --folder on each create.
: "${API_PROXY_FOLDER:=}"

# --- Stage → environment mapping (Plane A deploy target) -------------------
# Resolve the Boomi environment GUID for a stage. Set stage-specific vars in
# .env (BOOMI_ENVIRONMENT_ID_DEV/TEST/PROD) to promote across environments;
# otherwise all stages fall back to the single BOOMI_ENVIRONMENT_ID.
env_id_for_stage() {
  local stage; stage="$(printf '%s' "${1:-dev}" | tr '[:lower:]' '[:upper:]')"
  local var="BOOMI_ENVIRONMENT_ID_${stage}"
  printf '%s' "${!var:-${BOOMI_ENVIRONMENT_ID:-}}"
}

# --- Environment extension value files (Plane A) ---------------------------
# Per-stage extension values applied after deploy. File may be absent (skip).
extensions_file_for_stage() {
  printf '%s/environments/%s.extensions.json' "$PROJECT_ROOT" "${1:-dev}"
}

# --- Governance manifests (Plane B - APIM GraphQL) -------------------------
GATEWAY_POLICIES_DIR="${PROJECT_ROOT}/gateway/policies"
GATEWAY_PLANS_DIR="${PROJECT_ROOT}/gateway/plans"
GATEWAY_APPS_DIR="${PROJECT_ROOT}/gateway/applications"

# --- OpenAPI-driven request validation (Plane B - gateway-oas-validation.sh) --
# One entry per deployed API: "<deployedApiId>|<openapi.json>|<plan options>|<apply options>".
# 40-govern.sh generates json-validation (and, with --params, request-validation) rules from
# the OpenAPI and applies them to the deployed API; 40-govern.sh --check only plans and
# dry-runs. Paths are relative to the project root. Keep the OpenAPI contract-first in
# gateway/openapi/ (Boomi-generated specs carry no `required`). Find ids with
# `bash ci-cd/gateway-api.sh list`.
OAS_VALIDATION=(
  # "59ab7eeb-85da-4df9-9344-69572f3372a2|gateway/openapi/dummy-api.openapi.json||--adopt --prune"
)

# --- Smoke test (Plane B/verify) -------------------------------------------
# Base URL of the deployed gateway + the proxy path to probe in 50-verify.sh.
# Fill from SERVER_BASE_URL and your proxy's Base API Path once deployed.
VERIFY_BASE_URL="${SERVER_BASE_URL:-}"
VERIFY_PATH="${VERIFY_PATH:-/}"           # e.g. /orders/v1/health
VERIFY_EXPECT_CODE="${VERIFY_EXPECT_CODE:-200}"
