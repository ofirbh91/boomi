#!/usr/bin/env bash
# Copyright (c) Anthony Rabiaza 2026-09-08
# Updated 2026-09-08
# ci-cd/gateway-policy.sh - Plane B accelerator: gateway Policy Rules + attachment.
# Wraps deployedApiPolicyRule* GraphQL operations (rate-limit, CORS, auth, cache…).
#
#   list                    list all policy rules
#   get <id>                one policy rule with its configuration
#   create <input.json>     create a policy rule (DeployedApiPolicyRuleCreateInput)
#   update <input.json>     update a policy rule (DeployedApiPolicyRuleInput, needs id)
#   delete <id>             delete a policy rule
#   attached <deployedApiId>                          show custom policies on a deployed API
#   attach <deployedApiId> <path> <ruleId[,ruleId]> [appliedWhen]
#                           bind rule(s) to ONE route/path of a deployed API
#   set-policies <deployedApiId> <customPolicies.json>
#                           REPLACE the whole customPolicies list (the only way to
#                           remove/rewrite attachments - bulkAdd is add-only)
#
# attach/set-policies take effect on the running gateway automatically (no redeploy).
# WARNING: <path> is compiled as a REGEX, not an ant-glob. "/a/b" literal, "/a/.*"
# prefix; an invalid regex like "/a/**" fails to compile and 500s the ENTIRE API.
# Boomi route paths double the segment (base + objectName + urlPath), e.g. /dumb/dumb.
#
# A policy is TWO steps: a rule is a reusable *definition* (create/update/delete);
# attaching it to a specific deployed API and route/path is a separate operation
# (attach → deployedApiPolicyBulkAdd). Creating a rule alone applies it to nothing.
#
# create input.json is the GraphQL input object itself, e.g.:
#   { "name": "Rate limit 100/min", "type": "<policyTypeId>",
#     "methods": ["GET","POST"], "configuration": "{\"limit\":100}" }
#
# attach <path> is the route relative to the API context (e.g. /dumb to scope to the
# dumb route only). appliedWhen defaults to AFTER_STANDARD_POLICIES; other values:
# BEFORE_STANDARD_POLICIES, BEFORE_REQUEST_{BEFORE,AFTER}_STANDARD_POLICIES,
# AFTER_RESPONSE_{BEFORE,AFTER}_STANDARD_POLICIES.

set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "${HERE}/lib/common.sh"
. "${HERE}/config.sh"
. "${HERE}/lib/gateway.sh"
load_env

LIST='query { deployedApiPolicyRules { id name description type configuration scope } }'
GET='query ($id: ID!) { deployedApiPolicyRule(id: $id) { id name description type configuration scope } }'
CREATE='mutation ($in: DeployedApiPolicyRuleCreateInput!) {
  deployedApiPolicyRuleCreate(deployedApiPolicyRule: $in) { id name type } }'
UPDATE='mutation ($in: DeployedApiPolicyRuleInput!) {
  deployedApiPolicyRuleUpdate(deployedApiPolicyRule: $in) { id name type configuration } }'
DELETE='mutation ($id: ID!) { deployedApiPolicyRuleDelete(id: $id) }'

# --- Route attachment (beyond the standard CRUD) ---------------------------
# deployedApiPolicyBulkAdd binds rule(s) to a route (policyInput.path) on one or
# more deployed APIs; returns the affected DeployedApi(s) with their customPolicies.
ATTACH='mutation ($in: DeployedApiPolicyBulkAddInput!) {
  deployedApiPolicyBulkAdd(deployedApiPolicyBulkAddInput: $in) {
    id customPolicyPathMode
    customPolicies { path when rules { id name type } }
  } }'
ATTACHED='query ($id: ID!) { deployedApi(id: $id) {
    id customPolicyPathMode
    customPolicies { path when rules { id name type } } } }'

# Replace the ENTIRE customPolicies list on a deployed API (deployedApiUpdate).
# The only way to REMOVE/rewrite attachments - bulkAdd is add-only. Input JSON is
# the customPolicies array: [{ "path": "...", "rules": ["<ruleId>"], "appliedWhen": "..." }].
# NB: the gateway compiles `path` as a REGEX (not ant-glob) - "/a/b" literal, "/a/.*"
# prefix; an invalid regex (e.g. "/a/**") breaks the whole API's policy chain (500s).
SETPOLICIES='mutation ($in: DeployedApiInput!) {
  deployedApiUpdate(deployedApi: $in) {
    id customPolicyPathMode
    customPolicies { path when rules { id name type } }
  } }'

policy_set_policies() {
  local api_id="${1:-}" file="${2:-}"
  [ -n "$api_id" ] && [ -n "$file" ] || die "set-policies needs: <deployedApiId> <customPolicies.json>"
  [ -f "$file" ] || die "customPolicies JSON not found: $file"
  jq -e 'type=="array"' "$file" >/dev/null 2>&1 || die "customPolicies JSON must be an array of {path, rules, appliedWhen}"
  local vars; vars="$(jq -c --arg id "$api_id" '{in:{id:$id, customPolicies: .}}' "$file")"
  log_warn "REPLACE customPolicies on deployedApi ${api_id} with $(jq length "$file") entr(ies) from ${file}"
  APIM_GRAPHQL_VARS="$vars" apim_graphql - ".data" <<GQL
${SETPOLICIES}
GQL
}

policy_attach() {
  local api_id="${1:-}" path="${2:-}" rules_csv="${3:-}" when="${4:-AFTER_STANDARD_POLICIES}"
  [ -n "$api_id" ] && [ -n "$path" ] && [ -n "$rules_csv" ] \
    || die "attach needs: <deployedApiId> <path> <ruleId[,ruleId...]> [appliedWhen]"
  local rules_json; rules_json="$(printf '%s' "$rules_csv" | jq -Rc 'split(",") | map(select(length>0))')"
  [ "$(printf '%s' "$rules_json" | jq 'length')" -gt 0 ] || die "attach: no rule ids in '${rules_csv}'"
  local vars; vars="$(jq -cn --arg api "$api_id" --arg path "$path" --argjson rules "$rules_json" --arg when "$when" \
    '{in:{deployedApiIds:[$api], policyInput:{path:$path, rules:$rules, appliedWhen:$when}}}')"
  log_warn "attach rule(s) [${rules_csv}] → deployedApi ${api_id} at path '${path}' (${when})"
  APIM_GRAPHQL_VARS="$vars" apim_graphql - ".data" <<GQL
${ATTACH}
GQL
}

case "${1:-}" in
  attach)      shift; policy_attach "$@" ;;
  set-policies) shift; policy_set_policies "$@" ;;
  attached)    log_info "custom policies on deployed API ${2:-}"; gw_get "$ATTACHED" "${2:-}" ;;
  -h|--help|help)
    gw_usage "policy rule"
    cat <<'EOF'

Route attachment (extends the standard CRUD):
  attached <deployedApiId>                            show custom policies on a deployed API
  attach <deployedApiId> <path> <ruleId[,ruleId]> [appliedWhen]
                                                      bind rule(s) to ONE route/path
    appliedWhen: AFTER_STANDARD_POLICIES (default) | BEFORE_STANDARD_POLICIES |
                 BEFORE_REQUEST_* | AFTER_RESPONSE_*
  set-policies <deployedApiId> <customPolicies.json> replace the whole customPolicies
                                                      list (only way to remove/rewrite)

Attachments take effect on the gateway automatically (no redeploy). <path> is a REGEX:
"/a/b" literal, "/a/.*" prefix - an invalid regex like "/a/**" 500s the ENTIRE API.
EOF
    ;;
  *) gw_dispatch "policy rule" "$LIST" "$GET" "$CREATE" "$UPDATE" "$DELETE" "$@" ;;
esac
