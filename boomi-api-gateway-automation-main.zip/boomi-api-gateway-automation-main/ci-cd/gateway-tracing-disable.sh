#!/usr/bin/env bash
# Copyright (c) Anthony Rabiaza 2026-10-14
# Updated 2026-10-14
# ci-cd/gateway-tracing-disable.sh - Plane B accelerator: stop an Advanced tracing
# session on one deployed API before it expires.
#
#   <deployedApiId>
#
# Wraps deployedApiUpdate with tracing.advanced.expiresAt = null, which cancels the
# session and returns the API to its base tracingMode (or the gateway's setting when
# that is null). Safe to run when no session is active. Takes effect without a
# redeploy. Start a session with gateway-tracing-enable.sh.
#
# e.g.  bash ci-cd/gateway-tracing-disable.sh 59ab7eeb-85da-4df9-9344-69572f3372a2

set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "${HERE}/lib/common.sh"
. "${HERE}/config.sh"
. "${HERE}/lib/gateway.sh"
load_env

DISABLE='mutation ($id: ID!) {
  deployedApiUpdate(deployedApi: { id: $id, tracing: { advanced: { expiresAt: null } } }) {
    id component { name } environment { name }
    tracing { tracingMode advanced { expiresAt captureBody captureHeaders capturePolicyConfig } }
  } }'

usage() {
  cat <<EOF
Usage: bash ci-cd/gateway-tracing-disable.sh <deployedApiId>

  <deployedApiId>   deployed API whose Advanced tracing session to stop
                    (find it with: bash ci-cd/gateway-api.sh list)

Start a session with: bash ci-cd/gateway-tracing-enable.sh <deployedApiId> [minutes]
Check the state:      bash ci-cd/gateway-api.sh get <deployedApiId>
EOF
}

case "${1:-}" in
  ""|-h|--help|help) if [ -z "${1:-}" ]; then usage >&2; exit 2; fi; usage ;;
  -*) log_err "unknown option '${1}'"; usage >&2; exit 2 ;;
  *)
    [ "$#" -eq 1 ] || { log_err "unexpected argument '${2}'"; usage >&2; exit 2; }
    log_warn "disable Advanced tracing on deployedApi ${1}"
    gw_get "$DISABLE" "$1" ".data.deployedApiUpdate" ;;
esac
