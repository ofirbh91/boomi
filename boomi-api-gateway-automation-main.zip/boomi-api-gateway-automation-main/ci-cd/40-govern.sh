#!/usr/bin/env bash
# Copyright (c) Anthony Rabiaza 2026-09-08
# Updated 2026-10-01
# ci-cd/40-govern.sh [--check] - Plane B gateway governance via APIM GraphQL.
# Applies policy rules, plans, and applications to DEPLOYED APIs.
#
# Model: each *.graphql file under gateway/{policies,plans,applications} is a
# GraphQL mutation document. An optional sibling <name>.vars.json supplies its
# variables. Files run in lexical order (prefix with 10-, 20-… to sequence).
#
# Then, for each OAS_VALIDATION entry in config.sh, generates validation rules from
# the API's OpenAPI and applies them (ci-cd/gateway-oas-validation.sh plan + apply).
#
# --check : run a read-only query to validate connectivity + auth, list the
#           deployed APIs the gateway currently exposes, dry-run the OpenAPI
#           validation entries, then exit.
#
# Why files-of-mutations: the exact APIM GraphQL mutation shapes (field names
# for policy rules, plan tiers, etc.) are account/version specific. Author them
# once from your account's GraphQL API reference UI (Services → API Management →
# GraphQL) and version-control them here. The helper handles auth + transport.

set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib/common.sh
. "${HERE}/lib/common.sh"
# shellcheck source=config.sh
. "${HERE}/config.sh"
load_env

# OpenAPI-driven validation (config: OAS_VALIDATION). $1 = "--dry-run" or "".
apply_oas_validation() {
  local dry="${1:-}" entry api spec plan_opts apply_opts dir
  [ "${#OAS_VALIDATION[@]}" -gt 0 ] || return 0
  for entry in "${OAS_VALIDATION[@]}"; do
    IFS='|' read -r api spec plan_opts apply_opts <<< "$entry"
    [ -n "$api" ] && [ -n "$spec" ] || die "OAS_VALIDATION entry needs '<deployedApiId>|<openapi.json>|...': ${entry}"
    case "$spec" in /*) ;; *) spec="${PROJECT_ROOT}/${spec}" ;; esac
    dir="$(mktemp -d)/plan"
    log_info "validation: ${spec#"${PROJECT_ROOT}/"} → deployedApi ${api}"
    # shellcheck disable=SC2086  # option strings are word lists by design
    bash "${HERE}/gateway-oas-validation.sh" plan "$spec" "$dir" ${plan_opts}
    # shellcheck disable=SC2086
    bash "${HERE}/gateway-oas-validation.sh" apply "$api" "$dir" ${apply_opts} ${dry}
  done
}

if [ "${1:-}" = "--check" ]; then
  log_info "APIM GraphQL connectivity check → $(apim_graphql_url)"
  # Read-only: list deployed APIs. Adjust fields to your schema if needed.
  apim_graphql - '.data' <<'GQL'
query ListDeployedApis {
  deployedApis {
    id
    version
    component { name }
    environment { name }
  }
}
GQL
  log_info "Connectivity OK."
  apply_oas_validation --dry-run
  exit 0
fi

apply_dir() {
  local label="$1" dir="$2"
  [ -d "$dir" ] || return 0
  local found=0
  while IFS= read -r -d '' gql; do
    found=1
    local rel="${gql#"${PROJECT_ROOT}/"}"
    local vars_file="${gql%.graphql}.vars.json"
    if [ -f "$vars_file" ]; then
      export APIM_GRAPHQL_VARS="$(cat "$vars_file")"
    else
      export APIM_GRAPHQL_VARS='{}'
    fi
    log_info "${label}: applying ${rel}"
    apim_graphql "$gql" '.data'
    unset APIM_GRAPHQL_VARS
  done < <(find "$dir" -name '*.graphql' -type f -print0 2>/dev/null | sort -z)
  [ "$found" -eq 1 ] || log_warn "${label}: no .graphql files in ${dir#"${PROJECT_ROOT}/"}"
}

log_info "Governance apply → $(apim_graphql_url)"
apply_dir "policies"     "$GATEWAY_POLICIES_DIR"
apply_dir "plans"        "$GATEWAY_PLANS_DIR"
apply_dir "applications" "$GATEWAY_APPS_DIR"
apply_oas_validation
log_info "Governance apply complete."
