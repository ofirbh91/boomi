# Plane B input examples (`ci-cd/examples/`)

Ready-to-edit sample inputs for the `ci-cd/gateway-*.sh` accelerators. Each file **is** the GraphQL
input object for a `create` (or `update`) call - the script binds it to the mutation's input
variable, so you just fill in the fields.

| Object | Example | Apply with |
|---|---|---|
| Subscription Plan | `plan/gold.json` | `bash ci-cd/gateway-plan.sh create ci-cd/examples/plan/gold.json` |
| Policy Rule | `policy/ip-allowlist.json` | `bash ci-cd/gateway-policy.sh create ci-cd/examples/policy/ip-allowlist.json` |
| Policy Rule (JSON schema validation) | `policy/dummy-add-json-validation.json` | `bash ci-cd/gateway-policy.sh create ci-cd/examples/policy/dummy-add-json-validation.json` |
| Policy Rule (JSON schema validation, single field) | `policy/dummy-abs-json-validation.json` | `bash ci-cd/gateway-policy.sh create ci-cd/examples/policy/dummy-abs-json-validation.json` |
| Policy attachment (whole list) | `policy/dummy-api-custompolicies.json` | `bash ci-cd/gateway-policy.sh set-policies <deployedApiId> ci-cd/examples/policy/dummy-api-custompolicies.json` |
| Application | `application/partner-app.json` | `bash ci-cd/gateway-application.sh create ci-cd/examples/application/partner-app.json` |
| Auth Source (JWT) | `authsource/azure-entraid.json` | `bash ci-cd/gateway-authsource.sh create ci-cd/examples/authsource/azure-entraid.json` |
| Subscription (API key) | `subscription/subscribe.json` | `bash ci-cd/gateway-subscription.sh create ci-cd/examples/subscription/subscribe.json` |

To **update** instead of create, add the object's `id` to the JSON and use `update`:

```bash
bash ci-cd/gateway-plan.sh get <id>                          # inspect current values
# edit the file, add  "id": "<id>"
bash ci-cd/gateway-plan.sh update ci-cd/examples/plan/gold.json
```

## Field notes (from the live schema)

- **Plan** `rateLimitPeriod` / `quotaLimitPeriod`: `SECOND | MIN | HOUR | DAY | WEEK | MONTH`.
  `rateLimit` / `quotaLimit` / `maxMessageSize` are integers. Only `name` is required.
- **Policy Rule** `type` is a gateway policy-type id - run `bash ci-cd/gateway-policy.sh list` to see
  the ids in use (e.g. `ip-filtering`, `transform-headers`). `methods` is a list of HTTP
  methods (`GET POST PUT DELETE HEAD OPTIONS PATCH …`). `configuration` is a **JSON string**
  (escaped) whose shape depends on the policy type - copy an existing rule's `configuration`
  as your starting point. Required: `name`, `methods`, `type`.
- **Application** `status`: `ENABLED | SUSPENDED`. Required: `name`, `status`.
- **Auth Source** targets JWT (`authSourceJWTCreate`). Required: `name`, `issuer`;
  `details` (`AuthSourceJWTDetailsInput`) holds `audiences`, `roles`, `groupsAttribute`,
  `userIdClaim`, `description`.
- **Subscription** links an application to an API on a plan. Required: `deployedApiId`,
  `applicationId`, `planId` (all string GUIDs); `startDate` / `expirationDate` are optional
  ISO-8601 timestamps. The created subscription's `apiKeyId` is the issued API key.

> These are templates with placeholder values - review every field before applying to a real
> account. Field names follow the APIM GraphQL input types; confirm them against your
> account's GraphQL reference UI if a mutation is rejected.
