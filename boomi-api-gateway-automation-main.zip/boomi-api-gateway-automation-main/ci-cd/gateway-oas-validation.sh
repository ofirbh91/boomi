#!/usr/bin/env bash
# Copyright (c) Anthony Rabiaza 2026-10-01
# Updated 2026-10-14
# ci-cd/gateway-oas-validation.sh - Plane B accelerator: generate and apply gateway
# request-validation policies from an OpenAPI 3.0 definition.
#
# The Boomi gateway cannot enforce an OpenAPI file (it is documentation only), but it
# can run json-validation (body vs JSON Schema) and request-validation (headers/query)
# policy rules. This script translates the OpenAPI contract into those rules.
#
#   fetch <url> [out.json]                download a spec (sends x-api-key: $OAS_API_KEY if set)
#   plan  <openapi.json> [planDir] [opts] generate rule inputs + attachment plan (offline, no .env)
#   apply <deployedApiId> <planDir> [--dry-run] [--adopt] [--prune]
#                                         upsert rules by name, merge attachments, set-policies
#
# plan options:
#   --api-name <name>   prefix for rule names (default: info.title)
#   --strict            objects without additionalProperties get additionalProperties:false
#                       (OpenAPI's default is "extra fields allowed")
#   --require-all       objects without a `required` list get all their properties required
#                       (Boomi-generated specs carry no `required`; profiles have no optional fields)
#   --params            also generate request-validation rules for query/header params
#                       (UNVERIFIED on this gateway: type id and config from Boomi docs)
#   --when <phase>      appliedWhen (default BEFORE_REQUEST_AFTER_STANDARD_POLICIES)
#
# Plan directory layout (reviewable, version-controllable):
#   rules/*.json        one DeployedApiPolicyRuleCreateInput per operation
#   attachments.json    [{path, appliedWhen, rules:[<rule name>]}] (names, resolved at apply)
#   plan.txt            what was generated and what was skipped, and why
#   meta.json           {apiName, source, strict, params, when}
#
# Managed rules carry the description prefix "[oas-validation]". apply only replaces
# attachments that point at managed rules; every other custom policy on the API is kept.
# --adopt also detaches hand-made validation rules (json-validation / request-validation)
# on the planned paths, so the OpenAPI becomes the single owner of their validation.
#
# Platform limits handled here (see "Route conventions" in docs/openapi-validation.md):
#   - attachment paths are lowercased by API Management and may only contain URL
#     characters, so mixed-case paths and templated paths ({id}) are skipped, not guessed;
#   - an invalid path can 500 the whole API, so apply refuses anything not matching
#     ^/[a-z0-9/_.~-]*$ before calling set-policies.

set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "${HERE}/lib/common.sh"
. "${HERE}/config.sh"

MARKER='[oas-validation]'
DEFAULT_WHEN='BEFORE_REQUEST_AFTER_STANDARD_POLICIES'
SAFE_PATH_RE='^/[a-z0-9/_.~-]*$'
# Gravitee id of the request-validation policy as documented by Boomi (unverified here).
: "${REQUEST_VALIDATION_TYPE:=policy-request-validation}"

usage() {
  sed -n '4,/^$/p' "${BASH_SOURCE[0]}" | sed '$d; s/^# \{0,1\}//'
}

# --- fetch -------------------------------------------------------------------
oas_fetch() {
  local url="${1:-}" out="${2:-openapi.json}"
  [ -n "$url" ] || die "fetch needs: <url> [out.json]"
  local hdr=(); [ -n "${OAS_API_KEY:-}" ] && hdr=(-H "x-api-key: ${OAS_API_KEY}")
  log_info "fetch ${url} → ${out}"
  curl -sSf ${hdr[@]+"${hdr[@]}"} -o "$out" "$url" || die "download failed: ${url}"
  jq -e '.openapi // .swagger' "$out" >/dev/null 2>&1 \
    || die "${out} is not a JSON OpenAPI document (convert YAML first, e.g. yq -o=json)"
  jq -r '"  \(.info.title) \(.info.version) (OpenAPI \(.openapi // .swagger)), \(.paths|length) path(s)"' "$out" >&2
}

# --- plan --------------------------------------------------------------------
# jq library: $ref resolution and OpenAPI 3.0 schema -> JSON Schema draft-04.
JQ_LIB='
def unescape: gsub("~1";"/") | gsub("~0";"~");
def resolve($root; $d):
  if $d > 32 then error("$ref nesting deeper than 32 (recursive schema?)")
  elif type == "object" then
    if has("$ref") then
      (.["$ref"]) as $r
      | if ($r | startswith("#/")) then
          ($root | getpath($r[2:] | split("/") | map(unescape))) as $t
          | if $t == null then error("unresolved $ref: \($r)") else ($t | resolve($root; $d + 1)) end
        else error("external $ref not supported: \($r)") end
    else map_values(resolve($root; $d)) end
  elif type == "array" then map(resolve($root; $d))
  else . end;
def d4($strict; $reqall):
  if type != "object" then .
  else
    (if .nullable == true and has("type") then .type = ([.type] | flatten + ["null"]) else . end)
    | del(.nullable, .example, .examples, .xml, .externalDocs, .discriminator,
          .readOnly, .writeOnly, .deprecated)
    # OpenAPI-only formats are not JSON Schema draft-04 formats; drop them
    | (if (.format | type) == "string"
          and (.format | IN("int32", "int64", "float", "double", "byte", "binary", "password"))
       then del(.format) else . end)
    | (if (.properties | type) == "object" then .properties |= map_values(d4($strict; $reqall)) else . end)
    | (if (.patternProperties | type) == "object" then .patternProperties |= map_values(d4($strict; $reqall)) else . end)
    | (if (.items | type) == "object" then .items |= d4($strict; $reqall) else . end)
    | (if (.additionalProperties | type) == "object" then .additionalProperties |= d4($strict; $reqall) else . end)
    | (if has("not") then .not |= d4($strict; $reqall) else . end)
    # members of allOf must stay open, or the composition can never validate
    | (if has("allOf") then .allOf |= map(d4(false; $reqall)) else . end)
    | reduce ("anyOf", "oneOf") as $k (.; if has($k) then .[$k] |= map(d4($strict; $reqall)) else . end)
    | (if $reqall and ((.properties | type) == "object") and (has("required") | not)
          and ((.properties | length) > 0)
       then .required = (.properties | keys_unsorted) else . end)
    | (if $strict and (.type == "object" or has("properties"))
          and (has("additionalProperties") | not) and (has("allOf") | not)
       then .additionalProperties = false else . end)
  end;
# Short, human-readable description of a (draft-04) schema for the 400 error body.
# The gateway can not report which field failed, so the error says what is expected.
def tdesc:
  if (.enum | type) == "array" then
    "one of " + (.enum[:5] | map(tojson) | join(", ")) + (if (.enum | length) > 5 then ", ..." else "" end)
  else
    ((.type // (if has("properties") then "object" else "any" end))
      | if type == "array" then map(select(. != "null")) | join("/") else . end) as $t
    | if $t == "array" and (.items | type) == "object" then
        "array of " + ((.items.type // "any") | if type == "array" then join("/") else . end)
      elif (.format | type) == "string" then "\($t), \(.format)"
      else $t end
  end;
def expect:
  if (.properties | type) == "object" and (.properties | length) > 0 then
    (.required // []) as $req
    | (.properties | to_entries) as $ps
    | "a JSON object with "
      + ($ps[:10] | map("\(.key) (\(.value | tdesc)\(if (.key | IN($req[])) then ", required" else "" end))") | join(", "))
      + (if ($ps | length) > 10 then ", ..." else "" end)
      + (if .additionalProperties == false then "; no other fields" else "" end)
  else "a JSON value of type " + tdesc end;
'

oas_plan() {
  local spec="${1:-}"; shift || true
  [ -n "$spec" ] && [ -f "$spec" ] || die "plan needs: <openapi.json> [planDir] [--api-name N] [--strict] [--require-all] [--params] [--when PHASE]"
  local dir="" api_name="" strict=false reqall=false params=false when="$DEFAULT_WHEN"
  while [ "$#" -gt 0 ]; do
    case "$1" in
      --api-name) api_name="${2:?--api-name needs a value}"; shift 2 ;;
      --strict)   strict=true; shift ;;
      --require-all) reqall=true; shift ;;
      --params)   params=true; shift ;;
      --when)     when="${2:?--when needs a value}"; shift 2 ;;
      -*)         die "unknown plan option: $1" ;;
      *)          [ -z "$dir" ] || die "unexpected argument: $1"; dir="$1"; shift ;;
    esac
  done
  jq -e '(.openapi // "") | startswith("3.")' "$spec" >/dev/null 2>&1 \
    || die "${spec}: only OpenAPI 3.x JSON is supported"
  [ -n "$api_name" ] || api_name="$(jq -r '.info.title // "API"' "$spec")"
  [ -n "$dir" ] || dir="plan-$(printf '%s' "$api_name" | tr 'A-Z ' 'a-z-' | tr -cd 'a-z0-9-')"
  rm -rf "${dir}/rules"; mkdir -p "${dir}/rules"

  local src; src="$(jq -r '"\(.info.title) \(.info.version)"' "$spec")"
  # One JSON line per decision: {kind:"rule"|"skip", ...}
  jq -c --arg api "$api_name" --arg src "$src" --arg marker "$MARKER" \
        --argjson strict "$strict" --argjson reqall "$reqall" --argjson params "$params" \
        --arg when "$when" --arg rvtype "$REQUEST_VALIDATION_TYPE" --arg safe "$SAFE_PATH_RE" --arg sq "'" \
    "${JQ_LIB}"'
    . as $root
    | .paths | to_entries[] | .key as $path | .value as $item
    | ($item.parameters // []) as $pathParams
    | $item | to_entries[]
    | select(.key | IN("get","put","post","delete","options","head","patch","trace"))
    | (.key | ascii_upcase) as $m | .value as $op
    | "\($m) \($path)" as $label
    | if (($op.requestBody // null) == null) and ($params | not) then
        {kind:"skip", op:$label, reason:"no request body (use --params to validate query/header parameters)"}
      elif ($path | test("[{}]")) then
        {kind:"skip", op:$label, reason:"templated path: API Management only accepts URL characters, so {params} cannot be matched"}
      elif ($path | test($safe) | not) then
        {kind:"skip", op:$label, reason:"path is not lowercase/URL-safe: API Management lowercases policy paths and the gateway matches case-sensitively; give the route a lowercase path"}
      else
        # --- body: json-validation -------------------------------------------
        ( ($op.requestBody // null) | if . == null then empty else resolve($root; 0) end
          | (.content // {}) | to_entries
          | map(select(.key | test("^application/(.+\\+)?json"))) | first // empty
          | .value.schema // empty
          | {"$schema":"http://json-schema.org/draft-04/schema#"} + (resolve($root; 0) | d4($strict; $reqall))
          | {kind:"rule", op:$label, path:$path, when:$when,
             rule:{
               name: "\($api) \($m) \($path) - request schema",
               description: "\($marker) \($m) \($path) body vs JSON Schema, generated from \($src)",
               type: "json-validation",
               methods: [$m],
               configuration: ({
                 scope: "REQUEST_CONTENT",
                 errorMessage: ({error:"Bad request",
                                 message:"Body does not match the request schema of \($label)",
                                 expected:expect} | tojson),
                 schema: tojson,
                 deepCheck: false, validateUnchecked: false, straightRespondMode: false
               } | tojson)
             }}
        ),
        ( if ($op.requestBody // null) != null
             and ((($op.requestBody | resolve($root; 0)).content // {}) | keys | map(test("^application/(.+\\+)?json")) | any | not)
          then {kind:"skip", op:$label, reason:"request body is not JSON (\((($op.requestBody | resolve($root; 0)).content // {}) | keys | join(", "))); use xml-validation by hand"}
          else empty end
        ),
        # --- params: request-validation (opt-in, unverified) -------------------
        ( if $params then
            ([$pathParams[], ($op.parameters // [])[]] | map(resolve($root; 0))
              | map(select(.in == "query" or .in == "header"))
              | map(. as $p
                  | (if $p.in == "query" then "{#request.params[\($sq)\($p.name)\($sq)][0]}"
                     else "{#request.headers[\($sq)\($p.name)\($sq)][0]}" end) as $input
                  | ($p.schema // {}) as $s
                  | [ (if $p.required == true then {input:$input, constraint:{type:"NOT_NULL", parameters:[]}} else empty end),
                      (if $s.enum then {input:$input, constraint:{type:"ENUM", parameters:($s.enum | map(tostring))}} else empty end),
                      (if $s.pattern then {input:$input, constraint:{type:"PATTERN", parameters:[$s.pattern]}} else empty end),
                      (if $s.minimum != null then {input:$input, constraint:{type:"MIN", parameters:[$s.minimum | tostring]}} else empty end),
                      (if $s.maximum != null then {input:$input, constraint:{type:"MAX", parameters:[$s.maximum | tostring]}} else empty end) ][])
              | flatten) as $rv
            | if ($rv | length) > 0 then
                {kind:"rule", op:$label, path:$path, when:$when,
                 rule:{
                   name: "\($api) \($m) \($path) - request params",
                   description: "\($marker) \($m) \($path) query/header params, generated from \($src)",
                   type: $rvtype,
                   methods: [$m],
                   configuration: ({scope:"ON_REQUEST", status:"400", rules:$rv} | tojson)
                 }}
              else empty end
          else empty end
        )
      end
  ' "$spec" > "${dir}/.decisions.jsonl"

  # Write one rule file per generated rule, then the attachment plan.
  local n=0 line file
  while IFS= read -r line; do
    file="${dir}/rules/$(printf '%s' "$line" | jq -r '.rule.name' | tr 'A-Z' 'a-z' | tr -c 'a-z0-9\n' '-' | tr -s '-' | sed 's/-$//').json"
    printf '%s' "$line" | jq '.rule' > "$file"
    n=$((n + 1))
  done < <(jq -c 'select(.kind=="rule")' "${dir}/.decisions.jsonl")
  jq -s '[ .[] | select(.kind=="rule") ]
         | group_by([.path, .when])
         | map({path: .[0].path, appliedWhen: .[0].when, rules: map(.rule.name)})' \
     "${dir}/.decisions.jsonl" > "${dir}/attachments.json"
  {
    printf 'OpenAPI validation plan for %s (from %s)\n' "$api_name" "$spec"
    printf 'strict=%s require-all=%s params=%s appliedWhen=%s\n\n' "$strict" "$reqall" "$params" "$when"
    printf 'Generated rules:\n'
    jq -r 'select(.kind=="rule") | "  \(.op)  ->  \(.rule.type)  \"\(.rule.name)\""' "${dir}/.decisions.jsonl"
    printf '\nSkipped operations:\n'
    jq -r 'select(.kind=="skip") | "  \(.op)  -  \(.reason)"' "${dir}/.decisions.jsonl"
  } > "${dir}/plan.txt"
  rm -f "${dir}/.decisions.jsonl"
  jq -n --arg a "$api_name" --arg s "$src" --argjson st "$strict" --argjson ra "$reqall" --argjson pa "$params" --arg w "$when" \
    '{apiName:$a, source:$s, strict:$st, requireAll:$ra, params:$pa, when:$w}' > "${dir}/meta.json"
  cat "${dir}/plan.txt" >&2
  log_info "plan written to ${dir}/ (${n} rule(s)); review it, then: bash ci-cd/$(basename "$0") apply <deployedApiId> ${dir}"
}

# --- apply -------------------------------------------------------------------
oas_apply() {
  local api_id="${1:-}" dir="${2:-}"; shift 2 || true
  [ -n "$api_id" ] && [ -d "$dir" ] || die "apply needs: <deployedApiId> <planDir> [--dry-run] [--adopt] [--prune]"
  local dry=false prune=false adopt=false
  while [ "$#" -gt 0 ]; do
    case "$1" in --dry-run) dry=true ;; --prune) prune=true ;; --adopt) adopt=true ;; *) die "unknown apply option: $1" ;; esac
    shift
  done
  [ -f "${dir}/attachments.json" ] && [ -f "${dir}/meta.json" ] || die "${dir} is not a plan directory (run plan first)"
  local api_name; api_name="$(jq -r '.apiName' "${dir}/meta.json")"
  local bad; bad="$(jq -r --arg re "$SAFE_PATH_RE" '.[] | select(.path | test($re) | not) | .path' "${dir}/attachments.json")"
  [ -z "$bad" ] || die "refusing unsafe attachment path(s): ${bad} (would risk a 500 on the whole API)"
  load_env
  local P="${HERE}/gateway-policy.sh" tmp; tmp="$(mktemp -d)"
  trap 'rm -rf "$tmp"' RETURN

  # 1. Upsert rules by name (idempotent re-runs).
  bash "$P" list > "${tmp}/rules.json"
  echo '{}' > "${tmp}/ids.json"
  local f name id action
  for f in "${dir}"/rules/*.json; do
    [ -f "$f" ] || continue
    name="$(jq -r '.name' "$f")"
    id="$(jq -r --arg n "$name" '[.deployedApiPolicyRules[] | select(.name==$n) | .id][0] // empty' "${tmp}/rules.json")"
    if [ -n "$id" ]; then
      # DeployedApiPolicyRuleInput has no `type` (a rule's type can't change in place)
      action=update; jq --arg id "$id" 'del(.type) + {id:$id}' "$f" > "${tmp}/in.json"
    else
      action=create; cp "$f" "${tmp}/in.json"
    fi
    if $dry; then
      log_info "[dry-run] would ${action} rule \"${name}\"${id:+ (${id})}"
      [ -n "$id" ] || id="<new:${name}>"
    else
      local out; out="$(bash "$P" "$action" "${tmp}/in.json")"
      id="$(printf '%s' "$out" | jq -r '(.deployedApiPolicyRuleCreate // .deployedApiPolicyRuleUpdate).id')"
      [ -n "$id" ] && [ "$id" != null ] || die "no id returned for rule \"${name}\""
      log_info "${action}d rule \"${name}\" (${id})"
    fi
    jq --arg n "$name" --arg id "$id" '. + {($n): $id}' "${tmp}/ids.json" > "${tmp}/ids2.json" && mv "${tmp}/ids2.json" "${tmp}/ids.json"
  done

  # 2. Merge: keep every non-managed attachment, replace the managed ones.
  bash "$P" attached "$api_id" > "${tmp}/current.json"
  local managed; managed="$(jq -c --arg m "$MARKER" '[.deployedApiPolicyRules[] | select((.description // "") | startswith($m)) | .id]' "${tmp}/rules.json")"
  # Unmanaged validation rules already attached on planned paths: adopted (--adopt) or reported.
  local vtypes; vtypes="$(jq -cn --arg rv "$REQUEST_VALIDATION_TYPE" '["json-validation", $rv, "request-validation"]')"
  local overlap; overlap="$(jq -r --slurpfile plan "${dir}/attachments.json" --argjson managed "$managed" --argjson vt "$vtypes" '
    ($plan[0] | map(.path)) as $pp
    | .deployedApi.customPolicies[]? | select(.path as $p | $pp | index($p)) | .path as $p
    | .rules[] | select((.id as $i | $managed | index($i) | not) and (.type as $t | $vt | index($t)))
    | "\($p)\t\(.id)\t\(.name)"' "${tmp}/current.json")"
  if [ -n "$overlap" ]; then
    if $adopt; then
      log_warn "--adopt: detaching hand-made validation rules on planned paths:"
    else
      log_warn "hand-made validation rules already on planned paths (kept; requests are validated twice; use --adopt to replace them):"
    fi
    printf '%s\n' "$overlap" | sed 's/^/    /' >&2
  fi
  jq -n --slurpfile cur "${tmp}/current.json" --slurpfile plan "${dir}/attachments.json" \
        --slurpfile ids "${tmp}/ids.json" --argjson managed "$managed" \
        --argjson adopt "$adopt" --argjson vt "$vtypes" '
    ($ids[0]) as $ids
    | ($plan[0] | map(.path)) as $pp
    | ([ $cur[0].deployedApi.customPolicies[]?
         | .path as $p
         | {path, appliedWhen: .when,
            rules: [.rules[]
                    | select(.id as $r | ($managed | index($r)) | not)
                    | select(($adopt and ($pp | index($p)) and (.type as $t | $vt | index($t))) | not)
                    | .id]}
         | select(.rules | length > 0) ]) as $kept
    | ([ $plan[0][] | {path, appliedWhen, rules: [.rules[] | $ids[.]]} ]) as $gen
    # generated validation first (it should reject bad input before e.g. a cache answers),
    # then the kept rules in their existing order; group_by is stable, dedupe keeps order
    | ($gen + $kept) | group_by([.path, .appliedWhen])
    | map({path: .[0].path, appliedWhen: .[0].appliedWhen,
           rules: (reduce (map(.rules[])[]) as $r ([]; if index($r) then . else . + [$r] end))})
  ' > "${tmp}/custompolicies.json"

  log_info "current custom policies on ${api_id}:"
  jq -c '.deployedApi.customPolicies[]? | {path, when, rules: [.rules[].name]}' "${tmp}/current.json" >&2
  log_info "new custom policies:"
  jq -c '.[] | {path, appliedWhen, rules}' "${tmp}/custompolicies.json" >&2

  if $dry; then
    log_info "[dry-run] no changes made"
  else
    bash "$P" set-policies "$api_id" "${tmp}/custompolicies.json" >/dev/null
    log_info "custom policies replaced; readback:"
    bash "$P" attached "$api_id" | jq -c '.deployedApi.customPolicies[] | {path, when, rules: [.rules[].name]}' >&2
  fi

  # 3. Managed rules that are no longer referenced by the plan.
  local stale; stale="$(jq -r --slurpfile ids "${tmp}/ids.json" --arg m "$MARKER" --arg api "$api_name " '
    ($ids[0] | [.[]]) as $keep
    | .deployedApiPolicyRules[] | select((.description // "") | startswith($m))
    | select(.name | startswith($api))
    | select(.id as $i | ($keep | index($i)) | not) | "\(.id)\t\(.name)"' "${tmp}/rules.json")"
  if [ -n "$stale" ]; then
    if $prune && ! $dry; then
      printf '%s\n' "$stale" | while IFS=$'\t' read -r id name; do
        bash "$P" delete "$id" >/dev/null && log_info "pruned stale rule \"${name}\" (${id})" \
          || log_warn "could not delete \"${name}\" (${id}); still attached to another API?"
      done
    else
      log_warn "managed rules of \"${api_name}\" no longer in the plan (--prune deletes them):"
      printf '%s\n' "$stale" | sed 's/^/    /' >&2
    fi
  fi
}

case "${1:-}" in
  fetch) shift; oas_fetch "$@" ;;
  plan)  shift; oas_plan "$@" ;;
  apply) shift; oas_apply "$@" ;;
  -h|--help|help|"") usage; [ -n "${1:-}" ] || exit 2 ;;
  *) log_err "unknown action '${1}'"; usage >&2; exit 2 ;;
esac
