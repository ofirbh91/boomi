#!/usr/bin/env bash
# Copyright (c) Anthony Rabiaza 2026-10-14
# Updated 2026-10-19
# ci-cd/gateway-tracing-enable.sh - Plane B accelerator: start an Advanced tracing
# session on one deployed API (API Service or API Proxy).
#
#   <deployedApiId> [minutes] [--no-body] [--no-headers] [--no-policy-config]
#
# Advanced tracing splits each policy span into <policy>.request / .response sub-spans
# with headers and policy configuration, and adds body previews on the backend spans
# (gravitee.backend.request.body.preview on gateway.backend.request,
# gravitee.backend.response.body.preview on gateway.backend.response).
#
# Wraps deployedApiUpdate with tracing.advanced. The session ends on its own at
# expiresAt (now + minutes, default 60, at most 239: Boomi rejects longer sessions with
# MAX_DURATION_EXCEEDED); running this again extends it. Stop it early
# with gateway-tracing-disable.sh. Takes effect on the gateway without a redeploy.
# Needs OpenTelemetry tracing enabled on the gateway itself.
#
# Bodies are captured UNMASKED; keep sessions short on APIs carrying personal data.
#
# e.g.  bash ci-cd/gateway-tracing-enable.sh 59ab7eeb-85da-4df9-9344-69572f3372a2
#       bash ci-cd/gateway-tracing-enable.sh 59ab7eeb-85da-4df9-9344-69572f3372a2 15 --no-headers

set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "${HERE}/lib/common.sh"
. "${HERE}/config.sh"
. "${HERE}/lib/gateway.sh"
load_env

ENABLE='mutation ($in: DeployedApiInput!) {
  deployedApiUpdate(deployedApi: $in) {
    id component { name } environment { name }
    tracing { tracingMode advanced { expiresAt captureBody captureHeaders capturePolicyConfig } }
  } }'

usage() {
  cat <<EOF
Usage: bash ci-cd/gateway-tracing-enable.sh <deployedApiId> [minutes] [options]

  <deployedApiId>      deployed API to trace (find it with: bash ci-cd/gateway-api.sh list)
  [minutes]            session length, default 60, max 239 (Boomi's 3h59m cap);
                       running again extends the session

Options (all captures are on by default):
  --no-body            don't capture request/response body previews
  --no-headers         don't capture HTTP headers
  --no-policy-config   don't capture policy configurations

Stop early with: bash ci-cd/gateway-tracing-disable.sh <deployedApiId>
Check the state: bash ci-cd/gateway-api.sh get <deployedApiId>
EOF
}

body=true headers=true policy_config=true pos=()
for arg in "$@"; do
  case "$arg" in
    -h|--help|help)     usage; exit 0 ;;
    --no-body)          body=false ;;
    --no-headers)       headers=false ;;
    --no-policy-config) policy_config=false ;;
    -*)                 log_err "unknown option '${arg}'"; usage >&2; exit 2 ;;
    *)                  pos+=("$arg") ;;
  esac
done
# ${pos[@]+...} - safe empty-array expansion under `set -u` (bash 3.2)
set -- ${pos[@]+"${pos[@]}"}
[ "$#" -ge 1 ] && [ "$#" -le 2 ] || { usage >&2; exit 2; }
api_id="$1" minutes="${2:-60}"
case "$minutes" in ''|*[!0-9]*|0) die "minutes must be a positive whole number, got '${minutes}'" ;; esac
[ "$minutes" -le 239 ] || die "minutes must be at most 239: Boomi caps an Advanced session at 3h59m (got ${minutes})"

# jq computes the UTC end time, so this works with both BSD (macOS) and GNU date.
expires="$(jq -rn --argjson m "$minutes" 'now + ($m * 60) | floor | strftime("%Y-%m-%dT%H:%M:%SZ")')"

log_warn "enable Advanced tracing on deployedApi ${api_id} until ${expires} (body=${body}, headers=${headers}, policyConfig=${policy_config})"
APIM_GRAPHQL_VARS="$(jq -cn --arg id "$api_id" --arg exp "$expires" \
  --argjson body "$body" --argjson headers "$headers" --argjson pc "$policy_config" \
  '{in:{id:$id, tracing:{advanced:{expiresAt:$exp, captureBody:$body, captureHeaders:$headers, capturePolicyConfig:$pc}}}}')" \
  apim_graphql - ".data.deployedApiUpdate" <<GQL
${ENABLE}
GQL
