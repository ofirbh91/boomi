#!/usr/bin/env bash
# Copyright (c) Anthony Rabiaza 2026-09-08
# Updated 2026-10-14
# ci-cd/gateway-api.sh - Plane B accelerator: Deployed APIs (+ gateways / environments).
# Read-focused discovery: find the deployed-API / gateway / environment IDs that
# the other gateway-*.sh scripts need as inputs. All read-only and safe to run.
#
#   list                    list deployed APIs (id, version, component, env)
#   get <id>                full detail for one deployed API (incl. tracing state)
#   gateways                list API Gateways (id, name, type, public URL)
#   environments            list environments (id, name, classification)
#
# e.g.  bash ci-cd/gateway-api.sh list
#       bash ci-cd/gateway-api.sh get 251c8944-c5ff-6ea8-d74c-e8854603a215

set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "${HERE}/lib/common.sh"
. "${HERE}/config.sh"
. "${HERE}/lib/gateway.sh"
load_env

LIST='query { deployedApis { id version component { name } environment { name } } }'
GET='query ($id: ID!) { deployedApi(id: $id) {
  id version customPolicyPathMode
  component { name } environment { name }
  tracing { tracingMode advanced { expiresAt captureBody captureHeaders capturePolicyConfig } }
} }'
GATEWAYS='query { gateways { id name gatewayType effectivePublicUrl externalUrl } }'
ENVIRONMENTS='query { environments { id name classification publishedName } }'

usage() {
  cat <<EOF
Usage: bash ci-cd/gateway-api.sh <action> [arg]

  list          list deployed APIs (id, version, component, environment)
  get <id>      show one deployed API's detail
  gateways      list API Gateways (id, name, type, public URL)
  environments  list environments (id, name, classification)

Use 'list' / 'gateways' / 'environments' to discover the IDs the other
gateway-*.sh scripts (gateway-policy, gateway-plan, gateway-application, gateway-authsource) need.
EOF
}

if [ "$#" -eq 0 ]; then usage >&2; exit 2; fi
case "$1" in
  list)         log_info "list deployed APIs";  gw_run "$LIST" ;;
  get)          [ -n "${2:-}" ] || { usage >&2; exit 2; }; log_info "get deployed API ${2}"; gw_get "$GET" "$2" ;;
  gateways)     log_info "list gateways";       gw_run "$GATEWAYS" ;;
  environments) log_info "list environments";   gw_run "$ENVIRONMENTS" ;;
  -h|--help|help) usage ;;
  *) log_err "unknown action '${1}'"; usage >&2; exit 2 ;;
esac
