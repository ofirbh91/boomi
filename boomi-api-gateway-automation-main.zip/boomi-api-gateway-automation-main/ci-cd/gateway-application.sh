#!/usr/bin/env bash
# Copyright (c) Anthony Rabiaza 2026-09-08
# Updated 2026-09-08
# ci-cd/gateway-application.sh - Plane B accelerator: Applications (consumers / API keys).
# Wraps deployedApiApplication* GraphQL operations.
#
#   list                    list all applications
#   get <id>                one application
#   create <input.json>     create an application (DeployedApiApplicationCreateInput)
#   update <input.json>     update an application (DeployedApiApplicationUpdateInput, needs id)
#   delete <id>             delete an application
#
# input.json example:
#   { "name": "Partner X app", "status": "ENABLED",
#     "ownerName": "Jane Doe", "ownerEmail": "jane@example.com", "companyName": "X Inc" }

set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "${HERE}/lib/common.sh"
. "${HERE}/config.sh"
. "${HERE}/lib/gateway.sh"
load_env

FIELDS='id name status ownerName ownerUserName ownerEmail contactPhone companyName companyWebsite description'
LIST="query { deployedApiApplications { ${FIELDS} } }"
GET="query (\$id: ID!) { deployedApiApplication(id: \$id) { ${FIELDS} } }"
CREATE='mutation ($in: DeployedApiApplicationCreateInput!) {
  deployedApiApplicationCreate(deployedApiApplication: $in) { id name status } }'
UPDATE='mutation ($in: DeployedApiApplicationUpdateInput!) {
  deployedApiApplicationUpdate(deployedApiApplication: $in) { id name status } }'
# Delete takes arg name deployedApiApplicationId; bind our $id variable to it.
DELETE='mutation ($id: ID!) { deployedApiApplicationDelete(deployedApiApplicationId: $id) }'

gw_dispatch "application" "$LIST" "$GET" "$CREATE" "$UPDATE" "$DELETE" "$@"
