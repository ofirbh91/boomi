#!/usr/bin/env bash
# Copyright (c) Anthony Rabiaza 2026-09-08
# Updated 2026-09-08
# ci-cd/gateway-authsource.sh - Plane B accelerator: Authentication Sources (JWT).
# Wraps authSource* GraphQL operations. Create/update target JWT auth sources
# (authSourceJWTCreate / authSourceJWTUpdate); delete is type-agnostic.
#
#   list                    list all auth sources
#   get <id>                one auth source
#   create <input.json>     create a JWT auth source (AuthSourceJWTCreateInput)
#   update <input.json>     update a JWT auth source (AuthSourceJWTUpdateInput, needs id)
#   delete <id>             delete an auth source
#
# input.json example:
#   { "name": "Partner IdP", "issuer": "https://idp.example.com/",
#     "details": { ... } }        # AuthSourceJWTDetailsInput

set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "${HERE}/lib/common.sh"
. "${HERE}/config.sh"
. "${HERE}/lib/gateway.sh"
load_env

# AuthSource is a GraphQL interface; the rich fields live on the concrete
# subtypes (JWT / Basic / Broker / OpenID / SAML). get uses inline fragments to
# surface all of them; list stays light but shows __typename so you see the kind.
LIST='query { authSources { __typename id name description } }'
GET='query ($id: ID!) {
  authSource(id: $id) {
    __typename
    id
    name
    description
    roles { id name description }
    ... on AuthSourceJWT {
      issuer jwksUrl audiences groupsAttribute userIdClaim
      issuerError { code detail }
    }
    ... on AuthSourceBasic {
      users { id name enabled }
      groups { id name description }
    }
    ... on AuthSourceBasicBroker {
      brokerId redirectUris
      users { id name enabled }
      groups { id name description }
    }
    ... on AuthSourceOpenID {
      alias brokerId redirectUris issuer clientId clientSecret
      authUrl tokenUrl logoutUrl userInfoUrl
      defaultScopes promptType groupsAttribute
      standardFlowEnabled implicitFlowEnabled
    }
    ... on AuthSourceSAML {
      alias brokerId redirectUris
      singleSignOnServiceUrl singleLogoutServiceUrl nameIdPolicyFormat
      httpPostBindingResponse httpPostBindingRequest
      signAuthenticationRequests forceAuthentication groupsAttribute
    }
  }
}'
CREATE='mutation ($in: AuthSourceJWTCreateInput!) { authSourceJWTCreate(authSourceJWT: $in) { id name } }'
UPDATE='mutation ($in: AuthSourceJWTUpdateInput!) { authSourceJWTUpdate(authSourceJWT: $in) { id name } }'
DELETE='mutation ($id: ID!) { authSourceDelete(id: $id) }'

gw_dispatch "auth source" "$LIST" "$GET" "$CREATE" "$UPDATE" "$DELETE" "$@"
