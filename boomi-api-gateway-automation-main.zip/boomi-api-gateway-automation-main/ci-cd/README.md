# CI/CD Pipeline (`ci-cd/`)

Portable bash pipeline for the Boomi API Gateway. CI-system agnostic - call these scripts
from GitHub Actions, GitLab CI, Jenkins, or a laptop. No YAML lock-in.

## Two planes

- **Plane A (build/deploy)** - wraps the bundled `boomi-*.sh` CLI scripts (AtomSphere REST API)
  to push, package, and deploy components.
- **Plane B (governance)** - talks to the APIM **GraphQL** API (`https://api.boomi.com/graphql`)
  to apply policies, plans, and applications to *deployed* APIs.

## Prerequisites

- `.env` at the project root with `BOOMI_USERNAME`, `BOOMI_API_TOKEN`, `BOOMI_ACCOUNT_ID`,
  and `BOOMI_ENVIRONMENT_ID` (or stage-specific `BOOMI_ENVIRONMENT_ID_DEV/TEST/PROD`).
- `curl` + `jq`.
- The `boomi-*.sh` helper scripts are bundled under `vendor/boomi-integration` (no external
  install). Override their location with `SKILL_PATH` only if you keep them elsewhere.

## Configure

Edit `ci-cd/config.sh`:
- `DEPLOYABLES` - component XML paths to package + deploy (in order).
- `BUILD_GLOBS` - dirs whose component XML gets pushed at build time.
- stage → environment mapping via `BOOMI_ENVIRONMENT_ID_<STAGE>` in `.env`.
- `VERIFY_PATH` / `VERIFY_EXPECT_CODE` - smoke-test target.

## Run

```bash
# Preflight: check auth + connectivity to BOTH API planes (read-only, safe):
bash ci-cd/00-check.sh

# Validate GraphQL connectivity + list deployed APIs (read-only, safe):
bash ci-cd/40-govern.sh --check

# Individual stages:
bash ci-cd/00-check.sh                 # preflight connectivity + auth check
bash ci-cd/10-build.sh                 # push components (design-time)
bash ci-cd/20-deploy.sh dev            # package + deploy to DEV env
bash ci-cd/30-extensions.sh dev        # apply DEV environment extensions
bash ci-cd/40-govern.sh                # apply gateway policies/plans/apps
bash ci-cd/50-verify.sh                # smoke-test the live route

# Full pipeline for a stage:
bash ci-cd/pipeline.sh dev
bash ci-cd/pipeline.sh test
bash ci-cd/pipeline.sh prod

# Governance only (re-apply policies without redeploying):
bash ci-cd/pipeline.sh prod --govern-only
```

## Plane A accelerators (`api-proxy.sh`)

Imperative one-liners over the AtomSphere REST API for API Proxy components (Boomi
type `webservice.external`): a proxy publishes a base path and delegates traffic to a
backend endpoint URL.

```bash
# Discovery (read-only, safe):
bash ci-cd/api-proxy.sh list                 # all API Proxies (id, name, version, folder)
bash ci-cd/api-proxy.sh get <componentId>    # one proxy: base path + backend delegate URL
bash ci-cd/api-proxy.sh get <componentId> --raw   # full component XML

# Create a new proxy (writes components/api-proxy/<name>.xml, then creates it):
bash ci-cd/api-proxy.sh create "Orders Proxy" \
  --base-path orders/v1 \
  --target-url https://api.internal.example.com \
  --folder "MyAccount/API Proxies"
```

`create` requires `--base-path` and `--target-url`; the folder can come from `--folder`
(a full path, a bare name, or a folder ID - resolved to a folder ID, since the Component
API honors `folderId` only, not `folderFullPath`), `--folder-id`, or an `API_PROXY_FOLDER`
value in `.env`. Optional flags: `--api-type`, `--title`,
`--api-version`, `--description`, `--swagger <file>` (publish an OpenAPI/Swagger spec -
gzip+base64 embedded into the component, the same encoding the UI uses),
`--health-check-url`, `--branch`, `--no-create` (write the XML only), `--force` (overwrite
an existing file). The new component is tracked in sync state and picked up by
`10-build.sh`; add its path to `DEPLOYABLES` in `config.sh` to deploy it. See
`bash ci-cd/api-proxy.sh --help` for the full list.

Delegate/endpoint settings (matching the UI): `--http-version 1.1|2` (`http2Protocol`);
`--auth-type none|basic|pass-through`; for Basic Auth, `--basic-user`/`--basic-password`
(the password is sent in plaintext and encrypted by the platform on create);
`--forward-auth-header true|false` and `--remove-original-auth true|false` (default per
auth type); and custom headers via `--header "Key: Value"` and `--header-encrypted
"Key: Value"` (both repeatable). Note: the API stores an encrypted-flagged header's value
as given - the `encrypted` flag is set but the value is not auto-encrypted (only a Basic
Auth password is).

```bash
# With an OpenAPI spec and a health-check URL:
bash ci-cd/api-proxy.sh create "Orders Proxy" \
  --base-path orders/v1 --target-url https://api.internal.example.com \
  --swagger ./openapi/orders.yaml \
  --health-check-url https://api.internal.example.com/health \
  --folder "MyAccount/API Proxies"

# HTTP/2, Basic Auth, and custom headers:
bash ci-cd/api-proxy.sh create "Partner Proxy" \
  --base-path partner/v1 --target-url https://partner.internal.example.com \
  --http-version 2 \
  --auth-type basic --basic-user svcacct --basic-password 's3cret' \
  --header "X-Env: prod" --header-encrypted "X-Api-Key: shhh" \
  --folder-id Rjo4Nzc5MjY0
```

## Plane B accelerators (`gateway-*.sh`)

Imperative one-liners over the APIM GraphQL API - the fast way to discover IDs and make
one-off gateway changes without hand-writing GraphQL. Each script prints its actions with
`--help`.

```bash
# Discovery (read-only, safe) - start here to find IDs the other scripts need:
bash ci-cd/gateway-api.sh list                 # deployed APIs (id, version, component, env)
bash ci-cd/gateway-api.sh get <deployedApiId>  # one API's detail, incl. tracing state
bash ci-cd/gateway-api.sh gateways             # API Gateways (id, name, type, public URL)
bash ci-cd/gateway-api.sh environments         # environments (id, name, classification)

# Governance elements - list | get <id> | create <f> | update <f> | delete <id>:
bash ci-cd/gateway-policy.sh list
bash ci-cd/gateway-plan.sh list
bash ci-cd/gateway-application.sh list
bash ci-cd/gateway-authsource.sh list
bash ci-cd/gateway-subscription.sh list             # app ↔ API ↔ plan links + API keys

# Create/update take a JSON file that IS the GraphQL input object:
bash ci-cd/gateway-plan.sh create my-plan.json     # DeployedApiPlanCreateInput
bash ci-cd/gateway-policy.sh update my-rule.json    # DeployedApiPolicyRuleInput (must include id)
bash ci-cd/gateway-application.sh delete <appId>
```

### Recipe: add an API to an application and get its API key

"Adding an API to an application" means creating a **subscription** that links an
application + a deployed API + a plan. The subscription's `apiKeyId` **is** the API key the
consumer sends (e.g. as the `x-api-key` header).

```bash
# 1. Collect the three ids:
bash ci-cd/gateway-application.sh list                 # → applicationId
bash ci-cd/gateway-api.sh list                         # → deployedApiId
bash ci-cd/gateway-api.sh get <deployedApiId>          # shows that API's plans → planId
#    (or: bash ci-cd/gateway-plan.sh list)

# 2. Fill them into the input file, then create the subscription:
cp ci-cd/examples/subscription/subscribe.json /tmp/sub.json   # edit the 3 ids
bash ci-cd/gateway-subscription.sh create /tmp/sub.json
#    → the response's "apiKeyId" is the API key

# 3. Inspect or rotate later:
bash ci-cd/gateway-subscription.sh list <applicationId>       # all keys for that app
bash ci-cd/gateway-subscription.sh get <apiKeyId>             # one subscription
bash ci-cd/gateway-subscription.sh regenerate <apiKeyId>      # issue a new key
```

Each script's header comment documents its input shape (`create`/`update`) with an example.
Use these to explore and author, then capture the final mutation as a `gateway/*.graphql`
manifest (below) for repeatable, version-controlled promotion via `40-govern.sh`.

### Recipe: generate validation policies from an OpenAPI

The gateway can't enforce an OpenAPI file, so `gateway-oas-validation.sh` translates it into
`json-validation` rules (one per JSON request body) and attaches them per route. Full guide:
[docs/openapi-validation.md](../docs/openapi-validation.md).

```bash
bash ci-cd/gateway-oas-validation.sh plan gateway/openapi/dummy-api.openapi.json gateway/validation/dummy-api
bash ci-cd/gateway-oas-validation.sh apply <deployedApiId> gateway/validation/dummy-api --dry-run
bash ci-cd/gateway-oas-validation.sh apply <deployedApiId> gateway/validation/dummy-api --adopt --prune
```

To run it from the pipeline, add `"<deployedApiId>|<openapi.json>|<plan opts>|<apply opts>"`
to `OAS_VALIDATION` in `config.sh`; `40-govern.sh` applies it and `40-govern.sh --check`
dry-runs it.

### Recipe: capture headers and payloads on the gateway (Advanced tracing)

An Advanced tracing session makes the gateway record headers, policy configuration and
request/response body previews in its traces, for one deployed API (API Service or API
Proxy). It ends on its own; the gateway picks the change up without a redeploy. Bodies are
captured unmasked, so keep sessions short.

```bash
bash ci-cd/gateway-tracing-enable.sh  <deployedApiId>              # 60 minutes, everything captured
bash ci-cd/gateway-tracing-enable.sh  <deployedApiId> 15 --no-headers
bash ci-cd/gateway-tracing-disable.sh <deployedApiId>              # stop early
bash ci-cd/gateway-api.sh get <deployedApiId>                      # tracing.advanced.expiresAt
```

The bodies are span attributes `gravitee.backend.request.body.preview` (span
`gateway.backend.request`) and `gravitee.backend.response.body.preview` (span
`gateway.backend.response`). Find them in Tempo with
`{ span.gravitee.backend.request.body.preview != nil }`. A session lasts at most 239 minutes
(longer is rejected with `MAX_DURATION_EXCEEDED`); run `enable` again to extend it.

### Recipe: follow one call end to end (one id)

The gateway honours a caller's W3C `traceparent` and keeps a caller's
`X-Gateway-Transaction-Id`, so one value can find the call everywhere. Send the same id in both:

```bash
T=$(openssl rand -hex 16)                                   # 32-hex trace id
curl -i -X POST "https://<gateway>/ws/rest/dummy/add" \
  -H "x-api-key: <key>" -H 'Content-Type: application/json' \
  -H "traceparent: 00-${T}-$(openssl rand -hex 8)-01" \
  -H "X-Gateway-Transaction-Id: ${T}" \
  --data '{"number1": 2, "number2": 3}'
# response: x-gateway-transaction-id: G:<T>, x-global-uid: <runtime execution id>
# (a gateway rejection, e.g. a 400 from validation, returns no id header)
```

Then:
- **Trace:** open trace id `$T` in Tempo (gateway and runtime spans), or TraceQL
  `{ span.execution.id = "<x-global-uid>" }`.
- **Boomi call log** (status, URL, top-level execution id; rejections included):

```bash
APIM_GRAPHQL_VARS='{"in":{"requestTsStart":"2026-10-15T02:25:00Z","requestTsEnd":"2026-10-15T02:30:00Z","rowLimit":50}}' \
bash -c 'source ci-cd/lib/common.sh && load_env && echo "query(\$in: DeployedApiCallDetailInput!) {
  deployedApiCallDetail(input: \$in) { data { requestTs transactionId status requestUrl execution { id } } } }" \
  | apim_graphql - ".data.deployedApiCallDetail.data[]"' | jq -c 'select(.transactionId == "G:<T>")'
```

## Authoring gateway policies (Plane B)

Each `*.graphql` file under `gateway/{policies,plans,applications}` is a GraphQL mutation
document; an optional sibling `<name>.vars.json` supplies its variables. Files apply in
lexical order - prefix with `10-`, `20-` to sequence. `.example` files are templates: copy,
drop the `.example` suffix, and set the real field names/IDs.

**Get the exact mutation shapes** from your account's GraphQL API reference UI
(*Services → API Management → GraphQL*), or introspect a type:

```bash
set -a && . ./.env && set +a
curl -sS -u "BOOMI_TOKEN.${BOOMI_USERNAME}:${BOOMI_API_TOKEN}" \
  -H "X-Account: ${BOOMI_ACCOUNT_ID}" -H 'Content-Type: application/json' \
  --data '{"query":"query{__type(name:\"DeployedApi\"){fields{name type{name kind ofType{name}}}}}"}' \
  https://api.boomi.com/graphql | jq .
```

Find a deployed API's `id` (needed as a mutation variable) with `bash ci-cd/40-govern.sh --check`.
