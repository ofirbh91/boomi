#!/usr/bin/env bash
# Copyright (c) Anthony Rabiaza 2026-09-08
# Updated 2026-09-08
# ci-cd/gateway-plan.sh - Plane B accelerator: Subscription Plans (consumer tiers).
# Wraps deployedApiPlan* GraphQL operations (Bronze/Silver/Gold style limits).
#
#   list                    list all plans
#   get <id>                one plan with its limits
#   create <input.json>     create a plan (DeployedApiPlanCreateInput)
#   update <input.json>     update a plan (DeployedApiPlanUpdateInput, needs id)
#   delete <id>             delete a plan
#
# Period enums: SECOND | MIN | HOUR | DAY | WEEK | MONTH
# input.json example (see ci-cd/examples/plan/gold.json):
#   { "name": "Gold", "description": "High tier",
#     "rateLimit": 1000, "rateLimitPeriod": "MIN",
#     "quotaLimit": 1000000, "quotaLimitPeriod": "MONTH", "maxMessageSize": 100 }

set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "${HERE}/lib/common.sh"
. "${HERE}/config.sh"
. "${HERE}/lib/gateway.sh"
load_env

FIELDS='id name description status maxMessageSize rateLimit rateLimitPeriod quotaLimit quotaLimitPeriod applicationCount'
LIST="query { deployedApiPlans { ${FIELDS} } }"
GET="query (\$id: ID!) { deployedApiPlan(id: \$id) { ${FIELDS} } }"
CREATE='mutation ($in: DeployedApiPlanCreateInput!) { deployedApiPlanCreate(createPlan: $in) { id name } }'
UPDATE='mutation ($in: DeployedApiPlanUpdateInput!) { deployedApiPlanUpdate(deployedApiPlan: $in) { id name } }'
DELETE='mutation ($id: ID!) { deployedApiPlanDelete(id: $id) }'

gw_dispatch "plan" "$LIST" "$GET" "$CREATE" "$UPDATE" "$DELETE" "$@"
