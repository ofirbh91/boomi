#!/usr/bin/env bash
# Copyright (c) Anthony Rabiaza 2026-09-08
# Updated 2026-09-08
# ci-cd/pipeline.sh <stage> [--skip-verify] [--govern-only] [--check]
# Orchestrates the full Boomi API Gateway CI/CD pipeline for one stage.
#
#   stage           dev | test | prod   (default: dev)
#   --check         only run APIM GraphQL connectivity check, then exit
#   --govern-only   only run governance (Plane B), skip build/deploy
#   --skip-verify   skip the final smoke test
#
# Order: 00 check → 10 build → 20 deploy → 30 extensions → 40 govern → 50 verify.

set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "${HERE}/lib/common.sh"

STAGE="dev"; SKIP_VERIFY=false; GOVERN_ONLY=false; CHECK_ONLY=false
for a in "$@"; do
  case "$a" in
    --check)       CHECK_ONLY=true ;;
    --govern-only) GOVERN_ONLY=true ;;
    --skip-verify) SKIP_VERIFY=true ;;
    dev|test|prod) STAGE="$a" ;;
    *) die "unknown arg: $a" ;;
  esac
done

if $CHECK_ONLY; then
  bash "${HERE}/40-govern.sh" --check
  exit $?
fi

log_info "===== Pipeline start: stage=${STAGE} ====="

bash "${HERE}/00-check.sh"

if ! $GOVERN_ONLY; then
  bash "${HERE}/10-build.sh"
  bash "${HERE}/20-deploy.sh" "$STAGE"
  bash "${HERE}/30-extensions.sh" "$STAGE"
fi

bash "${HERE}/40-govern.sh"

if ! $SKIP_VERIFY; then
  bash "${HERE}/50-verify.sh" || log_warn "verify failed - review before promoting ${STAGE}"
fi

log_info "===== Pipeline complete: stage=${STAGE} ====="
