#!/usr/bin/env bash
# Copyright (c) Anthony Rabiaza 2026-09-08
# Updated 2026-09-08
# ci-cd/30-extensions.sh <stage> - Plane A environment extensions.
# Applies per-stage extension VALUES (URLs, credentials, connection overrides)
# to the stage's environment. Extension DECLARATIONS live in the component XML
# (<bns:processOverrides>) and are pushed at build time; this only sets values.
# boomi-extensions.sh auto-snapshots current values before every write.

set -euo pipefail
STAGE="${1:-dev}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib/common.sh
. "${HERE}/lib/common.sh"
# shellcheck source=config.sh
. "${HERE}/config.sh"
load_env

env_id="$(env_id_for_stage "$STAGE")"
[ -n "$env_id" ] || die "No environment ID for stage '${STAGE}'."
ext_file="$(extensions_file_for_stage "$STAGE")"

if [ ! -f "$ext_file" ]; then
  log_warn "No extensions file for stage '${STAGE}' (${ext_file}) - skipping."
  exit 0
fi

log_info "Applying extensions stage=${STAGE} → environment ${env_id}"
export BOOMI_ENVIRONMENT_ID="$env_id"
boomi extensions set --file "$ext_file"
log_info "Extensions applied for stage=${STAGE}."
