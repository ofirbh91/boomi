#!/usr/bin/env bash
# Copyright (c) Anthony Rabiaza 2026-09-08
# Updated 2026-09-08
# ci-cd/lib/gateway.sh - Plane B (APIM GraphQL) accelerator primitives.
# Sourced by the ci-cd/gateway-*.sh element scripts AFTER lib/common.sh + config.sh.
# Not meant to be run directly.
#
# These wrap the apim_graphql client (common.sh) so each element script only has
# to declare its GraphQL documents. Operation and argument names follow the APIM
# GraphQL schema.
#
# Primitives:
#   gw_run    <doc> [jq-filter]            - run a query/mutation with no variables
#   gw_get    <doc> <id> [jq-filter]       - run with variable $id (from a string)
#   gw_delete <doc> <id> [jq-filter]       - alias of gw_get, named for intent
#   gw_mutate <doc> <input-json-file> [jq] - run with variable $in = file contents

# Run a GraphQL document that needs no variables.
gw_run() {
  local doc="$1" filter="${2:-.data}"
  apim_graphql - "$filter" <<GQL
${doc}
GQL
}

# Run a document that takes a single ID variable named \$id.
gw_get() {
  local doc="$1" id="$2" filter="${3:-.data}"
  [ -n "$id" ] || die "id required"
  APIM_GRAPHQL_VARS="$(jq -cn --arg id "$id" '{id:$id}')" \
    apim_graphql - "$filter" <<GQL
${doc}
GQL
}

# Same as gw_get; separate name so delete call sites read clearly.
gw_delete() { gw_get "$@"; }

# Run a create/update mutation. The user-supplied JSON file IS the input object;
# we bind it to the document's \$in variable. Keeps the CLI "just write the input".
gw_mutate() {
  local doc="$1" file="$2" filter="${3:-.data}"
  [ -f "$file" ] || die "input JSON not found: $file"
  jq -e . "$file" >/dev/null 2>&1 || die "invalid JSON: $file"
  APIM_GRAPHQL_VARS="$(jq -c '{in: .}' "$file")" \
    apim_graphql - "$filter" <<GQL
${doc}
GQL
}

# Print usage for a full CRUD element script. Goes to stdout so `--help` can be
# piped; callers send exit code separately.
gw_usage() {
  local label="$1" prog; prog="$(basename "${0}")"
  cat <<EOF
Usage: bash ci-cd/${prog} <action> [arg]

  list                  list all ${label}s
  get <id>              show one ${label}
  create <input.json>   create a new ${label}
  update <input.json>   update an existing ${label}  (input.json must include its "id")
  delete <id>           delete a ${label}

Sample create/update inputs live under ci-cd/examples/.
EOF
}

# Shared dispatcher used by the gateway-*.sh element scripts. Given a resource label
# and the four documents, routes: list | get <id> | create <f> | update <f> |
# delete <id>. Element scripts pass their own docs so the GraphQL stays visible
# and version-controlled next to each element. With no action, prints usage and
# exits 2 (rather than silently listing).
#
# Usage inside an element script:
#   gw_dispatch "policy rule" "$LIST" "$GET" "$CREATE" "$UPDATE" "$DELETE" "$@"
gw_dispatch() {
  local label="$1" list="$2" get="$3" create="$4" update="$5" delete="$6"; shift 6
  if [ "$#" -eq 0 ]; then gw_usage "$label" >&2; exit 2; fi
  local action="$1"; shift
  case "$action" in
    list)   log_info "list ${label}s";                gw_run    "$list" ;;
    get)    [ -n "${1:-}" ] || { gw_usage "$label" >&2; exit 2; }; log_info "get ${label} ${1}";    gw_get    "$get"    "$1" ;;
    create) [ -n "${1:-}" ] || { gw_usage "$label" >&2; exit 2; }; log_info "create ${label} ← ${1}"; gw_mutate "$create" "$1" ;;
    update) [ -n "${1:-}" ] || { gw_usage "$label" >&2; exit 2; }; log_info "update ${label} ← ${1}"; gw_mutate "$update" "$1" ;;
    delete) [ -n "${1:-}" ] || { gw_usage "$label" >&2; exit 2; }; log_warn "delete ${label} ${1}"; gw_delete "$delete" "$1" ;;
    -h|--help|help) gw_usage "$label" ;;
    *) log_err "unknown action '${action}'"; gw_usage "$label" >&2; exit 2 ;;
  esac
}
