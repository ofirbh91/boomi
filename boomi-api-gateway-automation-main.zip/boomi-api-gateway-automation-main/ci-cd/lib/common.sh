#!/usr/bin/env bash
# Copyright (c) Anthony Rabiaza 2026-09-08
# Updated 2026-09-08
# ci-cd/lib/common.sh - shared helpers for the Boomi API Gateway CI/CD pipeline.
# Sourced by every ci-cd/ script. Not meant to be run directly.
#
# Provides:
#   - .env loading (from project root)
#   - logging: log_info / log_warn / log_err / die
#   - skill tool runner: boomi <script-name> [args...]   (Plane A - AtomSphere REST)
#   - GraphQL client:     apim_graphql <query-file|-> [jq-filter]   (Plane B - APIM GraphQL)

set -euo pipefail

# --- Paths -----------------------------------------------------------------
CI_LIB_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CI_DIR="$(dirname "$CI_LIB_DIR")"
PROJECT_ROOT="$(dirname "$CI_DIR")"

# Location of the bundled boomi-*.sh helper scripts. Vendored in-project under
# vendor/boomi-integration so this repo runs with no external dependencies.
# Override via SKILL_PATH env if you keep the scripts elsewhere.
: "${SKILL_PATH:=${PROJECT_ROOT}/vendor/boomi-integration}"
SKILL_SCRIPTS="${SKILL_PATH}/scripts"

# --- Logging ---------------------------------------------------------------
_ts() { date -u +%H:%M:%S; }
log_info() { printf '[%s] \033[0;36mINFO\033[0m  %s\n' "$(_ts)" "$*" >&2; }
log_warn() { printf '[%s] \033[0;33mWARN\033[0m  %s\n' "$(_ts)" "$*" >&2; }
log_err()  { printf '[%s] \033[0;31mERROR\033[0m %s\n' "$(_ts)" "$*" >&2; }
die()      { log_err "$*"; exit 1; }

# --- .env loading ----------------------------------------------------------
load_env() {
  local env_file="${PROJECT_ROOT}/.env"
  [ -f "$env_file" ] || die ".env not found at ${env_file} (copy .env.example → .env)"
  set -a
  # shellcheck disable=SC1090
  . "$env_file"
  set +a
  : "${BOOMI_API_URL:?BOOMI_API_URL not set in .env}"
  : "${BOOMI_USERNAME:?BOOMI_USERNAME not set in .env}"
  : "${BOOMI_API_TOKEN:?BOOMI_API_TOKEN not set in .env}"
  : "${BOOMI_ACCOUNT_ID:?BOOMI_ACCOUNT_ID not set in .env}"
}

# --- Plane A: run a bundled boomi-*.sh helper script -----------------------
# Runs from PROJECT_ROOT so the tool resolves .env and active-development/.
# Usage: boomi component-push components/api-proxy/MyProxy.xml
boomi() {
  local script="$1"; shift
  local path="${SKILL_SCRIPTS}/boomi-${script}.sh"
  [ -f "$path" ] || die "skill script not found: ${path} (check SKILL_PATH)"
  ( cd "$PROJECT_ROOT" && bash "$path" "$@" )
}

# --- Plane A: AtomSphere REST API (direct call) ----------------------------
# Thin client for the AtomSphere Platform API, for read/query calls the bundled
# boomi-*.sh helpers don't expose (e.g. ComponentMetadata/query, Component GET).
# Endpoint is relative to the account base:
#   <BOOMI_API_URL>/api/rest/v1/<accountId>/<endpoint>
# HTTP Basic auth uses the AtomSphere API token (same creds as the helpers).
# Prints the raw response body on stdout; any non-2xx status is fatal.
# Extra curl args (method, headers, data) pass through before the URL.
# Usage:
#   atom_rest ComponentMetadata/query -X POST \
#     -H 'Content-Type: application/json' -H 'Accept: application/json' -d "$body"
#   atom_rest "Component/${id}" -H 'Accept: application/xml'
atom_rest() {
  local endpoint="$1"; shift
  local url="${BOOMI_API_URL%/}/api/rest/v1/${BOOMI_ACCOUNT_ID}/${endpoint}"
  local verify=(); [ "${BOOMI_VERIFY_SSL:-true}" = "false" ] && verify=(-k)
  local resp code
  # ${arr[@]+"${arr[@]}"} - safe empty-array expansion under `set -u` (bash 3.2)
  resp="$(curl -sS ${verify[@]+"${verify[@]}"} -w $'\n%{http_code}' \
    -u "BOOMI_TOKEN.${BOOMI_USERNAME}:${BOOMI_API_TOKEN}" \
    "$@" "$url")" || die "AtomSphere REST request failed (network) to $url"
  code="${resp##*$'\n'}"; resp="${resp%$'\n'*}"
  case "$code" in
    2*) printf '%s' "$resp" ;;
    *)  log_err "AtomSphere REST HTTP $code from $url"; printf '%s\n' "$resp" >&2; return 1 ;;
  esac
}

# Resolve a folder reference to a Boomi folder ID (prints it on stdout).
# The Component API honors folderId, not folderFullPath, so a create/move must
# send an ID. Accepts, in order:
#   - a folder ID (base64 of "F:<n>", always starts with "Rjo") - returned as-is
#   - an exact folderFullPath ("Parent/Child/Leaf") - matched client-side
#   - a bare folder name - unique match required
# Queries Folder by the leaf name (fullPath is not server-queryable). Returns 1
# with a message on stderr for zero or ambiguous matches; callers should check.
resolve_folder_id() {
  local input="$1"
  if printf '%s' "$input" | grep -qE '^Rjo[A-Za-z0-9+/=_-]+$'; then
    printf '%s' "$input"; return 0
  fi
  local leaf="${input##*/}" body results ids count
  body="$(jq -cn --arg n "$leaf" '{QueryFilter:{expression:{operator:"and",nestedExpression:[
    {operator:"EQUALS",property:"name",argument:[$n]},
    {operator:"EQUALS",property:"deleted",argument:["false"]}
  ]}}}')"
  results="$(atom_rest "Folder/query" -X POST \
    -H 'Content-Type: application/json' -H 'Accept: application/json' -d "$body")" || return 1
  if [ "$input" = "$leaf" ]; then
    ids="$(printf '%s' "$results" | jq -r '.result[]?.id')"
  else
    ids="$(printf '%s' "$results" | jq -r --arg p "$input" '.result[]? | select(.fullPath==$p) | .id')"
  fi
  count="$(printf '%s' "$ids" | grep -c . || true)"
  if [ "$count" -eq 0 ]; then
    log_err "folder not found: '${input}'. Check the path/name or pass a folder ID."; return 1
  elif [ "$count" -gt 1 ]; then
    log_err "folder reference '${input}' is ambiguous - matches:"
    printf '%s' "$results" | jq -r '.result[]? | "  \(.id)\t\(.fullPath)"' >&2
    log_err "use the full path 'Parent/.../${leaf}' or a folder ID."; return 1
  fi
  printf '%s' "$ids"
}

# --- Plane B: APIM GraphQL endpoint ----------------------------------------
# Endpoint is <platform base>/graphql. Default derives from BOOMI_API_URL,
# stripping any /api/... suffix. Override with APIM_GRAPHQL_URL in .env.
apim_graphql_url() {
  if [ -n "${APIM_GRAPHQL_URL:-}" ]; then
    printf '%s' "$APIM_GRAPHQL_URL"; return
  fi
  local base="${BOOMI_API_URL%/}"
  base="${base%%/api/*}"          # https://api.boomi.com/api/rest/v1 → https://api.boomi.com
  printf '%s/graphql' "$base"
}

# Send a GraphQL request. Query comes from a file path or stdin ("-").
# HTTP Basic auth uses the AtomSphere API token (same creds as Plane A).
# Usage: apim_graphql gateway/policies/query.graphql '.data.deployedApis'
# The query file may contain a raw GraphQL document; variables can be supplied
# via the APIM_GRAPHQL_VARS env var (JSON string), default {}.
apim_graphql() {
  local src="$1"; local jq_filter="${2:-.}"
  local query
  if [ "$src" = "-" ]; then query="$(cat)"; else
    [ -f "$src" ] || die "GraphQL query file not found: $src"
    query="$(cat "$src")"
  fi
  local url; url="$(apim_graphql_url)"
  # NB: don't inline a brace-literal default in the expansion - `${VAR:-{}}`
  # mis-parses (the first `}` closes it, appending a literal `}` to the value).
  local vars="${APIM_GRAPHQL_VARS-}"; [ -n "$vars" ] || vars='{}'
  local body; body="$(jq -cn --arg q "$query" --argjson v "$vars" '{query:$q, variables:$v}')"

  local verify=(); [ "${BOOMI_VERIFY_SSL:-true}" = "false" ] && verify=(-k)
  local resp code
  # ${arr[@]+"${arr[@]}"} - safe empty-array expansion under `set -u` (bash 3.2)
  resp="$(curl -sS ${verify[@]+"${verify[@]}"} -w $'\n%{http_code}' -X POST "$url" \
    -u "BOOMI_TOKEN.${BOOMI_USERNAME}:${BOOMI_API_TOKEN}" \
    -H "X-Account: ${BOOMI_ACCOUNT_ID}" \
    -H 'Content-Type: application/json' \
    -H 'Accept: application/json' \
    --data "$body")" || die "GraphQL request failed (network) to $url"
  code="${resp##*$'\n'}"; resp="${resp%$'\n'*}"

  if [ "$code" != "200" ]; then
    log_err "GraphQL HTTP $code from $url"; printf '%s\n' "$resp" >&2; return 1
  fi
  if printf '%s' "$resp" | jq -e '.errors? // empty | length > 0' >/dev/null 2>&1; then
    log_err "GraphQL returned errors:"; printf '%s' "$resp" | jq '.errors' >&2; return 1
  fi
  printf '%s' "$resp" | jq "$jq_filter"
}
