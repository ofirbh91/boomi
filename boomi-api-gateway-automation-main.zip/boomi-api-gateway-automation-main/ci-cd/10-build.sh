#!/usr/bin/env bash
# Copyright (c) Anthony Rabiaza 2026-09-08
# Updated 2026-09-08
# ci-cd/10-build.sh - Plane A build (design-time).
# Pushes every component XML under BUILD_GLOBS to the platform (create or
# update). Safe to run repeatedly; the skill tools no-op when content is
# unchanged. Does NOT deploy - see 20-deploy.sh.

set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib/common.sh
. "${HERE}/lib/common.sh"
# shellcheck source=config.sh
. "${HERE}/config.sh"
load_env

log_info "Build: pushing components to platform (account ${BOOMI_ACCOUNT_ID})"

pushed=0
for dir in "${BUILD_GLOBS[@]}"; do
  d="${PROJECT_ROOT}/${dir}"
  [ -d "$d" ] || continue
  while IFS= read -r -d '' xml; do
    rel="${xml#"${PROJECT_ROOT}/"}"
    # A component already tracked in sync-state uses push; new ones use create.
    if grep -q "componentId=\"[^\"]\+\"" "$xml" 2>/dev/null; then
      log_info "push  ${rel}"
      boomi component-push "$rel"
    else
      log_info "create ${rel}"
      boomi component-create "$rel"
    fi
    pushed=$((pushed+1))
  done < <(find "$d" -name '*.xml' -type f -print0 2>/dev/null)
done

if [ "$pushed" -eq 0 ]; then
  log_warn "No component XML found under: ${BUILD_GLOBS[*]}"
  log_warn "Build a component first (e.g. an API Proxy) - nothing to push yet."
else
  log_info "Build complete: ${pushed} component(s) processed."
fi
