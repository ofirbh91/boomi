#!/usr/bin/env bash
# Copyright (c) Anthony Rabiaza 2026-09-08
# Updated 2026-09-08
# ci-cd/00-check.sh - preflight connectivity + auth check for both API planes.
# Runs BEFORE build/deploy to fail fast on bad credentials or unreachable APIs.
# Read-only and safe to run repeatedly.
#
#   Plane A (AtomSphere REST) : GET the Account object for BOOMI_ACCOUNT_ID.
#   Plane B (APIM GraphQL)    : minimal query to validate endpoint + auth.
#
# Exit 0 only if BOTH planes authenticate successfully.

set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib/common.sh
. "${HERE}/lib/common.sh"
# shellcheck source=config.sh
. "${HERE}/config.sh"
load_env

verify=(); [ "${BOOMI_VERIFY_SSL:-true}" = "false" ] && verify=(-k)

# --- Plane A: AtomSphere REST ----------------------------------------------
# GET /api/rest/v1/{accountId}/Account/{accountId} - same Basic auth as Plane B
# (BOOMI_TOKEN.<username> : <api-token>).
check_rest() {
  local base="${BOOMI_API_URL%/}"
  local url="${base}/api/rest/v1/${BOOMI_ACCOUNT_ID}/Account/${BOOMI_ACCOUNT_ID}"
  log_info "Plane A (AtomSphere REST): GET ${url}"

  local resp code
  # ${arr[@]+"${arr[@]}"} - safe empty-array expansion under `set -u` (bash 3.2)
  resp="$(curl -sS ${verify[@]+"${verify[@]}"} -w $'\n%{http_code}' \
    -u "BOOMI_TOKEN.${BOOMI_USERNAME}:${BOOMI_API_TOKEN}" \
    -H 'Accept: application/json' \
    --max-time 20 \
    "$url")" || { log_err "Plane A request failed (network) to ${url}"; return 1; }
  code="${resp##*$'\n'}"; resp="${resp%$'\n'*}"

  case "$code" in
    200)
      local name
      name="$(printf '%s' "$resp" | jq -r '.name // .accountId // empty' 2>/dev/null || true)"
      log_info "Plane A OK (HTTP 200)${name:+ - account: ${name}}"
      return 0 ;;
    401|403)
      log_err "Plane A auth FAILED (HTTP ${code}) - check BOOMI_USERNAME / BOOMI_API_TOKEN / BOOMI_ACCOUNT_ID"
      return 1 ;;
    *)
      log_err "Plane A FAILED (HTTP ${code}) from ${url}"
      printf '%s\n' "$resp" >&2
      return 1 ;;
  esac
}

# --- Plane B: APIM GraphQL --------------------------------------------------
# Minimal, schema-agnostic query - proves endpoint + auth without depending on
# any particular type being present. The apim_graphql helper handles transport,
# HTTP status, and GraphQL-error checking.
check_graphql() {
  log_info "Plane B (APIM GraphQL): POST $(apim_graphql_url)"
  if apim_graphql - '.data' >/dev/null <<'GQL'
query Ping { __typename }
GQL
  then
    log_info "Plane B OK"
    return 0
  fi
  log_err "Plane B FAILED - see error above (endpoint: $(apim_graphql_url))"
  return 1
}

log_info "Connectivity check - account ${BOOMI_ACCOUNT_ID}"

rc=0
check_rest    || rc=1
check_graphql || rc=1

if [ "$rc" -eq 0 ]; then
  log_info "Connectivity check PASSED - both planes reachable and authenticated."
else
  die "Connectivity check FAILED - resolve the errors above before running the pipeline."
fi
