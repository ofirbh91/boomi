#!/usr/bin/env bash
# Copyright (c) Anthony Rabiaza 2026-09-09
# Updated 2026-09-09
# ci-cd/api-proxy.sh - Plane A accelerator: API Proxy components (webservice.external).
#
# An API Proxy in Boomi is a component of type `webservice.external`: it publishes
# a base path and delegates (reverse-proxies) traffic to a backend endpoint URL.
#
#   list                     list API Proxy components (id, name, version, folder)
#   get <id>                 summarise one proxy (basePath, backend URL, ...)
#     get <id> --raw         print the full component XML instead
#   create <name> <opts>     create a new API Proxy component (see below)
#
# create <name> --base-path <path> --target-url <url> [options]
#   Required:
#     --base-path <path>     public base path of the proxy (e.g. orders/v1)
#     --target-url <url>     backend the proxy delegates to (delegate endpoint URL)
#   Optional:
#     --folder <ref>         target folder as a full path ("Acct/_IDB/API Proxies"),
#                            a bare name ("API Proxies"), or a folder ID - resolved
#                            to a folder ID (the Component API honors folderId only)
#                            (default: $API_PROXY_FOLDER, else a folder is required)
#     --folder-id <id>       target folder by its Boomi folder ID (skips resolution)
#     --api-type <rest|soap> publication API type (default: rest)
#     --title <title>        publication title (default: <name>)
#     --api-version <ver>    publication version (default: 1.0)
#     --description <text>   description for the proxy
#     --swagger <file>       OpenAPI/Swagger spec file to publish with the proxy
#                            (gzip + base64 encoded into the component, as the UI does)
#     --health-check-url <u> delegate health-check URL (default: empty)
#     --http-version <1.1|2> HTTP protocol version to the backend (default: 1.1)
#     --auth-type <type>     none | basic | pass-through (default: pass-through)
#     --basic-user <u>       Basic Auth username   (required for --auth-type basic)
#     --basic-password <p>   Basic Auth password   (required for --auth-type basic;
#                            sent in plaintext, encrypted by the platform on create)
#     --forward-auth-header <true|false>   forward the caller's Authorization header
#                            (includeAuthHeader; default: true for pass-through, else false)
#     --remove-original-auth <true|false>  strip the caller's Authorization header
#                            (removeOriginalAuthorization; default: true for basic, else false)
#     --header "K: V"        add a custom request header (repeatable)
#     --header-encrypted "K: V"  add a header flagged encrypted (repeatable; note the
#                            API stores the value as given - the flag is set, not the value)
#     --branch <name|id>     target branch (passed to component-create)
#     --no-create            only write the XML file; do not create on platform
#     --force                overwrite an existing components/api-proxy/<name>.xml
#
# 'create' writes components/api-proxy/<name>.xml then creates it on the platform
# via the bundled component-create helper (which stamps the returned componentId
# and sync state back into the file). Subsequent 10-build.sh runs pick it up.
#
# e.g.  bash ci-cd/api-proxy.sh list
#       bash ci-cd/api-proxy.sh get 452c1591-5909-4f2e-bb8b-e4782d4ec541
#       bash ci-cd/api-proxy.sh create "Orders Proxy" \
#         --base-path orders/v1 --target-url https://api.internal.example.com \
#         --folder "MyAccount/API Proxies"

set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib/common.sh
. "${HERE}/lib/common.sh"
# shellcheck source=config.sh
. "${HERE}/config.sh"
load_env

PROXY_TYPE="webservice.external"

usage() {
  cat <<EOF
Usage: bash ci-cd/api-proxy.sh <action> [args]

  list                         list API Proxy components (id, name, version, folder)
  get <id> [--raw]             summarise one proxy (or --raw for full XML)
  create <name> --base-path <path> --target-url <url> [options]

create options:
  --folder <ref>               folder full path, name, or ID - resolved to a folder ID
                               (default: \$API_PROXY_FOLDER, else required)
  --folder-id <id>             target folder by Boomi folder ID (skips resolution)
  --api-type <rest|soap>       publication API type (default: rest)
  --title <title>              publication title (default: <name>)
  --api-version <ver>          publication version (default: 1.0)
  --description <text>         proxy description
  --swagger <file>             OpenAPI/Swagger spec file to publish (gzip+base64 embedded)
  --health-check-url <url>     delegate health-check URL (default: empty)
  --http-version <1.1|2>       HTTP protocol version to backend (default: 1.1)
  --auth-type <type>           none | basic | pass-through (default: pass-through)
  --basic-user <u>             Basic Auth username (required for --auth-type basic)
  --basic-password <p>         Basic Auth password (required for --auth-type basic)
  --forward-auth-header <t|f>  forward caller Authorization header (default: type-based)
  --remove-original-auth <t|f> strip caller Authorization header (default: type-based)
  --header "K: V"              add a custom request header (repeatable)
  --header-encrypted "K: V"    add a header flagged encrypted (repeatable)
  --branch <name|id>           target branch (passed to component-create)
  --no-create                  only write the XML file; do not create on platform
  --force                      overwrite an existing components/api-proxy/<name>.xml

An API Proxy is a component of type '${PROXY_TYPE}'. Use 'list' to discover
component IDs, then 'get <id>' for its base path and backend delegate URL.
EOF
}

# XML-escape a value for use in element text or a double-quoted attribute.
xml_escape() {
  local s="$1"
  s="${s//&/&amp;}"; s="${s//</&lt;}"; s="${s//>/&gt;}"
  s="${s//\"/&quot;}"
  printf '%s' "$s"
}

# Extract the first value of attr $1 (name="value") from stdin XML.
first_attr() { grep -oE "$1=\"[^\"]*\"" | head -1 | sed -E "s/^$1=\"//; s/\"\$//"; }

# Trim leading/trailing whitespace from $1.
trim() { local s="$1"; s="${s#"${s%%[![:space:]]*}"}"; s="${s%"${s##*[![:space:]]}"}"; printf '%s' "$s"; }

# --- list ------------------------------------------------------------------
proxy_list() {
  log_info "list API Proxy components (type=${PROXY_TYPE})"
  local body
  body="$(jq -cn --arg t "$PROXY_TYPE" '{QueryFilter:{expression:{operator:"and",nestedExpression:[
    {operator:"EQUALS",property:"type",argument:[$t]},
    {operator:"EQUALS",property:"currentVersion",argument:["true"]},
    {operator:"EQUALS",property:"deleted",argument:["false"]}
  ]}}}')"
  atom_rest "ComponentMetadata/query" -X POST \
    -H 'Content-Type: application/json' -H 'Accept: application/json' \
    -d "$body" \
    | jq '[.result // [] | .[] | {id: .componentId, name, version, folder: .folderName, folderId}]'
}

# --- get -------------------------------------------------------------------
proxy_get() {
  local id="$1" raw="${2:-}"
  log_info "get API Proxy ${id}"
  local xml
  xml="$(atom_rest "Component/${id}" -H 'Accept: application/xml')"
  if [ "$raw" = "--raw" ]; then printf '%s\n' "$xml"; return; fi

  # Drop the <?xml ...?> declaration so its version="1.0" doesn't shadow the
  # component's own version on the root <Component> element.
  xml="${xml#*\?>}"

  # Object content is single-line XML; targeted attributes are unique except
  # name/type/version, which first appear on the root <Component> element.
  local name type version folder apiType basePath title backend health
  name="$(printf '%s' "$xml"   | first_attr 'name')"
  type="$(printf '%s' "$xml"   | first_attr 'type')"
  version="$(printf '%s' "$xml" | first_attr 'version')"
  folder="$(printf '%s' "$xml" | first_attr 'folderFullPath')"
  apiType="$(printf '%s' "$xml" | first_attr 'apiType')"
  basePath="$(printf '%s' "$xml" | first_attr 'basePath')"
  title="$(printf '%s' "$xml"  | first_attr 'title')"
  backend="$(printf '%s' "$xml" | first_attr 'url')"
  health="$(printf '%s' "$xml" | first_attr 'healthCheckUrl')"

  jq -n --arg id "$id" --arg name "$name" --arg type "$type" --arg version "$version" \
        --arg folder "$folder" --arg apiType "$apiType" --arg basePath "$basePath" \
        --arg title "$title" --arg backend "$backend" --arg health "$health" \
    '{id:$id, name:$name, type:$type, version:$version, folder:$folder,
      publication:{apiType:$apiType, basePath:$basePath, title:$title},
      delegateEndpoint:{url:$backend, healthCheckUrl:$health}}'
}

# --- create ----------------------------------------------------------------
proxy_create() {
  local name="${1:-}"; shift || true
  [ -n "$name" ] || { log_err "create requires a <name>"; usage >&2; exit 2; }

  local base_path="" target_url="" folder="${API_PROXY_FOLDER:-}" folder_id=""
  local api_type="rest" title="" api_version="1.0" description="" swagger=""
  local health_url="" branch="" do_create=true force=false
  local http_version="1.1" auth_type="pass-through" basic_user="" basic_password=""
  local forward_auth="" remove_orig_auth=""
  local -a hdr_plain=() hdr_enc=()
  while [ "$#" -gt 0 ]; do
    case "$1" in
      --base-path)       base_path="${2:-}"; shift 2 ;;
      --target-url)      target_url="${2:-}"; shift 2 ;;
      --folder)          folder="${2:-}"; shift 2 ;;
      --folder-id)       folder_id="${2:-}"; shift 2 ;;
      --api-type)        api_type="${2:-}"; shift 2 ;;
      --title)           title="${2:-}"; shift 2 ;;
      --api-version)     api_version="${2:-}"; shift 2 ;;
      --description)     description="${2:-}"; shift 2 ;;
      --swagger)         swagger="${2:-}"; shift 2 ;;
      --health-check-url) health_url="${2:-}"; shift 2 ;;
      --http-version)    http_version="${2:-}"; shift 2 ;;
      --auth-type)       auth_type="${2:-}"; shift 2 ;;
      --basic-user)      basic_user="${2:-}"; shift 2 ;;
      --basic-password)  basic_password="${2:-}"; shift 2 ;;
      --forward-auth-header)  forward_auth="${2:-}"; shift 2 ;;
      --remove-original-auth) remove_orig_auth="${2:-}"; shift 2 ;;
      --header)          hdr_plain+=("${2:-}"); shift 2 ;;
      --header-encrypted) hdr_enc+=("${2:-}"); shift 2 ;;
      --branch)          branch="${2:-}"; shift 2 ;;
      --no-create)       do_create=false; shift ;;
      --force)           force=true; shift ;;
      *) log_err "unknown create option '${1}'"; usage >&2; exit 2 ;;
    esac
  done

  [ -n "$base_path" ]  || die "create: --base-path is required"
  [ -n "$target_url" ] || die "create: --target-url is required"
  [ -n "$title" ] || title="$name"

  # Folder placement: the Component API honors folderId, not folderFullPath, so
  # resolve whatever was given (id, full path, or name) to a folder ID up front.
  if [ -z "$folder_id" ]; then
    [ -n "$folder" ] || die "create: a folder is required - pass --folder <fullPath|name> or --folder-id <id> (or set API_PROXY_FOLDER in .env). Find IDs with: bash ci-cd/api-proxy.sh list"
    folder_id="$(resolve_folder_id "$folder")" || exit 1
  fi
  log_info "target folder: ${folder_id}"
  local folder_attr="folderId=\"$(xml_escape "$folder_id")\""

  # Optional Swagger/OpenAPI spec: gzip then base64, embedded as <swaggerFile>
  # inside <publicationInfo> - the same encoding the Boomi UI stores. Empty when
  # --swagger is not given (a proxy can publish without a spec).
  local swagger_block=""
  if [ -n "$swagger" ]; then
    [ -f "$swagger" ] || die "create: --swagger file not found: ${swagger}"
    local sw_name sw_content sw_now
    sw_name="$(basename "$swagger")"
    sw_content="$(gzip -nc "$swagger" | base64 | tr -d '\n')"
    [ -n "$sw_content" ] || die "create: failed to encode swagger file ${swagger}"
    sw_now="$(date -u +%Y-%m-%dT%H:%M:%S.000Z)"
    swagger_block="$(printf '\n        <swaggerFile><fileName>%s</fileName><fileContent>%s</fileContent><uploadedBy>%s</uploadedBy><uploadedDate>%s</uploadedDate></swaggerFile>' \
      "$(xml_escape "$sw_name")" "$sw_content" "$(xml_escape "$BOOMI_USERNAME")" "$sw_now")"
    log_info "embedding swagger spec ${sw_name} (gzip+base64)"
  fi

  # --- Delegate endpoint: HTTP version, auth, custom headers ---------------
  case "$http_version" in 1.1|2) ;; *) die "create: --http-version must be 1.1 or 2" ;; esac
  case "$auth_type" in none|basic|pass-through) ;; *) die "create: --auth-type must be none, basic, or pass-through" ;; esac
  local http2="false"; [ "$http_version" = "2" ] && http2="true"
  if [ "$auth_type" = "basic" ]; then
    [ -n "$basic_user" ] && [ -n "$basic_password" ] || die "create: --auth-type basic requires --basic-user and --basic-password"
  fi
  # includeAuthHeader ("forward original authorization header") and
  # removeOriginalAuthorization: honour explicit flags, else default per type.
  [ -n "$forward_auth" ]    || { [ "$auth_type" = "pass-through" ] && forward_auth="true" || forward_auth="false"; }
  [ -n "$remove_orig_auth" ] || { [ "$auth_type" = "basic" ] && remove_orig_auth="true" || remove_orig_auth="false"; }
  case "$forward_auth" in true|false) ;; *) die "create: --forward-auth-header must be true or false" ;; esac
  case "$remove_orig_auth" in true|false) ;; *) die "create: --remove-original-auth must be true or false" ;; esac

  # Custom headers - <header> children come first in the delegateEndpoint XSD
  # sequence {header, basicAuth, oauth2Auth}. NB: the API stores header values
  # as given even with encrypted="true" (the flag is kept, the value is not
  # auto-encrypted the way a basicAuth password is).
  local headers_block="" spec k v
  for spec in ${hdr_plain[@]+"${hdr_plain[@]}"}; do
    case "$spec" in *:*) ;; *) die "create: invalid --header '${spec}' (use 'Key: Value')" ;; esac
    k="$(trim "${spec%%:*}")"; v="$(trim "${spec#*:}")"
    [ -n "$k" ] || die "create: invalid --header '${spec}' (empty key)"
    headers_block+="$(printf '\n        <header name="%s" value="%s"/>' "$(xml_escape "$k")" "$(xml_escape "$v")")"
  done
  for spec in ${hdr_enc[@]+"${hdr_enc[@]}"}; do
    case "$spec" in *:*) ;; *) die "create: invalid --header-encrypted '${spec}' (use 'Key: Value')" ;; esac
    k="$(trim "${spec%%:*}")"; v="$(trim "${spec#*:}")"
    [ -n "$k" ] || die "create: invalid --header-encrypted '${spec}' (empty key)"
    headers_block+="$(printf '\n        <header name="%s" value="%s" encrypted="true"/>' "$(xml_escape "$k")" "$(xml_escape "$v")")"
  done

  # Basic auth child (password is sent in plaintext; the platform encrypts it
  # on create and records the encryptedValue declaration itself).
  local auth_block=""
  if [ "$auth_type" = "basic" ]; then
    auth_block="$(printf '\n        <basicAuth user="%s" password="%s"/>' "$(xml_escape "$basic_user")" "$(xml_escape "$basic_password")")"
  fi

  # Assemble the delegateEndpoint element (self-closing unless it has children).
  local de_attrs delegate
  de_attrs="healthCheckUrl=\"$(xml_escape "$health_url")\" http2Protocol=\"${http2}\" includeAuthHeader=\"${forward_auth}\" removeOriginalAuthorization=\"${remove_orig_auth}\" url=\"$(xml_escape "$target_url")\""
  if [ -n "$headers_block" ] || [ -n "$auth_block" ]; then
    delegate="$(printf '<delegateEndpoint %s>%s%s\n      </delegateEndpoint>' "$de_attrs" "$headers_block" "$auth_block")"
  else
    delegate="$(printf '<delegateEndpoint %s/>' "$de_attrs")"
  fi

  # Sanitise a filesystem-safe basename; the real name stays in the XML.
  local safe; safe="$(printf '%s' "$name" | tr ' /' '__' | tr -cd '[:alnum:]_.-')"
  [ -n "$safe" ] || die "create: <name> produced an empty filename"
  local rel="components/api-proxy/${safe}.xml"
  local out="${PROJECT_ROOT}/${rel}"
  local sync_state="${PROJECT_ROOT}/active-development/.sync-state/${safe}.json"
  if [ -f "$out" ]; then
    [ "$force" = true ] || die "create: ${rel} already exists. To modify that proxy, edit the XML and run 10-build.sh. To make a NEW component under this name, pass --force."
    # --force means "create a new component": drop the stale sync link so
    # component-create doesn't no-op against a previously tracked (or deleted) id.
    log_warn "--force: replacing ${rel} and creating a NEW component (existing sync link cleared)"
    rm -f "$sync_state"
  fi
  mkdir -p "$(dirname "$out")"

  # No componentId → component-create treats this as a new component.
  cat > "$out" <<EOF
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<bns:Component xmlns:bns="http://api.platform.boomi.com/" ${folder_attr} name="$(xml_escape "$name")" type="${PROXY_TYPE}">
  <bns:description>$(xml_escape "$description")</bns:description>
  <bns:object>
    <ExternalWebservice xmlns="">
      <publicationInfo apiType="$(xml_escape "$api_type")" basePath="$(xml_escape "$base_path")" title="$(xml_escape "$title")" version="$(xml_escape "$api_version")">
        <description>$(xml_escape "$description")</description>${swagger_block}
      </publicationInfo>
      ${delegate}
      <metaInfo contactEmail="" contactName="" contactUrl="" licenseName="" licenseUrl=""><termsOfService/></metaInfo>
    </ExternalWebservice>
  </bns:object>
</bns:Component>
EOF
  log_info "wrote ${rel}"

  if [ "$do_create" != true ]; then
    log_info "--no-create: skipping platform create. Push later with: boomi component-create ${rel}"
    return
  fi

  log_info "creating API Proxy '${name}' on the platform"
  if [ -n "$branch" ]; then
    boomi component-create "$rel" --branch "$branch"
  else
    boomi component-create "$rel"
  fi
  log_info "Done. To deploy it, add \"${rel}\" to DEPLOYABLES in ci-cd/config.sh, then run: bash ci-cd/pipeline.sh dev"
}

if [ "$#" -eq 0 ]; then usage >&2; exit 2; fi
case "$1" in
  list)           proxy_list ;;
  get)            [ -n "${2:-}" ] || { usage >&2; exit 2; }; proxy_get "$2" "${3:-}" ;;
  create)         shift; proxy_create "$@" ;;
  -h|--help|help) usage ;;
  *) log_err "unknown action '${1}'"; usage >&2; exit 2 ;;
esac
