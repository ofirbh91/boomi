#!/usr/bin/env bash
# Copyright (c) Anthony Rabiaza 2026-09-08
# Updated 2026-09-08
# ci-cd/gateway-subscription.sh - Plane B accelerator: Subscriptions (API keys).
# A subscription links an Application + a Deployed API + a Plan. Its apiKeyId
# IS the API key the consumer presents (e.g. as the x-api-key header).
# This is how you "add an API to an application" and obtain its key.
#
#   list [applicationId]    list subscriptions (all apps, or one app's)
#   get <apiKeyId>          one subscription's detail (incl. its API key)
#   create <input.json>     subscribe an app to an API on a plan → returns apiKeyId
#   regenerate <apiKeyId>   rotate (re-issue) the API key
#   delete <apiKeyId>       cancel a subscription
#
# create input.json (DeployedApiSubscriptionCreateInput), see
# ci-cd/examples/subscription/subscribe.json:
#   { "deployedApiId": "<id>", "applicationId": "<id>", "planId": "<id>",
#     "expirationDate": "2027-01-01T00:00:00Z" }   # dates optional
#
# Discover the three ids with:
#   bash ci-cd/gateway-api.sh list          # deployedApiId + its plans (gateway-api get <id>)
#   bash ci-cd/gateway-application.sh list   # applicationId
#   bash ci-cd/gateway-plan.sh list          # planId

set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "${HERE}/lib/common.sh"
. "${HERE}/config.sh"
. "${HERE}/lib/gateway.sh"
load_env

SUB_FIELDS='apiKeyId status startDate expirationDate
  plan { id name }
  application { id name }
  deployedApi { id version component { name } }'

LIST_ALL="query { deployedApiApplications { id name subscriptions { ${SUB_FIELDS} } } }"
LIST_ONE="query (\$id: ID!) { deployedApiApplication(id: \$id) { id name subscriptions { ${SUB_FIELDS} } } }"
GET="query (\$id: ID!) { deployedApiSubscription(apiKeyId: \$id) { ${SUB_FIELDS} } }"
CREATE='mutation ($in: DeployedApiSubscriptionCreateInput!) {
  deployedApiSubscriptionCreate(deployedApiSubscription: $in) {
    apiKeyId status plan { name } application { name }
    deployedApi { component { name } version } } }'
REGEN='mutation ($id: ID!) { deployedApiSubscriptionRegenerateApiKey(apiKeyId: $id) { apiKeyId status } }'
DELETE='mutation ($id: ID!) { deployedApiSubscriptionDelete(apiKeyId: $id) }'

usage() {
  cat <<EOF
Usage: bash ci-cd/gateway-subscription.sh <action> [arg]

  list [applicationId]    list subscriptions (all applications, or just one)
  get <apiKeyId>          show one subscription (its apiKeyId is the API key)
  create <input.json>     subscribe an app to an API on a plan; returns apiKeyId
  regenerate <apiKeyId>   rotate (re-issue) the API key
  delete <apiKeyId>       cancel a subscription

Sample create input lives under ci-cd/examples/subscription/.
EOF
}

if [ "$#" -eq 0 ]; then usage >&2; exit 2; fi
case "$1" in
  list)       if [ -n "${2:-}" ]; then log_info "list subscriptions for application ${2}"; gw_get "$LIST_ONE" "$2";
              else log_info "list all subscriptions"; gw_run "$LIST_ALL"; fi ;;
  get)        [ -n "${2:-}" ] || { usage >&2; exit 2; }; log_info "get subscription ${2}"; gw_get "$GET" "$2" ;;
  create)     [ -n "${2:-}" ] || { usage >&2; exit 2; }; log_info "create subscription ← ${2}"; gw_mutate "$CREATE" "$2" ;;
  regenerate) [ -n "${2:-}" ] || { usage >&2; exit 2; }; log_warn "regenerate API key for ${2}"; gw_get "$REGEN" "$2" ;;
  delete)     [ -n "${2:-}" ] || { usage >&2; exit 2; }; log_warn "delete subscription ${2}"; gw_get "$DELETE" "$2" ;;
  -h|--help|help) usage ;;
  *) log_err "unknown action '${1}'"; usage >&2; exit 2 ;;
esac
