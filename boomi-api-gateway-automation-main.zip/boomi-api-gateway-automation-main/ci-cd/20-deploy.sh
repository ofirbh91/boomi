#!/usr/bin/env bash
# Copyright (c) Anthony Rabiaza 2026-09-08
# Updated 2026-09-08
# ci-cd/20-deploy.sh <stage> - Plane A package + deploy.
# For each component in DEPLOYABLES, boomi-deploy.sh creates an immutable
# PackagedComponent (version) and deploys it to the stage's environment.
# The same package flow is used for every stage, so Dev/Test/Prod get
# identical bits differentiated only by environment extensions (see 30).

set -euo pipefail
STAGE="${1:-dev}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib/common.sh
. "${HERE}/lib/common.sh"
# shellcheck source=config.sh
. "${HERE}/config.sh"
load_env

env_id="$(env_id_for_stage "$STAGE")"
[ -n "$env_id" ] || die "No environment ID for stage '${STAGE}'. Set BOOMI_ENVIRONMENT_ID or BOOMI_ENVIRONMENT_ID_${STAGE^^} in .env"

if [ "${#DEPLOYABLES[@]}" -eq 0 ]; then
  log_warn "DEPLOYABLES is empty in ci-cd/config.sh - nothing to deploy."
  log_warn "Add deployable component paths (proxy / API service / listen process) first."
  exit 0
fi

log_info "Deploy stage=${STAGE} → environment ${env_id}"
# boomi-deploy.sh reads BOOMI_ENVIRONMENT_ID from env; scope it per stage.
export BOOMI_ENVIRONMENT_ID="$env_id"

for rel in "${DEPLOYABLES[@]}"; do
  [ -f "${PROJECT_ROOT}/${rel}" ] || die "deployable not found: ${rel}"
  log_info "package+deploy ${rel}"
  boomi deploy "$rel" --deployment-notes "ci-cd ${STAGE} $(date -u +%Y-%m-%dT%H:%M:%SZ)"
done

log_info "Deploy complete for stage=${STAGE}."
