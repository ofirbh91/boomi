# Security guide: Boomi APIs

How to call, trace and govern APIs exposed through a Boomi API Gateway, step by step, with the
scripts in this repository, and what each step should show. Script setup is in
[README.md](README.md).

The examples use three APIs deployed to one Boomi environment:

- **Dummy API**: an API Service with JSON routes `/add`, `/sub` and `/abs` (Boomi processes
  `WSS: Dummy Add`, `Sub` and `Abs`).
- **PetStore Spring API Proxy**: an API Proxy in front of a PetStore backend.
- **HTTPdlight API Proxy**: an API Proxy in front of a small HTTP status backend.

The outputs shown are from real runs; your ids, times and hosts will differ.

## Placeholders

Replace these with the values of your own setup:

| Placeholder | Meaning |
|-------------|---------|
| `<your-domain.com>` | Your DNS domain |
| `https://gateway.<your-domain.com>` | Public URL of the Boomi API Gateway |
| `<environment-name>` | The Boomi environment the APIs are deployed to |
| `<dummy-api-id>`, `<petstore-api-id>`, `<httpdlight-api-id>` | Deployed API ids (from `gateway-api.sh list`) |
| `<gateway-service-name>` | OpenTelemetry service name of the gateway spans: `Boomi-api-gateway-<gateway name>` |
| `<runtime-service-name>` | OpenTelemetry service name of the runtime spans: the runtime's name in Boomi |
| `<runtime-host>:<port>` | Address the gateway uses to call the Boomi runtime |
| `<namespace>` | Kubernetes namespace of the Boomi runtime, gateway and collector |
| `<collector-host>` | Host name of the OpenTelemetry collector, as the runtime and gateway reach it (in Kubernetes: `otel-collector.<namespace>.svc.cluster.local`) |
| `<deployment-environment>` | Value of the `deployment.environment` resource attribute (for example `dev`, `prod`) |
| `<client-ip>` | IP address of the calling client |
| `<client-user-agent>` | `User-Agent` header sent by the calling client |

Screenshots are in `docs/images/`.

## 1. Before you start

Run everything from the project root. The scripts read `.env` there (see `.env.example`).

```bash
bash ci-cd/00-check.sh        # both API planes reachable and authenticated

# The deployed APIs of the environment (ids change on redeploy, so list them each time)
bash ci-cd/gateway-api.sh list | jq -r '.deployedApis[]
  | select(.environment.name == "<environment-name>") | [.id, .component.name, .version] | @tsv'
```

| API | Deployed API id | Example call |
|-----|-----------------|-------------|
| Dummy API | `<dummy-api-id>` | `POST https://gateway.<your-domain.com>/ws/rest/dummy/add` with `{"number1": 2, "number2": 3}` |
| PetStore Spring API Proxy | `<petstore-api-id>` | `GET https://gateway.<your-domain.com>/ws/rest/petstore/v3/pet/findByStatus?status=available` |
| HTTPdlight API Proxy | `<httpdlight-api-id>` | `GET https://gateway.<your-domain.com>/ws/rest/httpdlight/v5?status=up` |

Every call needs an API key from a subscription (header `x-api-key`). In the examples, the Dummy
API's plans allow 1 request per second.

**API Management > Configure APIs and Applications > Deployed APIs**, tab **APIs by Gateway**,
filtered on the environment:

![Deployed APIs in the API Management console](docs/images/security-guide-01-deployed-apis.png)

The rest of this section sets up the telemetry the later sections read: the Boomi runtime and
the API Gateway export OpenTelemetry (traces, metrics, logs) over OTLP/gRPC to an OpenTelemetry
Collector, which sends it to Azure Application Insights.

```mermaid
flowchart LR
  rt["Boomi runtime<br/>Runtime Management > Observability"]
  gw["Boomi API Gateway<br/>OpenTelemetry Settings"]
  col["OpenTelemetry Collector (contrib)<br/>:4317 gRPC / :4318 HTTP"]
  sec[("Secret<br/>connection string")]
  appi["Azure Application Insights<br/>+ Log Analytics workspace"]

  rt -- "OTLP gRPC" --> col
  gw -- "OTLP gRPC" --> col
  sec -. env .-> col
  col -- "azure_monitor exporter<br/>HTTPS" --> appi
```

Why a collector in between: the Boomi runtime exports OTLP over gRPC only, while Application
Insights ingests through its connection string (Track API); the collector's `azure_monitor`
exporter does the translation. It also drops noise (FINE logs, health checks) before it is
billed, and fixes how gateway spans are classified in Azure. Azure Monitor's native OTLP
ingestion (Data Collection Endpoint + Rule) is not used: it authenticates only with Microsoft
Entra ID, which needs a service principal from outside Azure.

### 1.1 Azure: Application Insights

In the Azure portal, keep all three resources in the same region:

1. **Resource groups > + Create**: a resource group for the observability resources.
2. **Log Analytics workspaces > + Create**: a workspace in that group. Cost guard: workspace >
   **Settings > Usage and estimated costs > Daily cap > On**, for example `0.15` GB/day (the first
   5 GB/month per billing account is free, about 0.16 GB/day). Once the cap is hit, ingestion
   stops until the next day.
3. **Application Insights > + Create**: Resource Mode **Workspace-based**, the workspace from
   step 2, **OTLP support: Off** (On creates the Entra-authenticated DCE/DCR path, not used here).
   Then **Usage and estimated costs > Daily cap > On**, same value (the lower cap wins); the
   default 100 GB/day would never trigger.
4. Application Insights > **Overview > Connection String**: copy it. It looks like
   `InstrumentationKey=...;IngestionEndpoint=https://<region>.in.applicationinsights.azure.com/;LiveEndpoint=...;ApplicationId=...`.
   Treat it as a secret (anyone holding it can write to your workspace) and don't save it to a
   file. It works only while **Configure > Properties > Local Authentication** is **Enabled**
   (the default); otherwise ingestion fails with HTTP 401.

The **Create** page, **Basics** tab: the resource group, the Log Analytics workspace from step 2,
**OTLP support: Off**. The current portal no longer shows a Resource Mode choice: every new
resource is workspace-based.

![Create Application Insights](docs/images/security-guide-02-azure-create-appinsights.png)

**Usage and estimated costs > Daily cap** on the Application Insights resource, at the
workspace's value:

![Application Insights daily cap](docs/images/security-guide-03-azure-daily-cap.png)

**Overview > Essentials**: the **Connection string** (masked here) next to the workspace. The
red banner is what a hit daily cap looks like:

![Application Insights connection string](docs/images/security-guide-04-azure-connection-string.png)

### 1.2 OpenTelemetry Collector

Use the **contrib** image (`otel/opentelemetry-collector-contrib`), which has the
`azure_monitor` exporter; the manifests below were run on `0.161.0`. They are for Kubernetes, in
the namespace of the runtime and gateway; elsewhere (Docker, a VM) use the same `config.yaml`
and pass the connection string in the `APPLICATIONINSIGHTS_CONNECTION_STRING` environment
variable.

**Secret.** Paste the connection string at a silent prompt, so it never reaches the disk. Run the
`read` line on its own, then the rest:

```bash
read -rsp 'Application Insights connection string: ' CS; echo
```

```bash
kubectl -n <namespace> create secret generic azure-monitor-secret \
  --from-literal=connection-string="$CS" --dry-run=client -o yaml | kubectl apply -f -
unset CS
```

**Collector config** (`configmap.yaml`). What each processor does, for Azure:

| Processor | Does |
|-----------|------|
| `memory_limiter` | Keeps the collector under its container memory limit |
| `filter/boomi_fine` | Drops java.util.logging FINE/FINER/FINEST log records (about 99% of Boomi log volume under load, billed per GB), but keeps deployment and WSS-route loggers at any level. The Boomi side cannot turn FINE off |
| `resource` | Tags every signal with `deployment.environment` and `k8s.namespace.name` (in `customDimensions` in Azure). `service.namespace` is not set on purpose: the exporter would prefix it to `cloud_RoleName` |
| `tail_sampling/azure` | Drops gateway-internal traces (`/_admin/*`, `/_node/*` health checks) and health probes (`kube-probe/*`, the gateway's backend check `GET /`) before they are billed. Adds 10 s of latency (`decision_wait`) |
| `transform/boomi_runtime_server_kind` | Boomi runtimes emit only INTERNAL spans, so Azure would file them all as dependencies and the runtime would have no requests. This makes the runtime's Web Services entry span (`<METHOD> /ws/...`) a SERVER span, so each call is a request of the runtime and the Application map draws gateway > runtime |
| `transform/azure_http_semconv` | The gateway emits only the old HTTP semantic-convention keys (`http.method`, `http.status_code`, ...), and the exporter reads only the new ones. Without this, Azure shows gateway 4xx and 5xx as successful, with response code `0`. It copies each old key to its new key where missing, so Azure gets the real HTTP code and marks 4xx/5xx as failed |
| `batch` | Batches before export |

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: otel-collector-config
  namespace: <namespace>
  labels:
    app: otel-collector
data:
  config.yaml: |
    extensions:
      health_check:
        endpoint: 0.0.0.0:13133

    receivers:
      otlp:
        protocols:
          grpc:
            endpoint: 0.0.0.0:4317   # the Boomi runtime and gateway export gRPC only
          http:
            endpoint: 0.0.0.0:4318

    processors:
      memory_limiter:
        check_interval: 1s
        limit_mib: 400               # container limit is 512Mi
        spike_limit_mib: 100

      # Drop java.util.logging FINE/FINER/FINEST records, but keep deploy/attach and
      # WSS-route loggers at any level.
      filter/boomi_fine:
        error_mode: ignore
        logs:
          log_record:
            - 'IsMatch(attributes["logger.level"], "^FINE(R|ST)?$") and not IsMatch(attributes["logger.name"], "^com\\.boomi\\.(container\\.deployment|connector\\.wss\\.route)")'

      # service.namespace is NOT set on purpose: azure_monitor prefixes it to cloud_RoleName.
      resource:
        attributes:
          - key: deployment.environment
            value: <deployment-environment>
            action: upsert
          - key: k8s.namespace.name
            value: <namespace>
            action: upsert

      # Drop gateway-internal and health-probe traces before they are billed. A trace is
      # dropped when ANY span matches. A real API call whose backend path is exactly "/"
      # through the gateway would be dropped too.
      tail_sampling/azure:
        decision_wait: 10s
        num_traces: 10000
        policies:
          - name: keep_all
            type: always_sample
          - name: drop_gateway_internal
            type: drop
            drop:
              drop_sub_policy:
                - name: admin_node_paths
                  type: string_attribute
                  string_attribute:
                    key: http.target
                    values: ['^/_(admin|node)/']
                    enabled_regex_matching: true
          - name: drop_health_probes
            type: drop
            drop:
              drop_sub_policy:
                - name: probe_span
                  type: ottl_condition
                  ottl_condition:
                    error_mode: ignore
                    span:
                      - 'IsMatch(attributes["user_agent.original"], "^kube-probe/") or (attributes["url.path"] == "/" and IsMatch(attributes["user_agent.original"], "Boomi-api-gateway"))'

      # Boomi runtimes emit only INTERNAL spans. Make the Web Services Server entry span
      # ("<METHOD> /ws/...") a SERVER span, so Azure records it as a request of the runtime.
      # Boomi's own spans (Execute process, connectors, shapes) stay INTERNAL.
      transform/boomi_runtime_server_kind:
        error_mode: ignore
        trace_statements:
          - context: span
            statements:
              - 'set(span.kind, SPAN_KIND_SERVER) where resource.attributes["service.name"] == "<runtime-service-name>" and span.kind == SPAN_KIND_INTERNAL and IsMatch(span.name, "^[A-Z]+ /ws/")'

      # Map the gateway's OLD HTTP semconv keys to the new ones read by azure_monitor
      # (http.request.method makes a span HTTP; http.response.status_code gives responseCode
      # and success = 100..399). Copies only where the new key is missing; the old keys stay.
      # http.route is stripped of its query string so requests group by route.
      # Known gap: the runtime's request span carries no status code, so Azure shows it as
      # "1"/success even when the gateway returns 4xx.
      transform/azure_http_semconv:
        error_mode: ignore
        trace_statements:
          - context: span
            conditions:
              - 'IsMatch(resource.attributes["service.name"], "^Boomi-api-gateway")'
            statements:
              - 'set(span.attributes["http.request.method"], span.attributes["http.method"]) where span.attributes["http.request.method"] == nil and span.attributes["http.method"] != nil'
              - 'set(span.attributes["http.response.status_code"], Int(span.attributes["http.status_code"])) where span.attributes["http.response.status_code"] == nil and span.attributes["http.status_code"] != nil'
              - 'set(span.attributes["url.scheme"], span.attributes["http.scheme"]) where span.attributes["url.scheme"] == nil and span.attributes["http.scheme"] != nil'
              - 'set(span.attributes["url.full"], span.attributes["http.url"]) where span.attributes["url.full"] == nil and span.attributes["http.url"] != nil'
              - 'set(span.attributes["url.query"], span.attributes["http.target"]) where span.attributes["url.query"] == nil and IsMatch(span.attributes["http.target"], "\\?")'
              - 'replace_pattern(span.attributes["url.query"], "^[^?]*\\?", "")'
              - 'set(span.attributes["url.path"], span.attributes["http.target"]) where span.attributes["url.path"] == nil and span.attributes["http.target"] != nil'
              - 'replace_pattern(span.attributes["url.path"], "\\?.*$", "")'
              - 'replace_pattern(span.attributes["http.route"], "\\?.*$", "")'
              - 'set(span.attributes["server.address"], span.attributes["net.host.name"]) where span.kind == SPAN_KIND_SERVER and span.attributes["server.address"] == nil and span.attributes["net.host.name"] != nil'
              - 'set(span.attributes["server.port"], Int(span.attributes["net.host.port"])) where span.kind == SPAN_KIND_SERVER and span.attributes["server.port"] == nil and span.attributes["net.host.port"] != nil'
              - 'set(span.attributes["server.address"], span.attributes["net.peer.name"]) where span.kind == SPAN_KIND_CLIENT and span.attributes["server.address"] == nil and span.attributes["net.peer.name"] != nil'
              - 'set(span.attributes["server.port"], Int(span.attributes["net.peer.port"])) where span.kind == SPAN_KIND_CLIENT and span.attributes["server.port"] == nil and span.attributes["net.peer.port"] != nil'
              - 'set(span.attributes["client.address"], span.attributes["http.client_ip"]) where span.attributes["client.address"] == nil and span.attributes["http.client_ip"] != nil'

      batch:
        send_batch_size: 1024
        timeout: 5s

    exporters:
      azure_monitor:
        connection_string: ${env:APPLICATIONINSIGHTS_CONNECTION_STRING}
        maxbatchsize: 1024
        maxbatchinterval: 10s
        sending_queue:
          enabled: true
          num_consumers: 4
          queue_size: 1000

      # One summary line per batch in the collector log: proof the Boomi side is exporting.
      # Remove from the pipelines once validated.
      debug:
        verbosity: basic
        sampling_initial: 5
        sampling_thereafter: 200

    service:
      extensions: [health_check]
      pipelines:
        traces:
          receivers: [otlp]
          processors: [memory_limiter, resource, tail_sampling/azure, transform/boomi_runtime_server_kind, transform/azure_http_semconv, batch]
          exporters: [azure_monitor, debug]
        metrics:
          receivers: [otlp]
          processors: [memory_limiter, resource, batch]
          exporters: [azure_monitor, debug]
        logs:
          receivers: [otlp]
          processors: [memory_limiter, filter/boomi_fine, resource, batch]
          exporters: [azure_monitor, debug]
```

With several runtimes, replace the `service.name ==` test in
`transform/boomi_runtime_server_kind` with an `IsMatch` on a regular expression that matches
all their names.

**Deployment and Service** (`deployment.yaml`). One stateless replica is enough for one runtime
and one gateway; ClusterIP, since both producers are in the cluster:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: otel-collector
  namespace: <namespace>
  labels:
    app: otel-collector
spec:
  replicas: 1
  selector:
    matchLabels:
      app: otel-collector
  template:
    metadata:
      labels:
        app: otel-collector
    spec:
      securityContext:
        runAsNonRoot: true
        runAsUser: 10001
      containers:
        - name: otel-collector
          image: otel/opentelemetry-collector-contrib:0.161.0   # contrib: has the azure_monitor exporter
          imagePullPolicy: IfNotPresent
          args: ["--config=/conf/config.yaml"]
          ports:
            - name: otlp-grpc
              containerPort: 4317
            - name: otlp-http
              containerPort: 4318
            - name: health
              containerPort: 13133
          env:
            - name: APPLICATIONINSIGHTS_CONNECTION_STRING
              valueFrom:
                secretKeyRef:
                  name: azure-monitor-secret
                  key: connection-string
            - name: GOMEMLIMIT
              value: "400MiB"
          resources:
            requests:
              cpu: "100m"
              memory: "128Mi"
            limits:
              cpu: "500m"
              memory: "512Mi"
          readinessProbe:
            httpGet:
              path: /
              port: 13133
            periodSeconds: 10
          livenessProbe:
            httpGet:
              path: /
              port: 13133
            periodSeconds: 30
            initialDelaySeconds: 10
          securityContext:
            allowPrivilegeEscalation: false
            readOnlyRootFilesystem: true
            capabilities:
              drop: ["ALL"]
          volumeMounts:
            - name: config
              mountPath: /conf
              readOnly: true
      volumes:
        - name: config
          configMap:
            name: otel-collector-config
---
apiVersion: v1
kind: Service
metadata:
  name: otel-collector
  namespace: <namespace>
  labels:
    app: otel-collector
spec:
  type: ClusterIP
  selector:
    app: otel-collector
  ports:
    - name: otlp-grpc
      port: 4317
      targetPort: 4317
      protocol: TCP
    - name: otlp-http
      port: 4318
      targetPort: 4318
      protocol: TCP
```

**Apply and check:**

```bash
kubectl apply -f configmap.yaml
kubectl apply -f deployment.yaml
kubectl -n <namespace> rollout status deployment/otel-collector --timeout=120s
kubectl -n <namespace> logs deploy/otel-collector --tail=50
```

The log should end with `Everything is ready. Begin running and processing data.` and have no
`error` lines. No data flows yet; the Boomi side comes next. The collector does not hot-reload:
after a config change, apply the ConfigMap and run
`kubectl -n <namespace> rollout restart deployment/otel-collector`. To validate a config first:
`otelcol-contrib validate --config=config.yaml` (with any dummy
`APPLICATIONINSIGHTS_CONNECTION_STRING` set).

### 1.3 Boomi Observability: runtime and gateway

Neither the runtime nor the gateway needs a new image or a redeploy: both have native
OpenTelemetry export, switched on in the Boomi platform.

**Runtime** (Atom or Molecule):

1. **Integration > Manage > Runtime Management**, select the environment and the runtime, then
   **Settings & Configuration > Observability**. If the entry is missing, the runtime release is
   too old for native observability.
2. Toggle **Enable Observability** on.
3. **Global Endpoint**: URL `http://<collector-host>:4317` (plaintext gRPC inside the cluster),
   **Authentication Type** None, no custom headers.
4. **Metrics**: **Export metrics** on, no endpoint override. **Logs**: **Export logs** on,
   **Logs to collect: All logs** (the collector drops FINE). **Traces**: **Export traces** on,
   **Processes to collect: All processes**, or **Specific processes** to limit volume and cost.
5. **Save**, and answer **Yes, restart the plugin now**. Only the observability plugin restarts,
   not the runtime; nothing is exported during the restart.

If the runtime sends its JVM HTTP traffic through a proxy (`http.proxyHost` /
`https.proxyHost`), the observability plugin uses it too, and Java ignores the `NO_PROXY`
environment variable. Either exclude the collector with `-Dhttp.nonProxyHosts` (in
`ATOM_VMOPTIONS_OVERRIDES`, where `|` is the separator, a wildcard such as `*local*` covers
`localhost` and `*.cluster.local`), or let the proxy `CONNECT` to the collector on ports 4317 and
4318.

The runtime's **Observability** page: global endpoint, then the Metrics, Logs and Traces
settings expanded (in this example, log export is off):

![Runtime Observability: global endpoint](docs/images/security-guide-05-boomi-runtime-observability-a.png)

![Runtime Observability: export toggles](docs/images/security-guide-05-boomi-runtime-observability-b.png)

![Runtime Observability: metrics](docs/images/security-guide-05-boomi-runtime-observability-c.png)

![Runtime Observability: logs](docs/images/security-guide-05-boomi-runtime-observability-d.png)

![Runtime Observability: traces](docs/images/security-guide-05-boomi-runtime-observability-e.png)

**API Gateway:**

1. **API Management > Configure Server > API Gateways**, select the gateway, then **Settings &
   Configuration > OpenTelemetry Settings**. If it already exports somewhere, note the current
   **Exporter Endpoint/URL** first (your rollback value).
2. **OpenTelemetry** enabled. **Global Setting**: **Exporter Endpoint/URL**
   `grpc://<collector-host>:4317`.
3. **Compression** GZIP, **SSL** disabled (plaintext inside the cluster), no headers.
4. **Enable Traces**, **Enable Metrics** and **Enable Log** on, with no **Override ... Setting**
   (a signal with an override skips the collector and never reaches Azure).
5. **Save**. Saving restarts the API Gateway (a brief interruption of service), which it needs to
   read new export settings.

The per-API tracing modes (Basic, Intermediate, Advanced; Advanced is section 6) are separate
and still apply.

The gateway's **OpenTelemetry Settings** (in this example, log export is off):

![Gateway OpenTelemetry: enabled and endpoint](docs/images/security-guide-06-boomi-gateway-opentelemetry-a.png)

![Gateway OpenTelemetry: compression, SSL and headers](docs/images/security-guide-06-boomi-gateway-opentelemetry-b.png)

![Gateway OpenTelemetry: traces, metrics and logs](docs/images/security-guide-06-boomi-gateway-opentelemetry-c.png)

### 1.4 Check the telemetry arrives

**Collector:** `kubectl -n <namespace> logs deploy/otel-collector --tail=100`. The `debug`
exporter logs one summary line per batch (`Traces ... "spans": 51`, `Logs ...`, `Metrics ...`).
`Exporting failed` lines naming `azure_monitor` point at the connection string (HTTP 400/401) or
at egress to `*.in.applicationinsights.azure.com:443` (timeouts).

**Azure:** Application Insights > **Monitoring > Logs**, KQL mode, after 2 to 5 minutes:

```kusto
// what arrived, per role, last 30 min
union requests, dependencies, traces, exceptions, customMetrics
| where timestamp > ago(30m)
| summarize count() by itemType, cloud_RoleName
```

Both `<runtime-service-name>` and `<gateway-service-name>` should be listed. Where the signals
land:

| OpenTelemetry | Application Insights |
|---------------|----------------------|
| Spans, kind SERVER / CONSUMER | `requests`: gateway API calls, and the runtime's Web Services entry span |
| Spans, kind CLIENT / PRODUCER / INTERNAL | `dependencies`: process and shape steps (InProc), gateway > runtime and other backend calls (HTTP) |
| Logs | `traces` (trace id in `operation_Id`, `logger.*` in `customDimensions`) |
| Logs and spans with exception attributes | `exceptions` |
| Metrics | `customMetrics` (JVM heap, GC, threads, gateway metrics) |
| `service.name` | `cloud_RoleName` |
| `service.instance.id` | `cloud_RoleInstance` |

Not available through this path: Live Metrics (needs the Azure SDK's QuickPulse channel).

Application Insights **Investigate > Application map**: the gateway calling the runtime (the
runtime is a request node thanks to `transform/boomi_runtime_server_kind`):

![Application map](docs/images/security-guide-07-azure-application-map.png)

The KQL query of this section in **Logs**: item counts per `itemType` and `cloud_RoleName`, both
roles present:

![Telemetry per role](docs/images/security-guide-08-azure-telemetry-per-role.png)

## 2. Send a traced call

Send a W3C `traceparent` and the same 32-hex trace id in `X-Gateway-Transaction-Id`. One value
then finds the call in the traces, the Boomi call log and the response.

`traceparent` is `00-<32 hex trace id>-<16 hex parent span id>-01`: lowercase hex, neither id all
zeros, and keep `-01` (sampled), or the call may not be traced.

**From the command line:**

```bash
U=https://gateway.<your-domain.com>/ws/rest/dummy
read -rs API_KEY                                     # not written to disk
T=$(uuidgen | tr -d - | tr A-F a-f); S=$(uuidgen | tr -d - | tr A-F a-f | cut -c1-16)
curl -s -D - -X POST "$U/add" -H "x-api-key: $API_KEY" -H 'Content-Type: application/json' \
  -H "traceparent: 00-$T-$S-01" -H "X-Gateway-Transaction-Id: $T" \
  -d '{"number1": 2, "number2": 3}'
echo "trace id: $T"
```

**From Postman** (tested with Postman web and the Postman Desktop Agent): set the API key and the
two headers on the **collection**, so every request in it inherits them. Postman web sends requests
through its Cloud Agent, on Postman's servers, which fails with "Couldn't resolve host" when the
gateway's name only resolves inside your network: install the **Postman Desktop Agent** and pick
it in the agent selector at the bottom right (or use the Postman desktop app).

1. Collection > **Authorization**: type **API Key**, key `x-api-key`, value `{{apiKey}}`,
   **Add to: Header**. Keep `apiKey` in an environment, not in the collection, so it is not
   exported or shared with it; click **Secure** on the variable to keep its value in the Postman
   Vault. A request on another API with its own key sets its own **Authorization** (API Key, value
   `{{apiKeyOther}}`) instead of inheriting the collection's.
2. Collection > **Scripts > Pre-request**: a new trace id on each send, in both headers:

   ```js
   const hex = () => pm.variables.replaceIn('{{$guid}}').replace(/-/g, '').toLowerCase();
   const traceId = hex(), spanId = hex().slice(0, 16);
   pm.request.headers.upsert({ key: 'traceparent', value: `00-${traceId}-${spanId}-01` });
   pm.request.headers.upsert({ key: 'X-Gateway-Transaction-Id', value: traceId });
   pm.collectionVariables.set('lastTraceId', traceId);
   ```

3. Collection > **Scripts > Post-response**: print the ids to the Postman Console
   (**View > Show Postman Console**), to paste into Application Insights or the call log:

   ```js
   console.log(`trace id: ${pm.collectionVariables.get('lastTraceId')}`);
   console.log(`x-gateway-transaction-id: ${pm.response.headers.get('x-gateway-transaction-id') || 'none'}`);
   console.log(`x-global-uid: ${pm.response.headers.get('x-global-uid') || 'none'}`);
   ```

Remove any per-request `traceparent` header. Postman sends no root span to your collector, so the parent span named in `traceparent` never arrives: the gateway's
server span is the top of the trace (some trace viewers flag the missing parent). The trace is
otherwise complete.

The collection's **Authorization** tab: the key comes from `{{apiKey}}` in the selected environment
(top right):

![Postman collection authorization](docs/images/security-guide-09-postman-authorization.png)

The collection's **Scripts**, **Pre-request** (step 2) and **Post-response** (step 3):

![Postman pre-request script](docs/images/security-guide-10-postman-pre-request.png)

![Postman post-response script](docs/images/security-guide-10-postman-post-response.png)

### What to expect: id headers

Three calls to `POST /ws/rest/dummy/add`:

| Call | Sent by the client | Response headers | Trace | Boomi call log (`deployedApiCallDetail`) |
|------|--------------------|------------------|-------|-------------------------------------------|
| A: valid | `traceparent: 00-5a51a6e89458c26cf8920411e113fbc6-...-01`, `x-gateway-transaction-id: CLIENT-TX-0001`, `x-correlation-id: CLIENT-CORR-0001` | 201, `x-gateway-transaction-id: G:CLIENT-TX-0001`, `x-gravitee-request-id: ddd528af-...` (new), `x-global-uid: execution-ba975866-...` | **Trace id `5a51a6e8...`, the caller's**, with gateway and runtime spans | `transactionId: G:CLIENT-TX-0001`, `execution.id: execution-ee2190f8-...` |
| B: valid | no id | 201, `x-gateway-transaction-id: G:2332d9a9-...` (= `x-gravitee-request-id`), `x-global-uid: execution-69368eaa-...` | New trace id, **not returned** to the caller | `transactionId: G:2332d9a9-...`, `execution.id: execution-01655e87-...` |
| C: rejected by `json-validation` | `x-gateway-transaction-id: CLIENT-TX-0003` | 400, **no id header** | Gateway spans only | `transactionId: G:CLIENT-TX-0003`, status 400, no execution |

A gateway rejection (400, 429, 401) returns **no** id header, so send your own id if you need
to quote it. The `G:` prefix comes from a `transform-headers` policy on each API.

### What to expect: calls from Postman

Test: `POST https://gateway.<your-domain.com>/ws/rest/dummy/add?test-param=123` with
`test-header: ABC`, the collection's API key and scripts above, sent through the Postman Desktop
Agent (Postman web, 2026-11-02):

| | Error case | Working case |
|---|---|---|
| Body | `{"number1":"A","number2":3}` | `{"number1":2,"number2":3}` |
| Status, Postman time | 400 Bad Request, 6.15 ms | 201 Created, 114.88 ms |
| `traceparent` sent | `00-86e26dee2aab4a6f9208b291aa9d14a8-...-01` | `00-82ff0b05104e455d972a0eb411e6cfb2-d88d47b6a79f4176-01` |
| `X-Gateway-Transaction-Id` sent | `86e26dee2aab4a6f9208b291aa9d14a8` | `82ff0b05104e455d972a0eb411e6cfb2` |
| `x-gateway-transaction-id` returned | none | `G:82ff0b05104e455d972a0eb411e6cfb2` |
| `x-gravitee-request-id`, `x-global-uid` returned | none | yes; `x-global-uid: execution-4260e0a8-3d8f-43f9-9e79-480db6f14d77-2026.11.02` |
| Postman Console | trace id, `x-gateway-transaction-id: none`, `x-global-uid: none` | trace id, `G:<trace id>`, `execution-...` |
| Top item in Application Insights | Gateway request, 400, 2.9 ms | Gateway request, 201, 110.1 ms |
| Items | Gateway only: the policies, ending at `json-validation` (1.7 ms) | Gateway and runtime (`atom-service...` request 105.9 ms, `Execute process` 84.5 ms), 31 items, no caller span |
| `user_agent.original` on the gateway request | `PostmanRuntime/2.12.2` | `PostmanRuntime/2.12.2` |

The screenshots below are from a later pair of sends (2026-11-03), so their ids and times differ
from the table, and Postman had moved on to `PostmanRuntime/7.56.1`.

The working case, request body on top and the 201's headers below
(`x-gateway-transaction-id: G:<trace id>`, `x-global-uid`, `x-gravitee-request-id`):

![Postman working call](docs/images/security-guide-15-postman-working-call.png)

The error case: the 400's body (with the per-route `expected` text) and its headers, none of them
an id header:

![Postman rejected call](docs/images/security-guide-16-postman-rejected-call.png)

The Postman Console after the two sends, with the ids logged by the post-response script:

![Postman Console: logged ids](docs/images/security-guide-17-postman-console-a.png)

Expanding the 201 shows the request headers Postman sent: `traceparent` and
`X-Gateway-Transaction-Id` carrying the same trace id, and `User-Agent: PostmanRuntime/7.56.1`:

![Postman Console: request headers](docs/images/security-guide-17-postman-console-b.png)

Application Insights end-to-end transaction details of the working call (search the trace id):
the gateway request at the top, its policies, `json-validation`, then the runtime items. With no
root span from Postman, the gateway request is the top of the trace:

![Azure transaction, Postman call](docs/images/security-guide-18-azure-postman-call.png)

Cross-host span order in a trace is only as good as the clock sync between the hosts (client,
gateway, runtime). Keep them on NTP; with skewed clocks, spans from different hosts can show out
of order.

## 3. Find a call

**Finding a call from what the caller has:**

| The caller has | Find the trace | Find the call log entry |
|----------------|----------------|-------------------------|
| Its trace id | Application Insights: `operation_Id` (below) | Only if it was also sent as the transaction id |
| `x-gateway-transaction-id` | Through the call log's execution id (below), or by header during an Advanced session | `deployedApiCallDetail`, `transactionId = G:<id>` |
| `x-global-uid` | Application Insights: span attribute `execution.id` (below) | Through the call log's execution id (top level) |

**In the Boomi call log** (status, URL, top-level execution id; gateway rejections included). Set
the time window around the call, in UTC, and the transaction id you sent:

```bash
APIM_GRAPHQL_VARS='{"in":{"requestTsStart":"2026-10-15T02:25:00Z","requestTsEnd":"2026-10-15T02:30:00Z","rowLimit":50}}' \
bash -c 'source ci-cd/lib/common.sh && load_env && echo "query(\$in: DeployedApiCallDetailInput!) {
  deployedApiCallDetail(input: \$in) { data { requestTs transactionId status requestUrl execution { id } } } }" \
  | apim_graphql - ".data.deployedApiCallDetail.data[]"' | jq -c 'select(.transactionId == "G:<T>")'
```

In the UI: API Management **Dashboard > Dashboard**, open the deployed API (here `Dummy API` on
`Homelab-Basic-K3S`), then **Call Logs**. One row per call, gateway rejections included (the 400
from `json-validation` above the 201). The UI has no transaction id column, so find the call by
time, URL and status; the GraphQL query above is the way to match on the transaction id. Scrolled
to the right, the **Execution ID** column links the 201 to Process Reporting (none for the 400,
which never reached the runtime):

![Boomi call log entry](docs/images/security-guide-23-boomi-call-log.png)

**In Azure Application Insights:** the trace id is the `operation_Id`. Allow 2 to 5 minutes of
ingestion latency (plus the collector's 10 s tail-sampling wait), so an empty result right after
the call doesn't mean the trace is missing. Transaction search finds it, or list everything
recorded for one call:

```kusto
union requests, dependencies
| where operation_Id == "<trace id>"
| project timestamp, itemType, name, resultCode, success, duration
| order by timestamp asc
```

From an `x-global-uid` (the runtime execution id), find the trace id:

```kusto
union requests, dependencies
| where tostring(customDimensions["execution.id"]) == "<x-global-uid>"
| distinct operation_Id
```

Azure gets the gateway and runtime spans through the collector of section 1.2, not a root span
sent by the API client (unless the collector receives it too). With its `transform/azure_http_semconv`, which
gives Azure the real HTTP code and marks HTTP >= 400 as failed, you should see:

| Item | Response code | Failed? |
|------|---------------|---------|
| Gateway request (`<gateway-service-name>`) | The HTTP code (200, 201, 400, 422, 429, ...) | Yes for 4xx and 5xx, 404 included |
| Gateway call to the runtime (dependency `<runtime-host>:<port>`) | The runtime's HTTP code | Yes for 4xx and 5xx |
| Runtime request (`<runtime-service-name>`, `POST /ws/...`) | `1` | No, even when the call failed (known gap) |
| Runtime step that failed (for example the 422 path) | | Yes, its own failed item |

Without that mapping, gateway rejections show as successful in Azure: the gateway's server span
keeps status unset on a 4xx (section 5). Verified: a 400 from `json-validation`, a 422 from the
process and a 429 from `rate-limit` are failed items in Azure (the 422 with the runtime's error
span as a second failed item), and 2xx calls are not.

A working call in Application Insights (**End-to-end transaction details**, here `POST /sub`,
200): the gateway request, its policy items (`json-validation` included), the dependency to the
runtime, and the runtime's request with the process shapes. The right pane shows the request
properties, with the response code and success from `transform/azure_http_semconv`:

![Azure transaction, working call](docs/images/security-guide-21-azure-working-call.png)

The error case in Application Insights: the failed gateway request (red), the policy items ending
at `json-validation`, no runtime items, and the `gateway.error.processing` item with
`failure.key` `JSON_INVALID_PAYLOAD` and the error body returned to the client (framed):

![Azure transaction, rejected call](docs/images/security-guide-22-azure-rejected-call.png)

**Investigate > Search**, **View as: Traces**: one row per trace, with its duration, item count and
failed items (here a 400 on `/add`). Paste a trace id in the search box to find one call, then open
it for the end-to-end transaction details:

![Azure transaction search](docs/images/security-guide-24-azure-transaction.png)

## 4. Runtime logs and errors (Dummy API)

`WSS: Dummy Add`, `Sub` and `Abs` log the request and the response (headers and body) with Notify
shapes, always on. In the trace they are the `Notify` spans (attribute `userEvent.message`), which
Azure lists as `Notify` dependencies (`customDimensions["userEvent.message"]`). For a valid `POST /add`, the
two log lines in Log Monitoring:

```text
Dummy Add: [REQ] headers={
    "Accept": "*/*",
    "Accept-Encoding": "deflate, gzip",
    "Content-Type": "application/json",
    "Host": "<runtime-host>:<port>",
    "Test-Header": "ABC"
} body={
  "number1": 2,
  "number2": 3
}

Dummy Add: [RESP] headers={} body={
  "sum" : 5
}
```

Note that `Host` and `Accept-Encoding` are the values on the gateway-to-runtime call, not what
the client sent: the runtime sees the request as the gateway forwards it.

In Process Reporting (reached from the call log's **Execution ID** link, or by searching the
execution id), the execution's **View Process Log**: the `Log request` step writes the `[REQ]`
line, and the `Try/Catch` step launches the continuation as `execution-2bdd5a20-...`, the
`x-global-uid` returned to the caller (the call log links to the top-level execution, not to the
continuation):

![Notify log lines in Boomi: request](docs/images/security-guide-25-boomi-notify-logs-a.png)

On the log's second page, the `Log response` step with the `[RESP]` line:

![Notify log lines in Boomi: response](docs/images/security-guide-25-boomi-notify-logs-b.png)

```kusto
dependencies
| where name == "Notify" and cloud_RoleName == "<runtime-service-name>"
| project timestamp, operation_Id, message = tostring(customDimensions["userEvent.message"])
| order by timestamp desc
```

### What to expect: process errors

`WSS: Dummy Add` and `Sub` fail on purpose when `number1` is `-1` (a test hook). The value passes
the gateway's schema, so the failure happens inside the process. Results through the gateway:

| Call | Response |
|------|----------|
| `POST /add {"number1": 2, "number2": 3}` | ✅ 200 `{"sum": 5}` (unchanged) |
| `POST /add {"number1": -1, "number2": 3}` | ✅ 422 `application/json` (body below) |
| `POST /add {"number1": -1.0, "number2": 3}` | ✅ 422, same body |
| `POST /sub {"number1": 5, "number2": 3}` | ✅ 200 `{"difference": 2}` (unchanged) |
| `POST /sub {"number1": -1, "number2": 3}` | ✅ 422, message names `Dummy Sub` |
| `POST /abs {"number1": -1}` (control) | ✅ 200 `{"absolute": 1}` (Abs not changed) |

```text
HTTP/2 422
content-type: application/json

{
  "error": "Unprocessable Entity",
  "status": 422,
  "message": "number1 = -1 is rejected by Dummy Add (simulated business-rule failure)",
  "executionId": "execution-c4b32996-9d52-4a8d-86d5-dffba0f5684b-2026.10.13"
}
```

**What the trace shows** (the failing `/add` call):

- Gateway server and client spans: `http.status_code 422` (span status still unset, as for 429).
- Runtime: "Log request" Notify, then `Try/Catch` > `Decision` > `Exception` (span status
  **ERROR**), then "Log error" Notify with `userEvent.level ERROR` and the full error line, then
  Message, Set Properties and "Error response" Return Documents.
- The response's `executionId` matches the span attribute `execution.id`, so a caller can quote
  it to support and it leads straight to the execution and the trace.

Application Insights end-to-end transaction details of the failing `/add` call: the gateway
request and its call to the runtime are failed (422), the `Exception` item is selected
(`otel.status_code STATUS_CODE_ERROR`, `processStep.userLabel Fail: number1 = -1`), followed by
the "Log error" `Notify` and the error response steps:

![Azure transaction, process error](docs/images/security-guide-26-azure-process-error.png)

## 5. Gateway rejections (rate limit)

In the examples, the Dummy API's plan allows 1 request per second (and 100 per day). Five
parallel calls within 0.04 s gave one 200 and four 429s. Every call was traced under its own
trace id; the rejected ones never reached the runtime.

| Trace | Result | Spans |
|-------|--------|-------|
| `e4af0c181e5b6dc4ffe320f9a24f4be6` | 200 `{"message": "OK"}` | Gateway, then runtime (`WSS: Dummy Fixed Reply`) |
| `df4be41f2c4aab8043c15bc156d06d90`, `bb085ccd53020ef7bb18b30893d7e691`, `f13e823d6fad2aff50ecbbb38bbebbc2`, `e1f6cc636b8f41e8c972e7570722a65a` | 429 | Gateway only |

Response returned to the client on a rejected call:

```text
HTTP/2 429
content-type: application/json
x-rate-limit-limit: 1
x-rate-limit-remaining: 0

{"message":"Rate limit exceeded ! You reach the limit of 1 requests per 1 seconds","http_status_code":429}
```

```mermaid
flowchart LR
  gs["SERVER: GET /ws/rest/dummy/Dummy?log=false<br/>4.7 ms, http.status_code 429<br/>span status: unset"]
  gs --> p1["transform-headers"] --> p2["forwarded-header"] --> p3["set-requesturl"] --> p4["assign-metrics"] --> p5["api-key<br/>OK"] --> p6["rate-limit<br/>status ERROR<br/>Rate limit exceeded ! ..."]
  p6 -.->|"request stops here"| rt["Runtime<br/>not called"]

  classDef err fill:#fde2e2,stroke:#d33,color:#000
  classDef off fill:#eee,stroke:#999,color:#666
  class p6 err
  class rt off
```

Application Insights end-to-end transaction details of one 429 call: the failed gateway request,
and the `rate-limit` item as the last one, with the rejection reason in
`otel.status_description`:

![Azure transaction, rate limit](docs/images/security-guide-27-azure-rate-limit.png)

Search for gateway rejections on the HTTP code, not on the span status: the gateway's server span
keeps status unset on a 4xx. In Application Insights, with the collector's HTTP mapping:

```kusto
requests
| where cloud_RoleName startswith "Boomi-api-gateway" and success == false
| summarize count() by resultCode
```

## 6. Gateway Advanced tracing (payloads and headers)

The gateway records headers and bodies only during an Advanced tracing session, per deployed
API, at most 3 h 59 min (239 minutes) at a time; a longer session is rejected with
`MAX_DURATION_EXCEEDED`. Bodies are captured **unmasked**, so turn it on only for as long as you
need it, and keep in mind who can read the traces.

### Turn it on, check it, stop it

Turn it on and off with the two scripts in `ci-cd/` (run from the project root; the change
takes effect without a redeploy):

```bash
bash ci-cd/gateway-tracing-enable.sh  "$DEPLOYED_API_ID"               # 60 minutes, body + headers + policy config
bash ci-cd/gateway-tracing-enable.sh  "$DEPLOYED_API_ID" 15 --no-headers
bash ci-cd/gateway-tracing-disable.sh "$DEPLOYED_API_ID"               # stop early (expiresAt: null)
bash ci-cd/gateway-api.sh get "$DEPLOYED_API_ID"                       # current tracing state
```

Running `enable` again extends the session. An expired session still shows in `get` with
its past `expiresAt`, so compare it with the current time to see whether one is running.

The deployed API's tracing mode in the console (**API Management > Configure APIs and
Applications > Manage APIs**, the deployed API, **API Tracing**): Basic, Intermediate or
Advanced. The scripts set the time-limited Advanced session through the API.

![API Tracing setting of the deployed API](docs/images/security-guide-28-advanced-tracing-session.png)

### Keep it on (manual renewal)

Each run starts a new 239-minute session from now, so renew at least every 3 h 59 min; a gap
only means calls in it have no bodies or headers.

```bash
# 1. The deployed APIs of the environment (ids change on redeploy, so list them each time)
IDS=$(bash ci-cd/gateway-api.sh list | jq -r '.deployedApis[]
  | select(.environment.name == "<environment-name>") | .id')

# 2. Renew: body and headers, no policy config, maximum length
for id in $IDS; do
  bash ci-cd/gateway-tracing-enable.sh "$id" 239 --no-policy-config >/dev/null
done

# 3. Check: name, end time (UTC), body, headers, policy config
for id in $IDS; do
  bash ci-cd/gateway-api.sh get "$id" | jq -r '.deployedApi | [.component.name,
    .tracing.advanced.expiresAt, .tracing.advanced.captureBody,
    .tracing.advanced.captureHeaders, .tracing.advanced.capturePolicyConfig] | @tsv'
done

# 4. Stop (any time)
bash ci-cd/gateway-tracing-disable.sh <deployedApiId>
```

### Where the data is in the trace

All span attributes are on service `<gateway-service-name>` (no span events):

| What | Span | Attribute |
|------|------|-----------|
| Request body, as forwarded to the backend | `gateway.backend.request` | `gravitee.backend.request.body.preview` |
| Request headers, as forwarded to the backend | `gateway.backend.request` | `gravitee.backend.request.header.<name>` |
| Response body, as received from the backend | `gateway.backend.response` | `gravitee.backend.response.body.preview` |
| Response headers from the backend | `gateway.backend.response` | `gravitee.backend.response.header.<name>` |
| Response headers to the client | Server span (`POST /ws/rest/...`) | `http.response.header.<name>` |
| Headers and query parameters at each policy | `<policy>.request` / `<policy>.response` | `gravitee.policy.before.header.*`, `gravitee.policy.before.request.param.*`, `gravitee.policy.after.request.header.*`, `gravitee.policy.after.http_response.header.*` |
| Policy configuration | `<policy>.request` | `gravitee.policy.configuration` (JSON string), `gravitee.policy.id` |
| API identity | `gateway.request.processing` | `api.id`, `api.name`, `api.version`, `http.path` |

### Where the data is in Azure

Open the transaction (Transaction search, then the call), click the item, and look under
**Custom Properties**. Azure shows some gateway spans as `POST`:

| What | Azure item | Custom property |
|------|------------|-----------------|
| Request body (as forwarded to the backend) | The second `POST` item, just below `gateway.backend.response` (it is `gateway.backend.request`) | `gravitee.backend.request.body.preview` |
| Request headers sent to the backend | same item | `gravitee.backend.request.header.*` |
| Request headers as the client sent them | the first `transform-headers.request` | `gravitee.policy.before.header.*` |
| Response body (from the backend) | `gateway.backend.response` | `gravitee.backend.response.body.preview` |
| Response headers from the backend | same item | `gravitee.backend.response.header.*` |
| Response headers sent to the client | the top item (`gateway.<your-domain.com> POST`) | `http.response.header.*` |
| Rate-limit and quota headers | `rate-limit.response`, `quota.response` | `gravitee.policy.after.http_response.header.x-rate-limit-*`, `x-quota-*` |

The rejected `/add` call during an Advanced session: the second `POST` item
(`gateway.backend.request`) selected, its **Custom Properties** with the request body preview
(framed) and the request headers:

![Azure custom properties, request body](docs/images/security-guide-29-azure-custom-properties-a.png)

A working `/sub` call: the `gateway.backend.response` item selected, with the response body
preview from the runtime (framed), its response headers and `backend.target`:

![Azure custom properties, response body](docs/images/security-guide-29-azure-custom-properties-b.png)

Everything for one call in a single list (replace the trace id):

```kusto
union requests, dependencies
| where operation_Id == "<trace id>"
| mv-apply key = bag_keys(customDimensions) to typeof(string) on (
    where key matches regex @"body\.preview|header\."
    | extend value = tostring(customDimensions[key]))
| project timestamp, item = name, key, value
| order by item asc, key asc
```

The result in Application Insights **Logs**: one row per body or header property of the call (a
`/sub` call from an earlier session; host and IP values masked). The query has no `timestamp`
filter, so set the **Time range** picker to cover the session:

![KQL, one call's bodies and headers](docs/images/security-guide-30-azure-kql-one-call.png)

Bodies across calls (Azure cuts values at 8192 characters; it shows `gateway.backend.request`
as `POST`, so filter on the property, not the name):

```kusto
dependencies
| where isnotempty(customDimensions["gravitee.backend.request.body.preview"])
     or isnotempty(customDimensions["gravitee.backend.response.body.preview"])
| project timestamp, operation_Id, name,
          req = tostring(customDimensions["gravitee.backend.request.body.preview"]),
          resp = tostring(customDimensions["gravitee.backend.response.body.preview"])
| order by timestamp desc
```

The result: request and response bodies across the Advanced sessions, the request body on the
`POST` row and the response body on the `gateway.backend.response` row of each call:

![KQL, bodies across calls](docs/images/security-guide-31-azure-kql-bodies.png)

Mind the Application Insights daily cap: Advanced spans raise the span count per call from about
7-15 to 25-32, and when the cap is reached Azure drops everything for the rest of the day.

### What to expect: verified traces

| Call | Captured |
|------|----------|
| Dummy API `POST /add?test-param=123` `{"number1": 2, "number2": 3}` | Request body (34 bytes) and response `{"sum" : 5}` (17 bytes), both matching `content-length`. **Identical, byte for byte, to the runtime's Notify copies.** |
| PetStore `GET /v3/pet/findByStatus?status=available` | Response XML, 1937 bytes, complete (7 items, ends with `</List>`) |
| HTTPdlight `GET /v5?status=up` | Response `{"message":"OK"}`, 16 bytes |

The two spans of the Dummy `POST /add` call, with all their attributes:

**`gateway.backend.request`** (2.78 ms, kind internal):

| Attribute | Value |
|-----------|-------|
| `http.method` | `POST` |
| `invoker` | `FailoverInvoker` |
| `gravitee.backend.request.body.preview` | `{"number1": 2, "number2": 3}` (pretty-printed, 34 bytes) |
| `gravitee.backend.request.header.accept` | `*/*` |
| `gravitee.backend.request.header.accept-encoding` | `gzip` |
| `gravitee.backend.request.header.content-length` | `34` |
| `gravitee.backend.request.header.content-type` | `application/json` |
| `gravitee.backend.request.header.host` | `gateway.<your-domain.com>` |
| `gravitee.backend.request.header.test-header` | `ABC` |
| `gravitee.backend.request.header.user-agent` | `<client-user-agent>` (the API client's) |
| `gravitee.backend.request.header.via` | `2.0 Caddy` (added by the reverse proxy in front of the gateway, if any) |
| `gravitee.backend.request.header.x-boomi-debug` | `true` |
| `gravitee.backend.request.header.x-forwarded-context` | `/ws/rest/dummy` |
| `gravitee.backend.request.header.x-forwarded-for` | `<client-ip>, <client-ip>` |
| `gravitee.backend.request.header.x-forwarded-host` | `gateway.<your-domain.com>` |
| `gravitee.backend.request.header.x-forwarded-proto` | `https` |
| `gravitee.backend.request.header.x-gateway-transaction-id` | `G:b48fefee-aa93-471c-8fef-eeaa93a71cef` |
| `gravitee.backend.request.header.x-gravitee-request-id` | `b48fefee-aa93-471c-8fef-eeaa93a71cef` |
| `gravitee.backend.request.header.x-real-ip` | `<client-ip>` |

**`gateway.backend.response`** (0.60 ms, kind internal):

| Attribute | Value |
|-----------|-------|
| `http.response.status_code` | `201` |
| `backend.connected` | `true` |
| `backend.target` | `http://<runtime-host>:<port>/ws/rest/dummy/add?test-param=123` |
| `gravitee.backend.response.body.preview` | `{"sum" : 5}` (pretty-printed, 17 bytes) |
| `gravitee.backend.response.header.content-length` | `17` |
| `gravitee.backend.response.header.content-type` | `application/json` |
| `gravitee.backend.response.header.x-atom-protobuf` | `oAFqsgEk...` (184-character encoded internal Atom header, removed before the client) |
| `gravitee.backend.response.header.x-global-uid` | `execution-bf3d9150-77de-4bdc-9d19-74596e4bec51-2026.10.13` (the runtime execution id) |

## 7. OpenAPI validation runbook

The commands to run, assuming the OpenAPI definition is up to date. Run them from the project
root. The examples use the Dummy API; replace the id and file for another API. Each step shows
the output of a run that updated three existing rules.

```mermaid
flowchart LR
  s0["0. Preflight<br/>00-check.sh"] --> s1["1. API id<br/>gateway-api.sh list"]
  s1 --> s2["2. OpenAPI file<br/>repo or fetch"]
  s2 --> s3["3. plan<br/>review plan.txt"]
  s3 --> s4["4. apply --dry-run"]
  s4 --> s5["5. apply --adopt --prune"]
  s5 --> s6["6. Verify<br/>attached + test calls"]
  s6 -.->|"from now on"| s7["7. Pipeline<br/>OAS_VALIDATION + 40-govern.sh"]
```

**0. Preflight** (needs `.env` at the project root):

```bash
bash ci-cd/00-check.sh            # both API planes reachable and authenticated
```

```text
INFO  Plane A OK (HTTP 200) - account: <your account name>
INFO  Plane B OK
INFO  Connectivity check PASSED - both planes reachable and authenticated.
```

**1. Find the deployed API id** and keep it in a variable for the next steps:

```bash
bash ci-cd/gateway-api.sh list | jq -r '.deployedApis[]
  | [.id, .component.name, .version, .environment.name] | @tsv'
export DEPLOYED_API_ID=<dummy-api-id>
```

```text
<dummy-api-id>       Dummy API                  13.0.1   <environment-name>
<petstore-api-id>    PetStore Spring API Proxy  1.0.1    <environment-name>
<httpdlight-api-id>  HTTPdlight API Proxy       3.0.1    <environment-name>
```

**2. Get the OpenAPI file.** Use the contract kept in the repo, or download the spec the
gateway publishes (regenerated on each API Service deploy):

```bash
# Option A: the repo contract
SPEC=gateway/openapi/dummy-api.openapi.json; PLAN_OPTS=""

# Option B: the published spec (sends x-api-key; the key is not written to disk).
# It has no `required` / `additionalProperties`, so plan it with --strict --require-all.
read -rs OAS_API_KEY; export OAS_API_KEY
bash ci-cd/gateway-oas-validation.sh fetch \
  https://gateway.<your-domain.com>/ws/rest/dummy/openapi.json gateway/openapi/dummy-api.published.json
SPEC=gateway/openapi/dummy-api.published.json; PLAN_OPTS="--strict --require-all"
```

Before planning, check the file:

| Check | Why |
|-------|-----|
| Paths are relative to the API base (`/add`, not `/ws/rest/dummy/add`) | The path becomes the policy path |
| Paths are lowercase, without `{templates}` | Others are skipped (platform limit) |
| Request bodies are `application/json` with `required` and `"additionalProperties": false` where the contract is strict | Boomi-generated specs carry neither: `--strict` adds `additionalProperties: false`, `--require-all` makes every property required |
| The API Service's JSON profiles have unique root names | New JSON profiles default to the root name `Root`; when two profiles of one API Service share it, the published spec silently stops regenerating and keeps the last good version. Rename the roots (for example `AddRequest`, `AddResponse`) and redeploy |

**3. Generate the plan (offline) and review it:**

```bash
bash ci-cd/gateway-oas-validation.sh plan "$SPEC" gateway/validation/dummy-api $PLAN_OPTS
cat gateway/validation/dummy-api/plan.txt     # generated rules + skipped operations and why
```

```text
OpenAPI validation plan for Dummy API (from gateway/openapi/dummy-api.openapi.json)
strict=false require-all=false params=false appliedWhen=BEFORE_REQUEST_AFTER_STANDARD_POLICIES

Generated rules:
  POST /add  ->  json-validation  "Dummy API POST /add - request schema"
  POST /sub  ->  json-validation  "Dummy API POST /sub - request schema"
  POST /abs  ->  json-validation  "Dummy API POST /abs - request schema"

Skipped operations:
  GET /Dummy  -  no request body (use --params to validate query/header parameters)
  GET /DummyRequest  -  no request body (use --params to validate query/header parameters)
```

The plan directory holds one rule input per operation (`rules/*.json`, each with its JSON
Schema and error message), `attachments.json` (route to rule names) and `meta.json`. Review
the schemas and messages before applying, for example:

```bash
jq -r '.configuration | fromjson | .errorMessage' gateway/validation/dummy-api/rules/*add*.json
# {"error":"Bad request","message":"Body does not match the request schema of POST /add",
#  "expected":"a JSON object with number1 (number, required), number2 (number, required); no other fields"}
```

**4. Dry-run against the live API** (read-only; shows the policy diff):

```bash
bash ci-cd/gateway-oas-validation.sh apply "$DEPLOYED_API_ID" gateway/validation/dummy-api --dry-run --adopt --prune
```

```text
INFO  [dry-run] would update rule "Dummy API POST /abs - request schema" (<abs-rule-id>)
INFO  [dry-run] would update rule "Dummy API POST /add - request schema" (<add-rule-id>)
INFO  [dry-run] would update rule "Dummy API POST /sub - request schema" (<sub-rule-id>)
INFO  current custom policies on <dummy-api-id>:
{"path":"/abs","when":"BEFORE_REQUEST_AFTER_STANDARD_POLICIES","rules":["Dummy API POST /abs - request schema"]}
{"path":"/add","when":"BEFORE_REQUEST_AFTER_STANDARD_POLICIES","rules":["Dummy API POST /add - request schema"]}
{"path":"/sub","when":"BEFORE_REQUEST_AFTER_STANDARD_POLICIES","rules":["Dummy API POST /sub - request schema"]}
INFO  new custom policies:
{"path":"/abs","appliedWhen":"BEFORE_REQUEST_AFTER_STANDARD_POLICIES","rules":["<abs-rule-id>"]}
{"path":"/add","appliedWhen":"BEFORE_REQUEST_AFTER_STANDARD_POLICIES","rules":["<add-rule-id>"]}
{"path":"/sub","appliedWhen":"BEFORE_REQUEST_AFTER_STANDARD_POLICIES","rules":["<sub-rule-id>"]}
INFO  [dry-run] no changes made
```

Check three things: each rule is `create` (new operation) or `update` (existing, matched by
name); the new attachment list keeps every policy you expect (anything not generated is
kept); and no warning lists hand-made validation rules you didn't mean to adopt.

**5. Apply:**

```bash
bash ci-cd/gateway-oas-validation.sh apply "$DEPLOYED_API_ID" gateway/validation/dummy-api --adopt --prune
```

```text
INFO  updated rule "Dummy API POST /abs - request schema" (<abs-rule-id>)
INFO  updated rule "Dummy API POST /add - request schema" (<add-rule-id>)
INFO  updated rule "Dummy API POST /sub - request schema" (<sub-rule-id>)
WARN  REPLACE customPolicies on deployedApi <dummy-api-id> with 3 entr(ies)
INFO  custom policies replaced; readback:
```

`--adopt` replaces hand-made validation rules on the planned paths; `--prune` deletes generated
rules whose operation is no longer in the OpenAPI. Other policies on the API are kept. The
gateway picks the change up within seconds; there is no publish or redeploy step.

The result in the console (**Manage APIs**, the deployed API, **Policy Rules**, one path at a
time): one `json-validation` rule per route, under **Policies executed before request > Executed
after standard policies** (`BEFORE_REQUEST_AFTER_STANDARD_POLICIES`):

![Policy rules on /add](docs/images/security-guide-32-custom-policies-a.png)

![Policy rules on /sub](docs/images/security-guide-32-custom-policies-b.png)

![Policy rules on /abs](docs/images/security-guide-32-custom-policies-c.png)

**6. Verify:**

```bash
bash ci-cd/gateway-policy.sh attached "$DEPLOYED_API_ID"

K="x-api-key: $OAS_API_KEY"; U=https://gateway.<your-domain.com>/ws/rest/dummy
curl -s -X POST "$U/add" -H "$K" -H 'Content-Type: application/json' -d '{"number1": 2, "number2": 3}'
sleep 1.2   # the example plans allow 1 request per second
curl -s -X POST "$U/add" -H "$K" -H 'Content-Type: application/json' -d '{"number1": "A", "number2": 3}'
```

Expected results (one call per second):

| Route | Body | Response |
|-------|------|----------|
| `POST /add` | `{"number1": 2, "number2": 3}` | ✅ 201 `{"sum": 5}` |
| `POST /add` | `{"number1": "A", "number2": 3}` (wrong type) | ✅ 400, `message`: "... of POST /add", `expected`: "a JSON object with number1 (number, required), number2 (number, required); no other fields" |
| `POST /add` | `{"number1": 2}` (missing field) | ✅ 400, same body |
| `POST /add` | `{"number1": 2, "number2": 3, "evil": "x"}` (extra field) | ✅ 400, same body |
| `POST /add` | `{"number1": 2, "number2": ` (malformed) | ✅ 400, same body |
| `POST /sub` | `{"number1": 5, "number2": "x"}` | ✅ 400, `message`: "... of POST /sub" |
| `POST /abs` | `{"number1": -7.5}` | ✅ 200 `{"absolute": 7.5}` |
| `POST /abs` | `{"number1": -7.5, "number2": 1}` (extra field) | ✅ 400, `expected`: "a JSON object with number1 (number, required); no other fields" |
| `GET /Dummy` (control) | | ✅ 200, unaffected |

The wrong-type call in an API Client: request body on the left, the 400 from `json-validation`
with its `message` and `expected` fields on the right (both framed):

![Validation error response](docs/images/security-guide-33-validation-error.png)

To see what was rejected, start an Advanced tracing session first
(`bash ci-cd/gateway-tracing-enable.sh "$DEPLOYED_API_ID" 15`): the rejected body is then on
`gateway.backend.request` and the failure type (`JSON_INVALID_PAYLOAD` or
`JSON_INVALID_FORMAT`) on `gateway.error.processing` (section 6).

**7. Keep it automated.** Add the API to `OAS_VALIDATION` in `ci-cd/config.sh`. From then on,
editing the OpenAPI and running the governance stage keeps the gateway in line:

```bash
# ci-cd/config.sh (sourced by 40-govern.sh, so DEPLOYED_API_ID must be exported in that
# shell; in CI, set it as a pipeline variable)
OAS_VALIDATION=(
  "${DEPLOYED_API_ID:?export DEPLOYED_API_ID first}|gateway/openapi/dummy-api.openapi.json||--adopt --prune"
)

bash ci-cd/40-govern.sh --check     # plan + dry-run for every entry, no changes
bash ci-cd/40-govern.sh             # plan + apply for every entry
```

**Rollback:** re-run steps 3 and 5 from the previous version of the OpenAPI, or restore the
previous attachment list with `bash ci-cd/gateway-policy.sh set-policies <deployedApiId> <file>`.
