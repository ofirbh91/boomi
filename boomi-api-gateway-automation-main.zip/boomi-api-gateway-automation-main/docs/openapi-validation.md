# OpenAPI-driven request validation on the Boomi gateway

How to turn an API's OpenAPI definition into gateway validation policies, with the scripts in
this repo, by hand or from the pipeline.

## Why a translation is needed

The Boomi API Gateway cannot enforce an OpenAPI file: an OpenAPI attached to an API Proxy or
API Service is documentation for the developer portal, and Boomi's custom-policy list has no
OpenAPI-validation policy. What the gateway can enforce:

| OpenAPI element | Gateway policy | Status on boomi-basic |
|-----------------|----------------|-----------------------|
| JSON request body (`requestBody` with `application/json` or `+json`) | `json-validation`: body vs JSON Schema draft-04, 400 + JSON error on failure | Verified (Dummy API `/add`, `/sub`, `/abs`) |
| Required query/header parameters, `enum`, `pattern`, `minimum`, `maximum` | `request-validation` (`NOT_NULL`, `ENUM`, `PATTERN`, `MIN`, `MAX`) | Generated with `--params`, **not yet verified** on this gateway |
| XML request body | `xml-validation` | Not generated; configure by hand |
| Response bodies | `json-validation` with `RESPONSE_CONTENT` scope | Not generated (returns 500 to the client on failure) |

`ci-cd/gateway-oas-validation.sh` does the translation and applies the result through
`ci-cd/gateway-policy.sh`.

```mermaid
flowchart LR
  oas["OpenAPI contract<br/>gateway/openapi/*.openapi.json"] -->|plan| dir["Plan directory<br/>rules/*.json<br/>attachments.json<br/>plan.txt"]
  dir -->|"review / commit"| dir
  dir -->|"apply --dry-run"| diff["Diff of custom policies"]
  dir -->|apply| gp["gateway-policy.sh<br/>create / update<br/>attached / set-policies"]
  gp --> gw[("Deployed API<br/>custom policies")]
  cfg["config.sh OAS_VALIDATION"] --> gov["40-govern.sh<br/>(--check = dry-run)"]
  gov -->|plan + apply| gp
```

## Where the OpenAPI should come from

Findings on boomi-basic (2026-10-01):

| Source | What it gives | Use it for validation? |
|--------|---------------|------------------------|
| Gateway: `https://<gateway>/ws/rest/<api>/openapi.json` (API key required) | The deployed API's documentation (`deployedApi.documentation.oas`), generated from the API Service profiles and **regenerated on each API Service deploy**, as long as the profiles have unique root names (see below). Profiles have no "mandatory" flag for JSON, so **no `required`** and no `additionalProperties`. | **Yes**, planned with `--strict --require-all` |
| Runtime: `https://<runtime>/ws/rest/<api>/openapi.json` | The same generated spec, served by the runtime. Needs the Shared Web Server credentials (401 without). | Only to cross-check |
| **Contract-first file in this repo** (`gateway/openapi/`) | Exactly what the API promises, including optional fields, enums and patterns | **Yes**, when the contract is stricter than the profiles |

For the Dummy API both sources give the same rules: the published spec planned with
`--strict --require-all`, and the repo contract
[gateway/openapi/dummy-api.openapi.json](../gateway/openapi/dummy-api.openapi.json) planned
as is. Prefer the contract when some fields are optional or need enums or patterns.

**Keep the published spec fresh: give every JSON profile a unique root name.** New JSON
profiles default to the root name `Root`. When two profiles referenced by one API Service share
a root name, the API Service reports "conflicting profiles" and Boomi **silently keeps the last
good published spec**. That froze the Dummy API's spec for several versions; renaming the roots
(`AddSubRequest`, `AddResponse`, ...) fixed it without changing the wire format, and the next
deploy regenerated the spec.

## Route conventions the generator relies on

API Management lowercases policy paths and only accepts URL characters, and the gateway
matches paths case-sensitively: `/Add` is stored as `/add` and never fires on `/Add`, and
regex workarounds such as `/(?i)add` are rejected with `PATH_INVALID`. Therefore:

- **Give routes lowercase paths** (`/add`, not `/Add`). On an API Service, a route-level
  `objectName` override does this without touching the process. Mixed-case paths are skipped.
- **No templated paths** (`/orders/{id}`): a policy path can't express a variable segment, so
  those operations are skipped. Use a static path or validate in the process.
- The OpenAPI path is used as the policy path, so write paths **relative to the API's base
  URL** (`servers[0].url` = `https://<gateway>/ws/rest/dummy`, path `/add`).

## Step by step

Prerequisites: `.env` at the project root (`BOOMI_API_URL`, `BOOMI_USERNAME`,
`BOOMI_API_TOKEN`, `BOOMI_ACCOUNT_ID`; see `.env.example`), `curl`, `jq`. Steps 2 and 3 work
without `.env`.

### 1. Find the deployed API id

```bash
bash ci-cd/00-check.sh                 # both API planes reachable
bash ci-cd/gateway-api.sh list         # deployed APIs: id, version, component, environment
export DEPLOYED_API_ID=59ab7eeb-85da-4df9-9344-69572f3372a2    # the Dummy API on boomi-basic
```

The following steps use `$DEPLOYED_API_ID`.

### 2. Get or write the OpenAPI

Write or update the contract under `gateway/openapi/<api>.openapi.json` (OpenAPI 3.x, JSON;
convert YAML first, e.g. `yq -o=json`). To compare with what the gateway or runtime currently
publishes:

```bash
read -rs OAS_API_KEY; export OAS_API_KEY     # sent as x-api-key, never written to disk
bash ci-cd/gateway-oas-validation.sh fetch \
  https://boomi-basic-gateway.antsoftware.org/ws/rest/dummy/openapi.json /tmp/published.json
```

For a strict contract, set `required` and `"additionalProperties": false` on request objects
(OpenAPI's default allows extra fields). At plan time, `--strict` adds
`additionalProperties: false` wherever the spec leaves it out, and `--require-all` makes every
property required where the spec has no `required` list (use both for a Boomi-generated spec).
Save a downloaded spec under its own name (for example `dummy-api.published.json`) so it never
overwrites the contract.

### 3. Generate the plan (offline)

```bash
bash ci-cd/gateway-oas-validation.sh plan gateway/openapi/dummy-api.openapi.json gateway/validation/dummy-api
```

Options: `--strict`, `--require-all`, `--params` (also generate request-validation rules), `--api-name <name>`
(rule name prefix, default `info.title`), `--when <phase>` (default
`BEFORE_REQUEST_AFTER_STANDARD_POLICIES`, so the API-key check runs first and unauthenticated
callers get no schema feedback).

The plan directory is meant to be reviewed (and can be committed):

| File | Content |
|------|---------|
| `plan.txt` | Generated rules and skipped operations with the reason |
| `rules/*.json` | One `DeployedApiPolicyRuleCreateInput` per operation, e.g. `dummy-api-post-add-request-schema.json` |
| `attachments.json` | `[{path, appliedWhen, rules: [<rule name>]}]`, resolved to ids at apply time |
| `meta.json` | API name, source spec, options |

For the Dummy API:

```text
Generated rules:
  POST /add  ->  json-validation  "Dummy API POST /add - request schema"
  POST /sub  ->  json-validation  "Dummy API POST /sub - request schema"
  POST /abs  ->  json-validation  "Dummy API POST /abs - request schema"

Skipped operations:
  GET /Dummy  -  no request body (use --params to validate query/header parameters)
  GET /DummyRequest  -  no request body (use --params to validate query/header parameters)
```

What the translation does to each body schema:

- resolves every local `$ref` (`#/components/...`), including referenced `requestBodies`;
- OpenAPI `nullable: true` becomes a JSON Schema type union (`["string", "null"]`);
- drops OpenAPI-only keywords (`example`, `examples`, `readOnly`, `writeOnly`, `xml`,
  `discriminator`, `externalDocs`, `deprecated`);
- keeps `allOf` members open even with `--strict`, so the combination can still validate;
- adds `"$schema": "http://json-schema.org/draft-04/schema#"`;
- sets the 400 error body to name the route and describe the expected body, built from the
  route's schema, because the gateway's validation policy can't say which field failed:
  `{"error":"Bad request","message":"Body does not match the request schema of POST /add",
  "expected":"a JSON object with number1 (number, required), number2 (number, required); no
  other fields"}`. Enums, arrays, formats and nested objects are described too (first 10
  fields). Rules generated before 2026-10-14 carry the old fixed message
  `{"error":"Bad request","message":"Body does not match the request schema"}` until the
  next `apply`.

### 4. Dry-run against the live API

```bash
bash ci-cd/gateway-oas-validation.sh apply "$DEPLOYED_API_ID" gateway/validation/dummy-api --dry-run
```

It lists the rules it would create or update (matched **by name**, so re-runs update in
place), the current and the new custom policies, and two warnings worth reading:

- **hand-made validation rules already on planned paths**: requests would be validated twice;
  pass `--adopt` to replace them (step 5);
- **managed rules no longer in the plan** (an operation was removed from the OpenAPI); pass
  `--prune` to delete them.

### 5. Apply

```bash
bash ci-cd/gateway-oas-validation.sh apply "$DEPLOYED_API_ID" gateway/validation/dummy-api --adopt --prune
```

What apply does:

1. lists all policy rules and **creates or updates** each planned rule by name
   (`gateway-policy.sh create|update`). Generated rules carry the description prefix
   `[oas-validation]`, which marks them as managed;
2. reads the API's current custom policies (`gateway-policy.sh attached`) and builds the new
   list: generated rules first on their paths, then **every other attachment kept as is**
   (for example a cache rule). With `--adopt`, hand-made `json-validation` /
   `request-validation` rules on planned paths are detached;
3. refuses any path that is not `^/[a-z0-9/_.~-]*$` (an invalid path can 500 the whole API),
   then **replaces the list** in one call (`gateway-policy.sh set-policies`) and prints the
   readback;
4. with `--prune`, deletes managed rules of this API that are no longer in the plan.

Attachments take effect on the running gateway within seconds; there is no publish step.
Rules detached by `--adopt` are not deleted (they are not managed); remove them with
`gateway-policy.sh delete <id>` once you're happy.

### 6. Verify

```bash
bash ci-cd/gateway-policy.sh attached "$DEPLOYED_API_ID"
```

Then send one valid and a few invalid requests per operation (mind the plan's rate limit,
1 request per second on Free/Gold):

| Request | Expected |
|---------|----------|
| Valid body | 2xx from the backend (`/add` returns 201) |
| Wrong type, missing required field, extra field (strict contract), malformed JSON | 400 with the rule's error body: `message` names the route, `expected` describes the body |
| Another route without a rule | Unchanged |

In the traces, a rejected call stops at the `json-validation` span with `http.status_code`
400 and no runtime spans. That span carries no error message, so search on the status code.
During an Advanced tracing session (`bash ci-cd/gateway-tracing-enable.sh "$DEPLOYED_API_ID"
15`) the trace also has the rejected body (`gravitee.backend.request.body.preview`) and a
`gateway.error.processing` span whose `failure.key` is `JSON_INVALID_PAYLOAD` (schema
mismatch) or `JSON_INVALID_FORMAT` (not JSON).

A rejected response carries no `x-gateway-transaction-id`; the Boomi call log
(`deployedApiCallDetail`) still records the call under its transaction id, so a caller that
sends its own `X-Gateway-Transaction-Id` can quote it (see "Recipe: follow one call end to
end" in [ci-cd/README.md](../ci-cd/README.md#recipe-follow-one-call-end-to-end-one-id)).

### 7. Automate in the pipeline

Add one entry per API to `OAS_VALIDATION` in [ci-cd/config.sh](../ci-cd/config.sh):

```bash
# config.sh is sourced by 40-govern.sh, so DEPLOYED_API_ID must be exported in that shell
# (in CI, set it as a pipeline variable), or write the id literally
OAS_VALIDATION=(
  "${DEPLOYED_API_ID:?export DEPLOYED_API_ID first}|gateway/openapi/dummy-api.openapi.json||--adopt --prune"
)
```

Format: `<deployedApiId>|<openapi.json>|<plan options>|<apply options>`. Then:

```bash
bash ci-cd/40-govern.sh --check            # connectivity + plan + apply --dry-run, no changes
bash ci-cd/40-govern.sh                    # plan + apply for every entry
bash ci-cd/pipeline.sh test --govern-only  # same, as part of the pipeline
```

A typical CI flow: a pull request that changes `gateway/openapi/` runs `40-govern.sh --check`
and shows the policy diff; the merge runs `pipeline.sh <stage>` (or `--govern-only`).

## Rollback

- Re-run apply from the previous version of the OpenAPI (it updates the same rules by name and
  rewrites the attachments), or
- restore the attachments by hand: `gateway-policy.sh set-policies <deployedApiId> <file>`
  with the previous list (the `attached` output of the dry-run shows it), then delete unused
  rules.

## Limits and open points

- **The 400 can't name the failing field.** The gateway bundles `gravitee-policy-json-validation`
  1.6.2. Tested on 2026-10-14:

  | Option | Result |
  |--------|--------|
  | `returnDetailedErrorReport: true` (per-violation pointer and reason, policy 3.0.0+) | Ignored: needs a Boomi gateway upgrade |
  | SpEL in `errorMessage`, e.g. `{#request.content}` | SpEL is evaluated, but the request content resolves empty |
  | Response templates per error key (`JSON_INVALID_PAYLOAD`, `JSON_INVALID_FORMAT`) | Not exposed by the APIM GraphQL API |
  | Reason in logs | Only in the gateway's binary metrics event file, shipped to the platform; `deployedApiCallDetail.errorMessage` is not readable by a standard account |
  | **Per-route `expected` text generated from the schema** | **Used** (applied to the Dummy API on 2026-10-14) |
  | Groovy policy rule that validates and names the field | Not tried: per-call cost, and the type must be allowed by Boomi |
  | Let invalid calls reach the runtime for a field-level 422 | Not chosen: costs a runtime execution per bad call |

- **request-validation is unverified** on this gateway: the type id
  (`policy-request-validation`, override with `REQUEST_VALIDATION_TYPE`) and the config shape
  come from Boomi's docs. Test one rule before relying on `--params`.
- **Templated and mixed-case paths are skipped**, see the route conventions above.
- **Response validation is not generated**: a response that fails would reach the client as a
  500, which hides the backend's answer.
- **The published spec only regenerates without profile conflicts**: it is regenerated on each
  API Service deploy, unless two JSON profiles share a root name, in which case the last good
  spec is kept without any error. No GraphQL or Platform API call updates it directly. For an
  API Proxy, the published spec follows the proxy's attached spec and publication version
  (`api-proxy.sh create --swagger <file>`).
- **OpenAPI-only formats** (`int32`, `int64`, `float`, `double`, `byte`, `binary`, `password`)
  are dropped from the generated schemas: they are not JSON Schema draft-04 formats.
- **`set-policies` sends only the API id and its custom policies.** On boomi-basic the plans and
  auth settings stayed intact (verified after the first live apply); check the readback after
  the first apply on a new API.
- **Verified live on the Dummy API (2026-10-01):** dry-run, then `apply --adopt --prune`
  (3 rules created, 2 hand-made rules detached, plans and auth unchanged), then the same
  valid/invalid test results as before, and a second dry-run that changes nothing. Edge cases
  (cache rule kept, rule order, prune) were tested against a mock of `gateway-policy.sh`.
- **Updating existing rules verified live (2026-10-14):** the first real update failed because
  `apply` sent the rule's `type`, which the update input doesn't accept (it stopped before
  changing anything). Fixed; the three Dummy API rules were then updated with the per-route
  error message and re-tested (valid 201/200, invalid 400 with `expected`, `GET /Dummy` 200).
